var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// shared/schema.ts
var schema_exports = {};
__export(schema_exports, {
  accessRequestStatusEnum: () => accessRequestStatusEnum,
  achievementDifficultyEnum: () => achievementDifficultyEnum,
  achievementTypeEnum: () => achievementTypeEnum,
  achievements: () => achievements,
  achievementsRelations: () => achievementsRelations,
  activityLogs: () => activityLogs,
  activityLogsRelations: () => activityLogsRelations,
  adBillingTypeEnum: () => adBillingTypeEnum,
  adCategoryEnum: () => adCategoryEnum,
  adInquiries: () => adInquiries,
  adInquiriesRelations: () => adInquiriesRelations,
  adPriorityEnum: () => adPriorityEnum,
  adStatusEnum: () => adStatusEnum,
  adViews: () => adViews,
  adViewsRelations: () => adViewsRelations,
  advertisements: () => advertisements,
  advertisementsRelations: () => advertisementsRelations,
  appointmentStatusEnum: () => appointmentStatusEnum,
  appointments: () => appointments,
  appointmentsRelations: () => appointmentsRelations,
  archivedRecords: () => archivedRecords,
  archivedRecordsRelations: () => archivedRecordsRelations,
  auditLogs: () => auditLogs,
  badgeStatusEnum: () => badgeStatusEnum,
  billStatusEnum: () => billStatusEnum,
  billingIntervalEnum: () => billingIntervalEnum,
  claimFormSchema: () => claimFormSchema,
  claimLineItems: () => claimLineItems,
  claimLineItemsRelations: () => claimLineItemsRelations,
  claimStatusEnum: () => claimStatusEnum,
  communicationTranslations: () => communicationTranslations,
  communicationTranslationsRelations: () => communicationTranslationsRelations,
  communicationTypeEnum: () => communicationTypeEnum,
  countries: () => countries,
  countriesRelations: () => countriesRelations,
  countryMedicalCodes: () => countryMedicalCodes,
  countryMedicalCodesRelations: () => countryMedicalCodesRelations,
  crossTenantPatients: () => crossTenantPatients,
  currencies: () => currencies,
  currencyEnum: () => currencyEnum,
  departments: () => departments,
  departmentsRelations: () => departmentsRelations,
  exchangeRates: () => exchangeRates,
  financialTransactions: () => financialTransactions,
  financialTransactionsRelations: () => financialTransactionsRelations,
  healthAnalyses: () => healthAnalyses,
  healthRecommendations: () => healthRecommendations,
  hospitalBills: () => hospitalBills,
  hospitalBillsRelations: () => hospitalBillsRelations,
  hospitalPatientInsurance: () => hospitalPatientInsurance,
  insertAchievementSchema: () => insertAchievementSchema,
  insertActivityLogSchema: () => insertActivityLogSchema,
  insertAdInquirySchema: () => insertAdInquirySchema,
  insertAdViewSchema: () => insertAdViewSchema,
  insertAdvertisementSchema: () => insertAdvertisementSchema,
  insertAppointmentSchema: () => insertAppointmentSchema,
  insertArchivedRecordSchema: () => insertArchivedRecordSchema,
  insertClaimLineItemSchema: () => insertClaimLineItemSchema,
  insertCommunicationTranslationSchema: () => insertCommunicationTranslationSchema,
  insertCountryMedicalCodeSchema: () => insertCountryMedicalCodeSchema,
  insertCountrySchema: () => insertCountrySchema,
  insertCrossTenantPatientSchema: () => insertCrossTenantPatientSchema,
  insertDepartmentSchema: () => insertDepartmentSchema,
  insertFinancialTransactionSchema: () => insertFinancialTransactionSchema,
  insertHealthAnalysisSchema: () => insertHealthAnalysisSchema,
  insertHealthRecommendationSchema: () => insertHealthRecommendationSchema,
  insertHospitalBillSchema: () => insertHospitalBillSchema,
  insertInsuranceClaimSchema: () => insertInsuranceClaimSchema,
  insertInsurancePlanCoverageSchema: () => insertInsurancePlanCoverageSchema,
  insertInsuranceProviderSchema: () => insertInsuranceProviderSchema,
  insertLabBillSchema: () => insertLabBillSchema,
  insertLabOrderAssignmentSchema: () => insertLabOrderAssignmentSchema,
  insertLabOrderSchema: () => insertLabOrderSchema,
  insertLabResultSchema: () => insertLabResultSchema,
  insertLaboratoryApplicationSchema: () => insertLaboratoryApplicationSchema,
  insertLaboratorySchema: () => insertLaboratorySchema,
  insertLeaderboardSchema: () => insertLeaderboardSchema,
  insertMarketplaceOrderItemSchema: () => insertMarketplaceOrderItemSchema,
  insertMarketplaceOrderSchema: () => insertMarketplaceOrderSchema,
  insertMarketplaceProductSchema: () => insertMarketplaceProductSchema,
  insertMedicalCodeUploadSchema: () => insertMedicalCodeUploadSchema,
  insertMedicalCommunicationSchema: () => insertMedicalCommunicationSchema,
  insertMedicalPhraseSchema: () => insertMedicalPhraseSchema,
  insertMedicalSupplierSchema: () => insertMedicalSupplierSchema,
  insertMedicationCopaySchema: () => insertMedicationCopaySchema,
  insertOfflineSyncDataSchema: () => insertOfflineSyncDataSchema,
  insertPatientAccessAuditLogSchema: () => insertPatientAccessAuditLogSchema,
  insertPatientAccessRequestSchema: () => insertPatientAccessRequestSchema,
  insertPatientBillSchema: () => insertPatientBillSchema,
  insertPatientCheckInSchema: () => insertPatientCheckInSchema,
  insertPatientInsuranceSchema: () => insertPatientInsuranceSchema,
  insertPatientPaymentSchema: () => insertPatientPaymentSchema,
  insertPatientSchema: () => insertPatientSchema,
  insertPharmacyBillSchema: () => insertPharmacyBillSchema,
  insertPharmacyPatientInsuranceSchema: () => insertPharmacyPatientInsuranceSchema,
  insertPharmacyReceiptSchema: () => insertPharmacyReceiptSchema,
  insertPharmacyReportTemplateSchema: () => insertPharmacyReportTemplateSchema,
  insertPharmacySchema: () => insertPharmacySchema,
  insertPhraseTranslationSchema: () => insertPhraseTranslationSchema,
  insertPrescriptionSchema: () => insertPrescriptionSchema,
  insertPricingPlanSchema: () => insertPricingPlanSchema,
  insertProductReviewSchema: () => insertProductReviewSchema,
  insertQuoteRequestSchema: () => insertQuoteRequestSchema,
  insertReportSchema: () => insertReportSchema,
  insertRolePermissionSchema: () => insertRolePermissionSchema,
  insertServicePriceSchema: () => insertServicePriceSchema,
  insertSubscriptionSchema: () => insertSubscriptionSchema,
  insertSupportedLanguageSchema: () => insertSupportedLanguageSchema,
  insertTenantSchema: () => insertTenantSchema,
  insertTranslationSchema: () => insertTranslationSchema,
  insertUserAchievementSchema: () => insertUserAchievementSchema,
  insertUserSchema: () => insertUserSchema,
  insertUserStatsSchema: () => insertUserStatsSchema,
  insertVisitSummarySchema: () => insertVisitSummarySchema,
  insertVitalSignsSchema: () => insertVitalSignsSchema,
  insertWorkShiftSchema: () => insertWorkShiftSchema,
  insuranceClaims: () => insuranceClaims,
  insuranceClaimsRelations: () => insuranceClaimsRelations,
  insurancePlanCoverage: () => insurancePlanCoverage,
  insurancePlanCoverageRelations: () => insurancePlanCoverageRelations,
  insuranceProviders: () => insuranceProviders,
  insuranceProvidersRelations: () => insuranceProvidersRelations,
  labBills: () => labBills,
  labOrderAssignments: () => labOrderAssignments,
  labOrderAssignmentsRelations: () => labOrderAssignmentsRelations,
  labOrderStatusEnum: () => labOrderStatusEnum,
  labOrders: () => labOrders,
  labResults: () => labResults,
  labResultsRelations: () => labResultsRelations,
  laboratories: () => laboratories,
  laboratoriesRelations: () => laboratoriesRelations,
  laboratoryApplications: () => laboratoryApplications,
  laboratoryApplicationsRelations: () => laboratoryApplicationsRelations,
  laboratoryPatientInsurance: () => laboratoryPatientInsurance,
  leaderboards: () => leaderboards,
  leaderboardsRelations: () => leaderboardsRelations,
  marketplaceOrderItems: () => marketplaceOrderItems,
  marketplaceOrderItemsRelations: () => marketplaceOrderItemsRelations,
  marketplaceOrders: () => marketplaceOrders,
  marketplaceOrdersRelations: () => marketplaceOrdersRelations,
  marketplaceProducts: () => marketplaceProducts,
  marketplaceProductsRelations: () => marketplaceProductsRelations,
  medicalCodeUploads: () => medicalCodeUploads,
  medicalCodeUploadsRelations: () => medicalCodeUploadsRelations,
  medicalCommunications: () => medicalCommunications,
  medicalCommunicationsRelations: () => medicalCommunicationsRelations,
  medicalPhrases: () => medicalPhrases,
  medicalPhrasesRelations: () => medicalPhrasesRelations,
  medicalSpecialtyEnum: () => medicalSpecialtyEnum,
  medicalSuppliers: () => medicalSuppliers,
  medicationCopays: () => medicationCopays,
  medicationCopaysRelations: () => medicationCopaysRelations,
  offlineSyncData: () => offlineSyncData,
  orderItemStatusEnum: () => orderItemStatusEnum,
  orderStatusEnum: () => orderStatusEnum,
  patientAccessAuditLog: () => patientAccessAuditLog2,
  patientAccessRequests: () => patientAccessRequests,
  patientAssignments: () => patientAssignments,
  patientBills: () => patientBills,
  patientBillsRelations: () => patientBillsRelations,
  patientCheckIns: () => patientCheckIns,
  patientCheckInsRelations: () => patientCheckInsRelations,
  patientInsurance: () => patientInsurance,
  patientInsuranceRelations: () => patientInsuranceRelations,
  patientPayments: () => patientPayments,
  patientPaymentsRelations: () => patientPaymentsRelations,
  patientPharmacyPreferences: () => patientPharmacyPreferences,
  patients: () => patients,
  patientsRelations: () => patientsRelations,
  pendingRegistrations: () => pendingRegistrations,
  pharmacies: () => pharmacies,
  pharmaciesRelations: () => pharmaciesRelations,
  pharmacyBills: () => pharmacyBills,
  pharmacyBillsRelations: () => pharmacyBillsRelations,
  pharmacyPatientInsurance: () => pharmacyPatientInsurance,
  pharmacyPatientInsuranceRelations: () => pharmacyPatientInsuranceRelations,
  pharmacyReceipts: () => pharmacyReceipts,
  pharmacyReportTemplates: () => pharmacyReportTemplates,
  pharmacyReportTemplatesRelations: () => pharmacyReportTemplatesRelations,
  phraseTranslations: () => phraseTranslations,
  phraseTranslationsRelations: () => phraseTranslationsRelations,
  prescriptionArchives: () => prescriptionArchives,
  prescriptionStatusEnum: () => prescriptionStatusEnum,
  prescriptions: () => prescriptions,
  pricingPlans: () => pricingPlans,
  priorityLevelEnum: () => priorityLevelEnum,
  productReviews: () => productReviews,
  productReviewsRelations: () => productReviewsRelations,
  productStatusEnum: () => productStatusEnum,
  quoteRequestStatusEnum: () => quoteRequestStatusEnum,
  quoteRequests: () => quoteRequests,
  reportStatusEnum: () => reportStatusEnum,
  reportTypeEnum: () => reportTypeEnum,
  reports: () => reports,
  reportsRelations: () => reportsRelations,
  roleEnum: () => roleEnum,
  rolePermissions: () => rolePermissions,
  servicePrices: () => servicePrices,
  servicePricesRelations: () => servicePricesRelations,
  serviceTypeEnum: () => serviceTypeEnum,
  sessions: () => sessions,
  shiftStatusEnum: () => shiftStatusEnum,
  specialtyQuestionnaires: () => specialtyQuestionnaires,
  subscriptionPlanEnum: () => subscriptionPlanEnum,
  subscriptionStatusEnum: () => subscriptionStatusEnum,
  subscriptions: () => subscriptions,
  subscriptionsRelations: () => subscriptionsRelations,
  supplierStatusEnum: () => supplierStatusEnum,
  supportedLanguages: () => supportedLanguages,
  supportedLanguagesRelations: () => supportedLanguagesRelations,
  tenantTypeEnum: () => tenantTypeEnum,
  tenants: () => tenants,
  tenantsRelations: () => tenantsRelations,
  translationStatusEnum: () => translationStatusEnum,
  translations: () => translations,
  userAchievements: () => userAchievements,
  userAchievementsRelations: () => userAchievementsRelations,
  userStats: () => userStats,
  userStatsRelations: () => userStatsRelations,
  users: () => users,
  usersRelations: () => usersRelations,
  verificationStatusEnum: () => verificationStatusEnum,
  visitSummaries: () => visitSummaries,
  visitSummariesRelations: () => visitSummariesRelations,
  vitalSigns: () => vitalSigns,
  vitalSignsRelations: () => vitalSignsRelations,
  workShifts: () => workShifts,
  workShiftsRelations: () => workShiftsRelations,
  workflowStageEnum: () => workflowStageEnum
});
import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, uuid, timestamp, boolean, integer, decimal, jsonb, pgEnum, index, unique } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { nanoid } from "nanoid";
var roleEnum, tenantTypeEnum, supplierStatusEnum, quoteRequestStatusEnum, appointmentStatusEnum, prescriptionStatusEnum, labOrderStatusEnum, claimStatusEnum, subscriptionStatusEnum, subscriptionPlanEnum, billingIntervalEnum, reportTypeEnum, reportStatusEnum, communicationTypeEnum, translationStatusEnum, shiftStatusEnum, verificationStatusEnum, currencyEnum, priorityLevelEnum, achievementTypeEnum, achievementDifficultyEnum, badgeStatusEnum, billStatusEnum, accessRequestStatusEnum, workflowStageEnum, serviceTypeEnum, medicalSpecialtyEnum, adCategoryEnum, adStatusEnum, adPriorityEnum, productStatusEnum, orderStatusEnum, orderItemStatusEnum, adBillingTypeEnum, currencies, exchangeRates, sessions, countries, countryMedicalCodes, medicalCodeUploads, tenants, users, patients, crossTenantPatients, appointments, prescriptions, insuranceProviders, patientInsurance, labOrders, servicePrices, insurancePlanCoverage, claimLineItems, prescriptionArchives, medicationCopays, visitSummaries, insuranceClaims, rolePermissions, auditLogs, subscriptions, reports, workShifts, hospitalPatientInsurance, departments, laboratoryPatientInsurance, pharmacyPatientInsurance, patientPharmacyPreferences, archivedRecords, pharmacyReportTemplates, medicalCommunications, communicationTranslations, healthRecommendations, healthAnalyses, supportedLanguages, medicalPhrases, patientAssignments, patientAccessRequests, patientAccessAuditLog2, phraseTranslations, pharmacies, laboratories, laboratoryApplications, pendingRegistrations, labResults, pricingPlans, pharmacyReceipts, labBills, hospitalBills, pharmacyBills, financialTransactions, offlineSyncData, translations, labOrderAssignments, vitalSigns, specialtyQuestionnaires, patientCheckIns, patientBills, patientPayments, achievements, userAchievements, userStats, leaderboards, activityLogs, medicalSuppliers, departmentsRelations, tenantsRelations, insuranceProvidersRelations, patientInsuranceRelations, servicePricesRelations, insurancePlanCoverageRelations, claimLineItemsRelations, insuranceClaimsRelations, subscriptionsRelations, reportsRelations, medicalCommunicationsRelations, communicationTranslationsRelations, supportedLanguagesRelations, medicalPhrasesRelations, phraseTranslationsRelations, usersRelations, pharmaciesRelations, patientsRelations, laboratoriesRelations, laboratoryApplicationsRelations, labResultsRelations, labOrderAssignmentsRelations, appointmentsRelations, vitalSignsRelations, patientCheckInsRelations, medicationCopaysRelations, visitSummariesRelations, patientBillsRelations, patientPaymentsRelations, achievementsRelations, userAchievementsRelations, userStatsRelations, leaderboardsRelations, activityLogsRelations, hospitalBillsRelations, pharmacyBillsRelations, financialTransactionsRelations, workShiftsRelations, pharmacyPatientInsuranceRelations, archivedRecordsRelations, pharmacyReportTemplatesRelations, insertTenantSchema, insertUserSchema, insertPatientSchema, insertCrossTenantPatientSchema, insertAppointmentSchema, insertPrescriptionSchema, insertLabOrderSchema, insertPharmacySchema, insertInsuranceProviderSchema, insertPatientInsuranceSchema, insertInsuranceClaimSchema, claimFormSchema, insertServicePriceSchema, insertInsurancePlanCoverageSchema, insertClaimLineItemSchema, insertMedicationCopaySchema, insertVitalSignsSchema, insertVisitSummarySchema, insertPatientCheckInSchema, insertRolePermissionSchema, insertPatientBillSchema, insertPatientPaymentSchema, insertSubscriptionSchema, insertReportSchema, insertMedicalCommunicationSchema, insertCommunicationTranslationSchema, insertSupportedLanguageSchema, insertMedicalPhraseSchema, insertPhraseTranslationSchema, insertLaboratorySchema, insertLabResultSchema, insertLabOrderAssignmentSchema, insertLaboratoryApplicationSchema, insertHealthRecommendationSchema, insertHealthAnalysisSchema, insertPricingPlanSchema, insertOfflineSyncDataSchema, insertTranslationSchema, insertPharmacyReceiptSchema, insertLabBillSchema, insertHospitalBillSchema, insertPharmacyBillSchema, insertFinancialTransactionSchema, insertAchievementSchema, insertUserAchievementSchema, insertUserStatsSchema, insertLeaderboardSchema, insertActivityLogSchema, insertPatientAccessRequestSchema, insertPatientAccessAuditLogSchema, insertWorkShiftSchema, insertPharmacyPatientInsuranceSchema, insertArchivedRecordSchema, insertPharmacyReportTemplateSchema, insertDepartmentSchema, advertisements, adViews, adInquiries, marketplaceProducts, marketplaceOrders, marketplaceOrderItems, productReviews, quoteRequests, marketplaceProductsRelations, marketplaceOrdersRelations, marketplaceOrderItemsRelations, productReviewsRelations, advertisementsRelations, adViewsRelations, adInquiriesRelations, countriesRelations, countryMedicalCodesRelations, medicalCodeUploadsRelations, insertAdvertisementSchema, insertAdViewSchema, insertAdInquirySchema, insertCountrySchema, insertCountryMedicalCodeSchema, insertMedicalCodeUploadSchema, insertMedicalSupplierSchema, insertMarketplaceProductSchema, insertMarketplaceOrderSchema, insertMarketplaceOrderItemSchema, insertProductReviewSchema, insertQuoteRequestSchema;
var init_schema = __esm({
  "shared/schema.ts"() {
    "use strict";
    roleEnum = pgEnum("role", [
      "super_admin",
      "tenant_admin",
      "director",
      "physician",
      "nurse",
      "pharmacist",
      "lab_technician",
      "receptionist",
      "billing_staff",
      "insurance_manager",
      "patient"
    ]);
    tenantTypeEnum = pgEnum("tenant_type", [
      "platform",
      "hospital",
      "clinic",
      "pharmacy",
      "laboratory",
      "insurance_provider",
      "medical_supplier"
    ]);
    supplierStatusEnum = pgEnum("supplier_status", [
      "pending_review",
      "approved",
      "active",
      "suspended",
      "rejected"
    ]);
    quoteRequestStatusEnum = pgEnum("quote_request_status", [
      "pending",
      "quoted",
      "accepted",
      "rejected",
      "expired"
    ]);
    appointmentStatusEnum = pgEnum("appointment_status", [
      "scheduled",
      "confirmed",
      "checked_in",
      "in_progress",
      "completed",
      "cancelled",
      "no_show"
    ]);
    prescriptionStatusEnum = pgEnum("prescription_status", [
      "prescribed",
      // Prescribed by doctor
      "sent_to_pharmacy",
      // Sent to pharmacy
      "received",
      // Received by pharmacy - new workflow starts
      "insurance_verified",
      // Insurance coverage verified and copay calculated
      "processing",
      // Being processed by pharmacy
      "ready",
      // Ready for pickup
      "dispensed",
      // Dispensed to patient
      "filled",
      // Legacy status - same as dispensed
      "picked_up",
      // Picked up by patient
      "cancelled"
      // Cancelled
    ]);
    labOrderStatusEnum = pgEnum("lab_order_status", [
      "ordered",
      "collected",
      "processing",
      "completed",
      "cancelled"
    ]);
    claimStatusEnum = pgEnum("claim_status", [
      "draft",
      "submitted",
      "processing",
      "approved",
      "denied",
      "paid"
    ]);
    subscriptionStatusEnum = pgEnum("subscription_status", [
      "trial",
      "active",
      "suspended",
      "cancelled",
      "expired"
    ]);
    subscriptionPlanEnum = pgEnum("subscription_plan", [
      "starter",
      "professional",
      "enterprise",
      "white_label",
      "custom"
    ]);
    billingIntervalEnum = pgEnum("billing_interval", [
      "monthly",
      "quarterly",
      "yearly"
    ]);
    reportTypeEnum = pgEnum("report_type", [
      "financial",
      "operational",
      "clinical",
      "compliance",
      "custom"
    ]);
    reportStatusEnum = pgEnum("report_status", [
      "pending",
      "generating",
      "completed",
      "failed"
    ]);
    communicationTypeEnum = pgEnum("communication_type", [
      "medical_instruction",
      "prescription_note",
      "discharge_summary",
      "appointment_reminder",
      "lab_result",
      "general_message",
      "emergency_alert"
    ]);
    translationStatusEnum = pgEnum("translation_status", [
      "pending",
      "translating",
      "completed",
      "failed",
      "manual_review"
    ]);
    shiftStatusEnum = pgEnum("shift_status", [
      "active",
      "completed",
      "cancelled"
    ]);
    verificationStatusEnum = pgEnum("verification_status", [
      "pending",
      "verified",
      "expired",
      "denied"
    ]);
    currencyEnum = pgEnum("currency", [
      // Major International Currencies
      "USD",
      "EUR",
      "GBP",
      "JPY",
      "CHF",
      "CAD",
      "AUD",
      "CNY",
      // African Currencies
      "DZD",
      "AOA",
      "XOF",
      "BWP",
      "BIF",
      "XAF",
      "CVE",
      "KMF",
      "CDF",
      "DJF",
      "EGP",
      "ERN",
      "SZL",
      "ETB",
      "GMD",
      "GHS",
      "GNF",
      "KES",
      "LSL",
      "LRD",
      "LYD",
      "MGA",
      "MWK",
      "MRU",
      "MUR",
      "MAD",
      "MZN",
      "NAD",
      "NGN",
      "RWF",
      "STN",
      "SCR",
      "SLE",
      "SOS",
      "ZAR",
      "SSP",
      "SDG",
      "TZS",
      "TND",
      "UGX",
      "ZMW",
      "ZWL"
    ]);
    priorityLevelEnum = pgEnum("priority_level", [
      "low",
      "normal",
      "high",
      "urgent",
      "emergency"
    ]);
    achievementTypeEnum = pgEnum("achievement_type", [
      "productivity",
      // Speed and volume achievements
      "quality",
      // Accuracy and quality achievements  
      "milestone",
      // Major milestones and targets
      "consistency",
      // Streaks and regular performance
      "teamwork",
      // Collaboration achievements
      "efficiency"
      // Time and resource optimization
    ]);
    achievementDifficultyEnum = pgEnum("achievement_difficulty", [
      "bronze",
      "silver",
      "gold",
      "platinum",
      "legendary"
    ]);
    badgeStatusEnum = pgEnum("badge_status", [
      "locked",
      "unlocked",
      "earned"
    ]);
    billStatusEnum = pgEnum("bill_status", [
      "pending",
      "overdue",
      "paid",
      "partial_payment",
      "cancelled",
      "refunded"
    ]);
    accessRequestStatusEnum = pgEnum("access_request_status", [
      "pending",
      "approved",
      "rejected",
      "expired"
    ]);
    workflowStageEnum = pgEnum("workflow_stage", [
      "queue",
      // Waiting in queue
      "verification",
      // Insurance verification
      "processing",
      // Being processed
      "ready",
      // Ready for pickup
      "completed"
      // Dispensed/completed
    ]);
    serviceTypeEnum = pgEnum("service_type", [
      "procedure",
      "consultation",
      "diagnostic",
      "treatment",
      "laboratory",
      "imaging",
      "therapy",
      "medication",
      "emergency"
    ]);
    medicalSpecialtyEnum = pgEnum("medical_specialty", [
      "family_medicine",
      "internal_medicine",
      "pediatrics",
      "cardiology",
      "dermatology",
      "neurology",
      "orthopedics",
      "gynecology",
      "psychiatry",
      "oncology",
      "emergency_medicine",
      "anesthesiology",
      "radiology",
      "pathology",
      "surgery",
      "ophthalmology",
      "ent",
      "urology",
      "endocrinology",
      "gastroenterology"
    ]);
    adCategoryEnum = pgEnum("ad_category", [
      "medical_devices",
      "diagnostic_equipment",
      "surgical_instruments",
      "laboratory_equipment",
      "pharmacy_supplies",
      "software_solutions",
      "consulting_services",
      "training_programs",
      "maintenance_services",
      "insurance_services",
      "facility_management",
      "telemedicine_solutions"
    ]);
    adStatusEnum = pgEnum("ad_status", [
      "draft",
      "pending_review",
      "approved",
      "active",
      "paused",
      "expired",
      "rejected",
      "suspended"
    ]);
    adPriorityEnum = pgEnum("ad_priority", [
      "standard",
      "featured",
      "premium",
      "sponsored"
    ]);
    productStatusEnum = pgEnum("product_status", [
      "draft",
      "active",
      "inactive",
      "discontinued",
      "out_of_stock"
    ]);
    orderStatusEnum = pgEnum("marketplace_order_status", [
      "pending",
      "confirmed",
      "processing",
      "shipped",
      "delivered",
      "cancelled",
      "refunded"
    ]);
    orderItemStatusEnum = pgEnum("order_item_status", [
      "pending",
      "confirmed",
      "processing",
      "shipped",
      "delivered",
      "cancelled",
      "returned"
    ]);
    adBillingTypeEnum = pgEnum("ad_billing_type", [
      "monthly",
      "per_click",
      "per_impression",
      "fixed_duration"
    ]);
    currencies = pgTable("currencies", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      code: currencyEnum("code").notNull().unique(),
      name: text("name").notNull(),
      symbol: text("symbol").notNull(),
      numericCode: varchar("numeric_code", { length: 3 }),
      decimalPlaces: integer("decimal_places").default(2),
      region: text("region"),
      // Africa, Europe, Asia, etc.
      country: text("country"),
      isActive: boolean("is_active").default(true),
      exchangeRateToUSD: decimal("exchange_rate_to_usd", { precision: 15, scale: 6 }).default("1.000000"),
      lastUpdated: timestamp("last_updated").default(sql`CURRENT_TIMESTAMP`),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`)
    });
    exchangeRates = pgTable("exchange_rates", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      baseCurrency: currencyEnum("base_currency").notNull().default("USD"),
      targetCurrency: currencyEnum("target_currency").notNull(),
      rate: decimal("rate", { precision: 15, scale: 6 }).notNull(),
      bidRate: decimal("bid_rate", { precision: 15, scale: 6 }),
      askRate: decimal("ask_rate", { precision: 15, scale: 6 }),
      provider: text("provider").default("manual"),
      // manual, api, bank
      validFrom: timestamp("valid_from").default(sql`CURRENT_TIMESTAMP`),
      validTo: timestamp("valid_to"),
      isActive: boolean("is_active").default(true),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`)
    });
    sessions = pgTable(
      "sessions",
      {
        sid: varchar("sid").primaryKey(),
        sess: jsonb("sess").notNull(),
        expire: timestamp("expire").notNull()
      },
      (table) => ({
        expireIdx: index("IDX_session_expire").on(table.expire)
      })
    );
    countries = pgTable("countries", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      code: varchar("code", { length: 3 }).unique().notNull(),
      // ISO 3166-1 alpha-3 (USA, CAN, GBR, DEU, etc.)
      name: varchar("name", { length: 255 }).notNull(),
      // United States, Canada, United Kingdom, Germany
      region: varchar("region", { length: 100 }),
      // North America, Europe, Asia-Pacific
      isActive: boolean("is_active").default(true).notNull(),
      // Medical coding standards used in this country
      cptCodeSystem: varchar("cpt_code_system", { length: 50 }).default("CPT-4"),
      // CPT-4, SNOMED-CT, etc.
      icd10CodeSystem: varchar("icd10_code_system", { length: 50 }).default("ICD-10"),
      // ICD-10, ICD-11, etc.
      pharmaceuticalCodeSystem: varchar("pharmaceutical_code_system", { length: 50 }).default("NDC"),
      // NDC, ATC, DIN, etc.
      // Currency and formatting
      currencyCode: varchar("currency_code", { length: 3 }).default("USD"),
      // USD, CAD, EUR, GBP
      dateFormat: varchar("date_format", { length: 20 }).default("MM/DD/YYYY"),
      timeZone: varchar("time_zone", { length: 50 }).default("America/New_York"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    countryMedicalCodes = pgTable("country_medical_codes", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      countryId: uuid("country_id").references(() => countries.id).notNull(),
      codeType: varchar("code_type", { length: 20 }).notNull(),
      // 'CPT', 'ICD10', 'PHARMACEUTICAL'
      code: varchar("code", { length: 50 }).notNull(),
      description: text("description").notNull(),
      category: varchar("category", { length: 100 }),
      // Specialty or category
      amount: decimal("amount", { precision: 10, scale: 2 }),
      // Standard pricing if applicable
      isActive: boolean("is_active").default(true).notNull(),
      // Source tracking
      source: varchar("source", { length: 50 }),
      // 'manual', 'csv_upload', 'api_import'
      uploadedBy: uuid("uploaded_by"),
      // User who added this code
      uploadedAt: timestamp("uploaded_at").default(sql`CURRENT_TIMESTAMP`),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    medicalCodeUploads = pgTable("medical_code_uploads", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      countryId: uuid("country_id").references(() => countries.id).notNull(),
      fileName: varchar("file_name", { length: 255 }).notNull(),
      fileSize: integer("file_size"),
      // in bytes
      recordsProcessed: integer("records_processed").default(0),
      recordsImported: integer("records_imported").default(0),
      recordsSkipped: integer("records_skipped").default(0),
      errors: jsonb("errors").default("[]"),
      // Array of error messages
      status: varchar("status", { length: 20 }).default("processing"),
      // processing, completed, failed
      uploadedBy: uuid("uploaded_by").references(() => users.id).notNull(),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      completedAt: timestamp("completed_at")
    });
    tenants = pgTable("tenants", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      name: text("name").notNull(),
      type: tenantTypeEnum("type").notNull(),
      subdomain: text("subdomain").unique().notNull(),
      countryId: uuid("country_id").references(() => countries.id),
      // Country association
      settings: jsonb("settings").default("{}"),
      isActive: boolean("is_active").default(true),
      // Multi-tenant relationships
      parentTenantId: uuid("parent_tenant_id"),
      // For hospital-owned pharmacies
      organizationType: text("organization_type", { enum: ["independent", "hospital_owned"] }).default("independent"),
      // White-label branding
      brandName: text("brand_name"),
      logoUrl: text("logo_url"),
      primaryColor: varchar("primary_color", { length: 7 }).default("#10b981"),
      // hex color
      secondaryColor: varchar("secondary_color", { length: 7 }).default("#3b82f6"),
      customDomain: text("custom_domain"),
      customCss: text("custom_css"),
      // Multi-language settings
      defaultLanguage: varchar("default_language", { length: 10 }).default("en"),
      supportedLanguages: jsonb("supported_languages").default(["en"]),
      // Currency settings
      baseCurrency: currencyEnum("base_currency").default("USD"),
      supportedCurrencies: jsonb("supported_currencies").default(["USD"]),
      // Offline settings
      offlineEnabled: boolean("offline_enabled").default(false),
      offlineStorageMb: integer("offline_storage_mb").default(100),
      syncFrequencyMinutes: integer("sync_frequency_minutes").default(15),
      // Trial and subscription tracking
      trialStartDate: timestamp("trial_start_date").default(sql`CURRENT_TIMESTAMP`),
      trialEndDate: timestamp("trial_end_date").default(sql`CURRENT_TIMESTAMP + INTERVAL '14 days'`),
      subscriptionStatus: subscriptionStatusEnum("subscription_status").default("trial"),
      lastSuspensionCheck: timestamp("last_suspension_check"),
      suspendedAt: timestamp("suspended_at"),
      suspensionReason: text("suspension_reason"),
      // Phone and address (moved from top level)
      phoneNumber: text("phone_number"),
      address: text("address"),
      description: text("description"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    users = pgTable("users", {
      id: varchar("id").primaryKey(),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      username: text("username"),
      email: text("email"),
      password: text("password"),
      firstName: text("first_name"),
      lastName: text("last_name"),
      profileImageUrl: varchar("profile_image_url"),
      role: roleEnum("role").notNull(),
      isActive: boolean("is_active").default(true),
      isTemporaryPassword: boolean("is_temporary_password").default(false),
      mustChangePassword: boolean("must_change_password").default(false),
      languagePreference: text("language_preference").default("en"),
      lastLogin: timestamp("last_login"),
      // Stripe integration fields
      stripeCustomerId: text("stripe_customer_id"),
      stripeSubscriptionId: text("stripe_subscription_id"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    patients = pgTable("patients", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      mrn: text("mrn").notNull(),
      // Tenant-specific patient ID (unique within each hospital/clinic)
      tenantPatientId: text("tenant_patient_id").notNull(),
      firstName: text("first_name").notNull(),
      lastName: text("last_name").notNull(),
      dateOfBirth: timestamp("date_of_birth").notNull(),
      gender: text("gender"),
      phone: text("phone"),
      email: text("email"),
      address: jsonb("address"),
      emergencyContact: jsonb("emergency_contact"),
      insuranceInfo: jsonb("insurance_info"),
      preferredPharmacyId: uuid("preferred_pharmacy_id").references(() => pharmacies.id),
      primaryPhysicianId: uuid("primary_physician_id").references(() => users.id),
      // Assigned primary doctor
      medicalHistory: jsonb("medical_history").default("[]"),
      allergies: jsonb("allergies").default("[]"),
      medications: jsonb("medications").default("[]"),
      isActive: boolean("is_active").default(true),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    }, (table) => ({
      // Ensure tenant-specific patient ID is unique within each tenant
      uniqueTenantPatientId: unique().on(table.tenantId, table.tenantPatientId),
      // Ensure MRN is unique within each tenant
      uniqueTenantMrn: unique().on(table.tenantId, table.mrn)
    }));
    crossTenantPatients = pgTable("cross_tenant_patients", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      originalPatientId: uuid("original_patient_id").references(() => patients.id).notNull(),
      originalTenantId: uuid("original_tenant_id").references(() => tenants.id).notNull(),
      // Hospital/Clinic
      sharedWithTenantId: uuid("shared_with_tenant_id").references(() => tenants.id).notNull(),
      // Lab/Pharmacy
      tenantPatientId: text("tenant_patient_id").notNull(),
      // Same as original patient's tenant_patient_id
      sharedByUserId: uuid("shared_by_user_id").references(() => users.id).notNull(),
      shareReason: text("share_reason"),
      // "lab_order", "prescription_fulfillment", etc.
      shareType: text("share_type").notNull(),
      // "temporary", "permanent", "visit_specific"
      accessLevel: text("access_level").default("read_only"),
      // "read_only", "read_write", "full_access"
      expiresAt: timestamp("expires_at"),
      // For temporary sharing
      isActive: boolean("is_active").default(true),
      shareMetadata: jsonb("share_metadata"),
      // Additional sharing context
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    }, (table) => ({
      // Ensure one sharing record per patient per target tenant
      uniquePatientSharing: unique().on(table.originalPatientId, table.sharedWithTenantId),
      // Index for quick lookup by tenant patient ID
      tenantPatientIdIndex: index().on(table.sharedWithTenantId, table.tenantPatientId)
    }));
    appointments = pgTable("appointments", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      providerId: uuid("provider_id").references(() => users.id).notNull(),
      appointmentDate: timestamp("appointment_date").notNull(),
      duration: integer("duration").default(30),
      type: text("type").notNull(),
      status: appointmentStatusEnum("status").default("scheduled"),
      notes: text("notes"),
      chiefComplaint: text("chief_complaint"),
      vitals: jsonb("vitals"),
      diagnosis: jsonb("diagnosis").default("[]"),
      treatmentPlan: text("treatment_plan"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    prescriptions = pgTable("prescriptions", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      // Doctor/Hospital tenant
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      providerId: uuid("provider_id").references(() => users.id).notNull(),
      // Doctor who prescribed
      appointmentId: uuid("appointment_id").references(() => appointments.id),
      pharmacyTenantId: uuid("pharmacy_tenant_id").references(() => tenants.id),
      // Target pharmacy chosen by patient
      medicationName: text("medication_name").notNull(),
      dosage: text("dosage").notNull(),
      frequency: text("frequency").notNull(),
      quantity: integer("quantity").notNull(),
      refills: integer("refills").default(0),
      instructions: text("instructions"),
      status: prescriptionStatusEnum("status").default("prescribed"),
      prescribedDate: timestamp("prescribed_date").default(sql`CURRENT_TIMESTAMP`),
      sentToPharmacyDate: timestamp("sent_to_pharmacy_date"),
      filledDate: timestamp("filled_date"),
      expiryDate: timestamp("expiry_date"),
      // Pharmacy workflow fields
      insuranceVerifiedDate: timestamp("insurance_verified_date"),
      insuranceProvider: text("insurance_provider"),
      insuranceCopay: decimal("insurance_copay", { precision: 10, scale: 2 }),
      insuranceCoveragePercentage: decimal("insurance_coverage_percentage", { precision: 5, scale: 2 }),
      // 0-100%
      totalCost: decimal("total_cost", { precision: 10, scale: 2 }),
      processingStartedDate: timestamp("processing_started_date"),
      readyDate: timestamp("ready_date"),
      dispensedDate: timestamp("dispensed_date"),
      pharmacyNotes: text("pharmacy_notes"),
      // Prescription routing fields for hospital-pharmacy communication  
      routedFromHospital: uuid("routed_from_hospital").references(() => tenants.id),
      // Original hospital
      patientSelectedPharmacy: boolean("patient_selected_pharmacy").default(false),
      routingNotes: text("routing_notes"),
      // Workflow optimization fields
      priority: priorityLevelEnum("priority").default("normal"),
      urgencyScore: integer("urgency_score").default(50),
      // 0-100 calculated priority score
      estimatedWaitTime: integer("estimated_wait_time").default(0),
      // minutes
      assignedStaffId: uuid("assigned_staff_id").references(() => users.id),
      // Assigned pharmacist
      workflowStage: text("workflow_stage").default("queue"),
      // queue, verification, processing, ready
      lastStatusUpdate: timestamp("last_status_update").default(sql`CURRENT_TIMESTAMP`),
      patientWaitingSince: timestamp("patient_waiting_since"),
      priorityFactors: jsonb("priority_factors"),
      // JSON object with priority calculation details
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    insuranceProviders = pgTable("insurance_providers", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      name: text("name").notNull(),
      code: text("code").notNull(),
      type: text("type").notNull(),
      // HMO, PPO, Medicare, Medicaid, etc.
      contactInfo: jsonb("contact_info"),
      claimsAddress: text("claims_address"),
      electronicSubmission: boolean("electronic_submission").default(false),
      isActive: boolean("is_active").default(true),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    patientInsurance = pgTable("patient_insurance", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      insuranceProviderId: uuid("insurance_provider_id").references(() => insuranceProviders.id).notNull(),
      policyNumber: text("policy_number").notNull(),
      groupNumber: text("group_number"),
      subscriberName: text("subscriber_name"),
      subscriberRelationship: text("subscriber_relationship"),
      // self, spouse, child, other
      effectiveDate: timestamp("effective_date").notNull(),
      expirationDate: timestamp("expiration_date"),
      copayAmount: decimal("copay_amount", { precision: 10, scale: 2 }),
      deductibleAmount: decimal("deductible_amount", { precision: 10, scale: 2 }),
      isPrimary: boolean("is_primary").default(true),
      isActive: boolean("is_active").default(true),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    labOrders = pgTable("lab_orders", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      providerId: uuid("provider_id").references(() => users.id).notNull(),
      appointmentId: uuid("appointment_id").references(() => appointments.id),
      labTenantId: uuid("lab_tenant_id").references(() => tenants.id),
      testName: text("test_name").notNull(),
      testCode: text("test_code"),
      instructions: text("instructions"),
      priority: text("priority").default("routine"),
      status: labOrderStatusEnum("status").default("ordered"),
      results: jsonb("results"),
      resultDate: timestamp("result_date"),
      orderedDate: timestamp("ordered_date").default(sql`CURRENT_TIMESTAMP`),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    servicePrices = pgTable("service_prices", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      serviceCode: text("service_code").notNull(),
      // CPT, HCPCS, or internal code
      serviceName: text("service_name").notNull(),
      serviceDescription: text("service_description"),
      serviceType: serviceTypeEnum("service_type").notNull(),
      currency: currencyEnum("currency").notNull().default("USD"),
      basePrice: decimal("base_price", { precision: 10, scale: 2 }).notNull(),
      isActive: boolean("is_active").default(true),
      effectiveDate: timestamp("effective_date").default(sql`CURRENT_TIMESTAMP`),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    insurancePlanCoverage = pgTable("insurance_plan_coverage", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      insuranceProviderId: uuid("insurance_provider_id").references(() => insuranceProviders.id).notNull(),
      servicePriceId: uuid("service_price_id").references(() => servicePrices.id).notNull(),
      copayAmount: decimal("copay_amount", { precision: 10, scale: 2 }),
      // Fixed copay
      copayPercentage: decimal("copay_percentage", { precision: 5, scale: 2 }),
      // Percentage copay (0-100)
      deductibleApplies: boolean("deductible_applies").default(false),
      maxCoverageAmount: decimal("max_coverage_amount", { precision: 10, scale: 2 }),
      // Maximum insurance will pay
      preAuthRequired: boolean("pre_auth_required").default(false),
      isActive: boolean("is_active").default(true),
      effectiveDate: timestamp("effective_date").default(sql`CURRENT_TIMESTAMP`),
      expirationDate: timestamp("expiration_date"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    claimLineItems = pgTable("claim_line_items", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      claimId: uuid("claim_id").references(() => insuranceClaims.id).notNull(),
      servicePriceId: uuid("service_price_id").references(() => servicePrices.id).notNull(),
      quantity: integer("quantity").default(1),
      unitPrice: decimal("unit_price", { precision: 10, scale: 2 }).notNull(),
      totalPrice: decimal("total_price", { precision: 10, scale: 2 }).notNull(),
      patientCopay: decimal("patient_copay", { precision: 10, scale: 2 }).notNull(),
      insuranceAmount: decimal("insurance_amount", { precision: 10, scale: 2 }).notNull(),
      deductibleAmount: decimal("deductible_amount", { precision: 10, scale: 2 }).default("0"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    prescriptionArchives = pgTable("prescription_archives", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      // Pharmacy tenant
      originalPrescriptionId: uuid("original_prescription_id").notNull(),
      // Reference to original prescription
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      providerId: uuid("provider_id").references(() => users.id).notNull(),
      pharmacyTenantId: uuid("pharmacy_tenant_id").references(() => tenants.id),
      medicationName: text("medication_name").notNull(),
      dosage: text("dosage").notNull(),
      frequency: text("frequency").notNull(),
      quantity: integer("quantity").notNull(),
      refills: integer("refills").default(0),
      instructions: text("instructions"),
      status: prescriptionStatusEnum("status").default("dispensed"),
      prescribedDate: timestamp("prescribed_date"),
      dispensedDate: timestamp("dispensed_date"),
      archivedDate: timestamp("archived_date").default(sql`CURRENT_TIMESTAMP`),
      insuranceProvider: text("insurance_provider"),
      insuranceCopay: decimal("insurance_copay", { precision: 10, scale: 2 }),
      insuranceCoveragePercentage: decimal("insurance_coverage_percentage", { precision: 5, scale: 2 }),
      totalCost: decimal("total_cost", { precision: 10, scale: 2 }),
      pharmacyNotes: text("pharmacy_notes"),
      claimNumber: text("claim_number"),
      transactionId: text("transaction_id"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    medicationCopays = pgTable("medication_copays", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      // Pharmacy tenant
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      patientInsuranceId: uuid("patient_insurance_id").references(() => patientInsurance.id).notNull(),
      prescriptionId: uuid("prescription_id").references(() => prescriptions.id),
      medicationName: text("medication_name").notNull(),
      genericName: text("generic_name"),
      strength: text("strength"),
      dosageForm: text("dosage_form"),
      // tablet, capsule, liquid, etc.
      ndcNumber: text("ndc_number"),
      // National Drug Code
      // Pricing Information
      fullPrice: decimal("full_price", { precision: 10, scale: 2 }).notNull(),
      // Full medication price
      insuranceCoverage: decimal("insurance_coverage", { precision: 10, scale: 2 }).notNull(),
      // Amount covered by insurance
      patientCopay: decimal("patient_copay", { precision: 10, scale: 2 }).notNull(),
      // Amount patient pays
      copayPercentage: decimal("copay_percentage", { precision: 5, scale: 2 }),
      // If percentage-based copay
      // Insurance Details
      formularyTier: text("formulary_tier"),
      // Tier 1, 2, 3, etc.
      priorAuthRequired: boolean("prior_auth_required").default(false),
      quantityLimit: integer("quantity_limit"),
      // Max quantity per fill
      daySupplyLimit: integer("day_supply_limit"),
      // Max days supply
      // Pharmacy Information
      definedByPharmacist: uuid("defined_by_pharmacist").references(() => users.id).notNull(),
      pharmacyNotes: text("pharmacy_notes"),
      effectiveDate: timestamp("effective_date").default(sql`CURRENT_TIMESTAMP`),
      expirationDate: timestamp("expiration_date"),
      // Status
      isActive: boolean("is_active").default(true),
      lastVerified: timestamp("last_verified").default(sql`CURRENT_TIMESTAMP`),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    visitSummaries = pgTable("visit_summaries", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      appointmentId: uuid("appointment_id").references(() => appointments.id).notNull(),
      providerId: uuid("provider_id").references(() => users.id).notNull(),
      vitalSignsId: uuid("vital_signs_id").references(() => vitalSigns.id),
      // Chief Complaint and History
      chiefComplaint: text("chief_complaint").notNull(),
      historyOfPresentIllness: text("history_of_present_illness"),
      reviewOfSystems: jsonb("review_of_systems").default("{}"),
      // Physical Examination
      physicalExamination: text("physical_examination"),
      symptoms: jsonb("symptoms").default("[]"),
      // Array of symptom objects
      // Assessment and Plan
      assessment: text("assessment"),
      clinicalImpression: text("clinical_impression"),
      differentialDiagnosis: jsonb("differential_diagnosis").default("[]"),
      finalDiagnosis: jsonb("final_diagnosis").default("[]"),
      treatmentPlan: text("treatment_plan"),
      // Follow-up and Instructions
      patientInstructions: text("patient_instructions"),
      followUpInstructions: text("follow_up_instructions"),
      returnVisitRecommended: boolean("return_visit_recommended").default(false),
      returnVisitTimeframe: text("return_visit_timeframe"),
      // Provider Notes
      providerNotes: text("provider_notes"),
      // Status and Timestamps
      status: text("status").default("draft"),
      // draft, finalized
      visitDate: timestamp("visit_date").default(sql`CURRENT_TIMESTAMP`),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    insuranceClaims = pgTable("insurance_claims", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      appointmentId: uuid("appointment_id").references(() => appointments.id),
      visitSummaryId: uuid("visit_summary_id").references(() => visitSummaries.id),
      patientInsuranceId: uuid("patient_insurance_id").references(() => patientInsurance.id),
      providerId: uuid("provider_id").references(() => users.id).notNull(),
      // Doctor who created the claim
      medicalSpecialty: medicalSpecialtyEnum("medical_specialty"),
      claimNumber: text("claim_number").unique().notNull(),
      // Enhanced Medical Coding
      primaryDiagnosisCode: text("primary_diagnosis_code"),
      // Primary ICD-10 code
      primaryDiagnosisDescription: text("primary_diagnosis_description"),
      secondaryDiagnosisCodes: jsonb("secondary_diagnosis_codes").default("[]"),
      // Additional ICD-10 codes
      procedureCodes: jsonb("procedure_codes").default("[]"),
      // CPT codes with descriptions
      diagnosisCodes: jsonb("diagnosis_codes").default("[]"),
      // Legacy field for backward compatibility
      // Clinical Information
      clinicalFindings: text("clinical_findings"),
      treatmentProvided: text("treatment_provided"),
      durationOfTreatment: text("duration_of_treatment"),
      medicalNecessity: text("medical_necessity"),
      // Financial Information
      totalAmount: decimal("total_amount", { precision: 10, scale: 2 }).notNull(),
      totalPatientCopay: decimal("total_patient_copay", { precision: 10, scale: 2 }).default("0").notNull(),
      totalInsuranceAmount: decimal("total_insurance_amount", { precision: 10, scale: 2 }).default("0").notNull(),
      approvedAmount: decimal("approved_amount", { precision: 10, scale: 2 }),
      paidAmount: decimal("paid_amount", { precision: 10, scale: 2 }),
      // Claim Processing
      status: claimStatusEnum("status").default("draft"),
      submittedDate: timestamp("submitted_date"),
      processedDate: timestamp("processed_date"),
      paidDate: timestamp("paid_date"),
      rejectionReason: text("rejection_reason"),
      // Documentation
      notes: text("notes"),
      attachments: jsonb("attachments").default("[]"),
      // Supporting documents
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    rolePermissions = pgTable("role_permissions", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      role: roleEnum("role").notNull(),
      module: varchar("module", { length: 50 }).notNull(),
      // 'patients', 'appointments', 'prescriptions', etc.
      permissions: text("permissions").array().notNull(),
      // ['view', 'create', 'update', 'delete']
      isActive: boolean("is_active").default(true).notNull(),
      createdBy: uuid("created_by").references(() => users.id).notNull(),
      updatedBy: uuid("updated_by").references(() => users.id),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`).notNull()
    });
    auditLogs = pgTable("audit_logs", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      userId: uuid("user_id").references(() => users.id),
      entityType: text("entity_type").notNull(),
      entityId: uuid("entity_id").notNull(),
      action: text("action").notNull(),
      previousData: jsonb("previous_data"),
      newData: jsonb("new_data"),
      ipAddress: text("ip_address"),
      userAgent: text("user_agent"),
      timestamp: timestamp("timestamp").default(sql`CURRENT_TIMESTAMP`)
    });
    subscriptions = pgTable("subscriptions", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      pricingPlanId: uuid("pricing_plan_id").references(() => pricingPlans.id),
      planName: text("plan_name").notNull(),
      plan: subscriptionPlanEnum("plan").notNull().default("starter"),
      status: subscriptionStatusEnum("status").default("trial"),
      billingInterval: billingIntervalEnum("billing_interval").default("monthly"),
      monthlyPrice: decimal("monthly_price", { precision: 10, scale: 2 }).notNull(),
      maxUsers: integer("max_users").notNull(),
      maxPatients: integer("max_patients"),
      features: jsonb("features").default("[]"),
      trialEndsAt: timestamp("trial_ends_at"),
      currentPeriodStart: timestamp("current_period_start"),
      currentPeriodEnd: timestamp("current_period_end"),
      startDate: timestamp("start_date").notNull(),
      endDate: timestamp("end_date"),
      cancelAtPeriodEnd: boolean("cancel_at_period_end").default(false),
      customerId: text("customer_id"),
      // Stripe customer ID
      subscriptionId: text("subscription_id"),
      // Stripe subscription ID
      lastPaymentDate: timestamp("last_payment_date"),
      nextPaymentDate: timestamp("next_payment_date"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    reports = pgTable("reports", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      generatedBy: uuid("generated_by").references(() => users.id).notNull(),
      title: text("title").notNull(),
      type: reportTypeEnum("type").notNull(),
      format: text("format").default("pdf"),
      parameters: jsonb("parameters").default("{}"),
      data: jsonb("data"),
      status: reportStatusEnum("status").default("pending"),
      fileUrl: text("file_url"),
      dateFrom: timestamp("date_from"),
      dateTo: timestamp("date_to"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      completedAt: timestamp("completed_at")
    });
    workShifts = pgTable("work_shifts", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      userId: uuid("user_id").references(() => users.id).notNull(),
      // Pharmacist or staff
      shiftType: text("shift_type").notNull(),
      // morning, afternoon, evening, night
      startTime: timestamp("start_time").notNull(),
      endTime: timestamp("end_time"),
      status: shiftStatusEnum("status").default("active"),
      notes: text("notes"),
      totalPrescriptionsProcessed: integer("total_prescriptions_processed").default(0),
      totalRevenue: decimal("total_revenue", { precision: 10, scale: 2 }).default("0"),
      totalInsuranceClaims: integer("total_insurance_claims").default(0),
      shiftSummary: jsonb("shift_summary").default("{}"),
      // Summary statistics for the shift
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    hospitalPatientInsurance = pgTable("hospital_patient_insurance", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      // Primary Insurance
      primaryInsuranceProvider: text("primary_insurance_provider"),
      primaryPolicyNumber: text("primary_policy_number"),
      primaryGroupNumber: text("primary_group_number"),
      primaryMemberId: text("primary_member_id"),
      primarySubscriberName: text("primary_subscriber_name"),
      primarySubscriberRelationship: text("primary_subscriber_relationship"),
      primarySubscriberDob: timestamp("primary_subscriber_dob"),
      primaryEffectiveDate: timestamp("primary_effective_date"),
      primaryExpirationDate: timestamp("primary_expiration_date"),
      primaryCopayAmount: decimal("primary_copay_amount", { precision: 10, scale: 2 }),
      primaryDeductibleAmount: decimal("primary_deductible_amount", { precision: 10, scale: 2 }),
      primaryCoveragePercentage: integer("primary_coverage_percentage"),
      primaryIsActive: boolean("primary_is_active").default(true),
      // Secondary Insurance
      secondaryInsuranceProvider: text("secondary_insurance_provider"),
      secondaryPolicyNumber: text("secondary_policy_number"),
      secondaryGroupNumber: text("secondary_group_number"),
      secondaryMemberId: text("secondary_member_id"),
      secondarySubscriberName: text("secondary_subscriber_name"),
      secondarySubscriberRelationship: text("secondary_subscriber_relationship"),
      secondarySubscriberDob: timestamp("secondary_subscriber_dob"),
      secondaryEffectiveDate: timestamp("secondary_effective_date"),
      secondaryExpirationDate: timestamp("secondary_expiration_date"),
      secondaryCoveragePercentage: integer("secondary_coverage_percentage"),
      secondaryIsActive: boolean("secondary_is_active").default(false),
      // Verification details
      lastVerificationDate: timestamp("last_verification_date"),
      verificationStatus: text("verification_status").default("pending"),
      verificationNotes: text("verification_notes"),
      verifiedBy: uuid("verified_by").references(() => users.id),
      // Additional details
      emergencyContact: jsonb("emergency_contact"),
      specialPrograms: text("special_programs").array(),
      copayCards: jsonb("copay_cards").default("[]"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    departments = pgTable("departments", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      name: text("name").notNull(),
      description: text("description"),
      icon: text("icon").default("Building2"),
      // Lucide icon name
      color: text("color").default("#3b82f6"),
      // Department color theme
      headOfDepartment: uuid("head_of_department").references(() => users.id),
      staffCount: integer("staff_count").default(0),
      operatingHours: text("operating_hours").default("9:00 AM - 5:00 PM"),
      location: text("location"),
      phone: text("phone"),
      email: text("email"),
      budget: decimal("budget", { precision: 12, scale: 2 }),
      specializations: text("specializations").array().default(sql`'{}'::text[]`),
      equipment: jsonb("equipment").default("[]"),
      certifications: text("certifications").array().default(sql`'{}'::text[]`),
      isActive: boolean("is_active").default(true),
      settings: jsonb("settings").default("{}"),
      metrics: jsonb("metrics").default("{}"),
      // Performance metrics and KPIs
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    laboratoryPatientInsurance = pgTable("laboratory_patient_insurance", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      // Primary Insurance
      primaryInsuranceProvider: text("primary_insurance_provider"),
      primaryPolicyNumber: text("primary_policy_number"),
      primaryGroupNumber: text("primary_group_number"),
      primaryMemberId: text("primary_member_id"),
      primarySubscriberName: text("primary_subscriber_name"),
      primarySubscriberRelationship: text("primary_subscriber_relationship"),
      primarySubscriberDob: timestamp("primary_subscriber_dob"),
      primaryEffectiveDate: timestamp("primary_effective_date"),
      primaryExpirationDate: timestamp("primary_expiration_date"),
      primaryCopayAmount: decimal("primary_copay_amount", { precision: 10, scale: 2 }),
      primaryDeductibleAmount: decimal("primary_deductible_amount", { precision: 10, scale: 2 }),
      primaryCoveragePercentage: integer("primary_coverage_percentage"),
      primaryIsActive: boolean("primary_is_active").default(true),
      // Secondary Insurance
      secondaryInsuranceProvider: text("secondary_insurance_provider"),
      secondaryPolicyNumber: text("secondary_policy_number"),
      secondaryGroupNumber: text("secondary_group_number"),
      secondaryMemberId: text("secondary_member_id"),
      secondarySubscriberName: text("secondary_subscriber_name"),
      secondarySubscriberRelationship: text("secondary_subscriber_relationship"),
      secondarySubscriberDob: timestamp("secondary_subscriber_dob"),
      secondaryEffectiveDate: timestamp("secondary_effective_date"),
      secondaryExpirationDate: timestamp("secondary_expiration_date"),
      secondaryCoveragePercentage: integer("secondary_coverage_percentage"),
      secondaryIsActive: boolean("secondary_is_active").default(false),
      // Verification details
      lastVerificationDate: timestamp("last_verification_date"),
      verificationStatus: text("verification_status").default("pending"),
      verificationNotes: text("verification_notes"),
      verifiedBy: uuid("verified_by").references(() => users.id),
      // Additional details
      emergencyContact: jsonb("emergency_contact"),
      specialPrograms: text("special_programs").array(),
      copayCards: jsonb("copay_cards").default("[]"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    pharmacyPatientInsurance = pgTable("pharmacy_patient_insurance", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      // Pharmacy tenant
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      // Primary Insurance
      primaryInsuranceProvider: text("primary_insurance_provider"),
      primaryPolicyNumber: text("primary_policy_number"),
      primaryGroupNumber: text("primary_group_number"),
      primaryMemberId: text("primary_member_id"),
      primarySubscriberName: text("primary_subscriber_name"),
      primarySubscriberRelationship: text("primary_subscriber_relationship"),
      // self, spouse, child, parent
      primarySubscriberDob: timestamp("primary_subscriber_dob"),
      primaryEffectiveDate: timestamp("primary_effective_date"),
      primaryExpirationDate: timestamp("primary_expiration_date"),
      primaryCopayAmount: decimal("primary_copay_amount", { precision: 10, scale: 2 }),
      primaryDeductibleAmount: decimal("primary_deductible_amount", { precision: 10, scale: 2 }),
      primaryIsActive: boolean("primary_is_active").default(true),
      // Secondary Insurance (if applicable)
      secondaryInsuranceProvider: text("secondary_insurance_provider"),
      secondaryPolicyNumber: text("secondary_policy_number"),
      secondaryGroupNumber: text("secondary_group_number"),
      secondaryMemberId: text("secondary_member_id"),
      secondarySubscriberName: text("secondary_subscriber_name"),
      secondarySubscriberRelationship: text("secondary_subscriber_relationship"),
      secondarySubscriberDob: timestamp("secondary_subscriber_dob"),
      secondaryEffectiveDate: timestamp("secondary_effective_date"),
      secondaryExpirationDate: timestamp("secondary_expiration_date"),
      secondaryIsActive: boolean("secondary_is_active").default(false),
      // Pharmacy-specific insurance details
      preferredPharmacyNetwork: text("preferred_pharmacy_network"),
      formularyTier: text("formulary_tier"),
      // Tier 1, 2, 3, 4, specialty
      mailOrderBenefit: boolean("mail_order_benefit").default(false),
      maxDaysSupply: integer("max_days_supply").default(30),
      refillLimitations: text("refill_limitations"),
      priorAuthRequired: boolean("prior_auth_required").default(false),
      stepTherapyRequired: boolean("step_therapy_required").default(false),
      // Verification details
      lastVerificationDate: timestamp("last_verification_date"),
      verificationStatus: verificationStatusEnum("verification_status").default("pending"),
      verificationNotes: text("verification_notes"),
      verifiedBy: uuid("verified_by").references(() => users.id),
      // Pharmacist who verified
      // Additional details
      emergencyContact: jsonb("emergency_contact"),
      specialPrograms: text("special_programs").array().default([]),
      // Medicare Part D, Medicaid, etc.
      copayCards: jsonb("copay_cards").default("[]"),
      // Manufacturer copay cards
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    patientPharmacyPreferences = pgTable("patient_pharmacy_preferences", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      pharmacyId: uuid("pharmacy_id").references(() => tenants.id).notNull(),
      // Preferred pharmacy
      hospitalId: uuid("hospital_id").references(() => tenants.id),
      // Hospital context (optional)
      isPrimary: boolean("is_primary").default(false),
      // Primary pharmacy choice
      isActive: boolean("is_active").default(true),
      preferenceReason: text("preference_reason"),
      // Why patient chose this pharmacy
      deliveryPreference: text("delivery_preference", { enum: ["pickup", "delivery", "both"] }).default("pickup"),
      specialInstructions: text("special_instructions"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    archivedRecords = pgTable("archived_records", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      workShiftId: uuid("work_shift_id").references(() => workShifts.id).notNull(),
      recordType: text("record_type").notNull(),
      // prescription, receipt, payment, insurance_claim
      recordId: uuid("record_id").notNull(),
      // Reference to the actual record
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      // Search metadata for quick retrieval
      patientName: text("patient_name").notNull(),
      patientMrn: text("patient_mrn"),
      medicationName: text("medication_name"),
      prescriptionNumber: text("prescription_number"),
      receiptNumber: text("receipt_number"),
      insuranceProvider: text("insurance_provider"),
      // Archive details
      archivedAt: timestamp("archived_at").default(sql`CURRENT_TIMESTAMP`),
      archivedBy: uuid("archived_by").references(() => users.id).notNull(),
      // Access tracking
      accessCount: integer("access_count").default(0),
      lastAccessedAt: timestamp("last_accessed_at"),
      lastAccessedBy: uuid("last_accessed_by").references(() => users.id),
      // Additional metadata
      recordData: jsonb("record_data"),
      // Snapshot of the record at time of archiving
      tags: text("tags").array().default([]),
      // For categorization
      notes: text("notes"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`)
    });
    pharmacyReportTemplates = pgTable("pharmacy_report_templates", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      name: text("name").notNull(),
      description: text("description"),
      reportType: text("report_type").notNull(),
      // daily_sales, insurance_summary, patient_demographics, medication_dispensing, etc.
      // Template configuration
      dataFields: jsonb("data_fields").notNull(),
      // Which fields to include
      groupBy: text("group_by").array().default([]),
      // How to group data
      orderBy: text("order_by").array().default([]),
      // How to sort data
      filters: jsonb("filters").default("{}"),
      // Default filters
      // Scheduling options
      isScheduled: boolean("is_scheduled").default(false),
      scheduleFrequency: text("schedule_frequency"),
      // daily, weekly, monthly
      scheduleTime: text("schedule_time"),
      // Time to generate
      lastGenerated: timestamp("last_generated"),
      // Template settings
      isActive: boolean("is_active").default(true),
      isDefault: boolean("is_default").default(false),
      createdBy: uuid("created_by").references(() => users.id).notNull(),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    medicalCommunications = pgTable("medical_communications", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      senderId: uuid("sender_id").references(() => users.id).notNull(),
      recipientId: uuid("recipient_id").references(() => users.id),
      type: communicationTypeEnum("type").notNull(),
      priority: priorityLevelEnum("priority").default("normal"),
      originalLanguage: text("original_language").notNull().default("en"),
      targetLanguages: jsonb("target_languages").default('["en"]'),
      originalContent: jsonb("original_content").notNull(),
      metadata: jsonb("metadata").default("{}"),
      appointmentId: uuid("appointment_id").references(() => appointments.id),
      prescriptionId: uuid("prescription_id").references(() => prescriptions.id),
      labOrderId: uuid("lab_order_id").references(() => labOrders.id),
      isRead: boolean("is_read").default(false),
      readAt: timestamp("read_at"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    communicationTranslations = pgTable("communication_translations", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      communicationId: uuid("communication_id").references(() => medicalCommunications.id).notNull(),
      languageCode: text("language_code").notNull(),
      translatedContent: jsonb("translated_content").notNull(),
      status: translationStatusEnum("status").default("pending"),
      translationEngine: text("translation_engine"),
      reviewedBy: uuid("reviewed_by").references(() => users.id),
      reviewedAt: timestamp("reviewed_at"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    healthRecommendations = pgTable("health_recommendations", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      type: text("type").notNull(),
      // lifestyle, medical, preventive, risk_alert
      priority: text("priority").notNull(),
      // low, medium, high, urgent
      title: text("title").notNull(),
      description: text("description").notNull(),
      recommendations: jsonb("recommendations").default("[]"),
      reasoning: text("reasoning"),
      followUpRequired: boolean("follow_up_required").default(false),
      status: text("status").default("active"),
      // active, dismissed, completed
      acknowledgedAt: timestamp("acknowledged_at"),
      acknowledgedBy: uuid("acknowledged_by").references(() => users.id),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    healthAnalyses = pgTable("health_analyses", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      overallHealthScore: integer("overall_health_score").notNull(),
      riskFactors: jsonb("risk_factors").default("[]"),
      trends: jsonb("trends").default("{}"),
      nextAppointmentSuggestion: text("next_appointment_suggestion"),
      analysisData: jsonb("analysis_data"),
      confidence: decimal("confidence", { precision: 3, scale: 2 }),
      reviewedBy: uuid("reviewed_by").references(() => users.id),
      reviewedAt: timestamp("reviewed_at"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    supportedLanguages = pgTable("supported_languages", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      languageCode: text("language_code").notNull(),
      languageName: text("language_name").notNull(),
      nativeName: text("native_name").notNull(),
      isActive: boolean("is_active").default(true),
      isPrimary: boolean("is_primary").default(false),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    medicalPhrases = pgTable("medical_phrases", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      category: text("category").notNull(),
      phraseKey: text("phrase_key").notNull(),
      originalLanguage: text("original_language").notNull().default("en"),
      originalText: text("original_text").notNull(),
      isActive: boolean("is_active").default(true),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    patientAssignments = pgTable("patient_assignments", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      physicianId: uuid("physician_id").references(() => users.id).notNull(),
      assignmentType: text("assignment_type").notNull().default("primary"),
      // primary, secondary, temporary
      assignedBy: uuid("assigned_by").references(() => users.id).notNull(),
      // Who assigned the patient
      assignedDate: timestamp("assigned_date").default(sql`CURRENT_TIMESTAMP`),
      expiryDate: timestamp("expiry_date"),
      // For temporary assignments
      isActive: boolean("is_active").default(true),
      notes: text("notes"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    patientAccessRequests = pgTable("patient_access_requests", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      requestingPhysicianId: uuid("requesting_physician_id").references(() => users.id).notNull(),
      targetPhysicianId: uuid("target_physician_id").references(() => users.id),
      // Chief physician or assigned doctor
      requestType: text("request_type").notNull().default("access"),
      // access, transfer, consultation
      reason: text("reason").notNull(),
      urgency: text("urgency").notNull().default("normal"),
      // low, normal, high, emergency
      status: accessRequestStatusEnum("status").default("pending").notNull(),
      requestedDate: timestamp("requested_date").default(sql`CURRENT_TIMESTAMP`),
      reviewedDate: timestamp("reviewed_date"),
      reviewedBy: uuid("reviewed_by").references(() => users.id),
      reviewNotes: text("review_notes"),
      accessGrantedUntil: timestamp("access_granted_until"),
      // Temporary access expiry
      accessType: text("access_type").default("read").notNull(),
      // read, write, full
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    patientAccessAuditLog2 = pgTable("patient_access_audit_log", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      // Access Details
      doctorId: uuid("doctor_id").references(() => users.id).notNull(),
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      accessRequestId: uuid("access_request_id").references(() => patientAccessRequests.id),
      // Action Information  
      actionType: text("action_type").notNull(),
      // view, edit, create, delete
      resourceType: text("resource_type").notNull(),
      // medical_record, billing, appointment, prescription
      resourceId: text("resource_id"),
      // Context
      ipAddress: text("ip_address"),
      userAgent: text("user_agent"),
      accessMethod: text("access_method").default("direct").notNull(),
      // direct, requested, emergency
      // Metadata
      accessedAt: timestamp("accessed_at").default(sql`CURRENT_TIMESTAMP`)
    });
    phraseTranslations = pgTable("phrase_translations", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      phraseId: uuid("phrase_id").references(() => medicalPhrases.id).notNull(),
      languageCode: text("language_code").notNull(),
      translatedText: text("translated_text").notNull(),
      translatedBy: uuid("translated_by").references(() => users.id),
      verifiedBy: uuid("verified_by").references(() => users.id),
      isVerified: boolean("is_verified").default(false),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    pharmacies = pgTable("pharmacies", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      name: text("name").notNull(),
      licenseNumber: text("license_number"),
      npiNumber: text("npi_number"),
      // National Provider Identifier
      contactPerson: text("contact_person"),
      phone: text("phone").notNull(),
      email: text("email"),
      faxNumber: text("fax_number"),
      address: jsonb("address").notNull().$type(),
      isActive: boolean("is_active").default(true),
      acceptsInsurance: boolean("accepts_insurance").default(true),
      deliveryService: boolean("delivery_service").default(false),
      operatingHours: jsonb("operating_hours").$type(),
      specializations: text("specializations").array().default([]),
      // specialty medications, compounding, etc.
      websiteUrl: text("website_url"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    laboratories = pgTable("laboratories", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      name: text("name").notNull(),
      licenseNumber: text("license_number"),
      contactPerson: text("contact_person"),
      phone: text("phone"),
      email: text("email"),
      address: jsonb("address").$type(),
      specializations: text("specializations").array(),
      isActive: boolean("is_active").default(true),
      apiEndpoint: text("api_endpoint"),
      // For external lab integration
      apiKey: text("api_key"),
      // Encrypted API key for lab integration
      averageTurnaroundTime: integer("average_turnaround_time"),
      // Hours
      isExternal: boolean("is_external").default(false),
      // true for external labs registering on platform
      registrationStatus: text("registration_status").default("approved"),
      // pending, approved, rejected
      registrationNotes: text("registration_notes"),
      approvedBy: uuid("approved_by").references(() => users.id),
      approvedAt: timestamp("approved_at"),
      websiteUrl: text("website_url"),
      accreditations: text("accreditations").array().default([]),
      operatingHours: jsonb("operating_hours").$type(),
      servicesOffered: text("services_offered").array().default([]),
      equipmentDetails: text("equipment_details"),
      certificationDocuments: text("certification_documents").array().default([]),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    laboratoryApplications = pgTable("laboratory_applications", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      laboratoryName: text("laboratory_name").notNull(),
      licenseNumber: text("license_number").notNull(),
      contactPerson: text("contact_person").notNull(),
      contactEmail: text("contact_email").notNull(),
      contactPhone: text("contact_phone").notNull(),
      address: jsonb("address").notNull().$type(),
      specializations: text("specializations").array().notNull().default([]),
      description: text("description"),
      websiteUrl: text("website_url"),
      accreditations: text("accreditations").array().default([]),
      averageTurnaroundTime: integer("average_turnaround_time").default(24),
      operatingHours: jsonb("operating_hours").$type(),
      servicesOffered: text("services_offered").array().default([]),
      equipmentDetails: text("equipment_details"),
      certificationDocuments: text("certification_documents").array().default([]),
      status: text("status").default("pending"),
      // pending, under_review, approved, rejected
      reviewNotes: text("review_notes"),
      reviewedBy: uuid("reviewed_by").references(() => users.id),
      reviewedAt: timestamp("reviewed_at"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    pendingRegistrations = pgTable("pending_registrations", {
      id: text("id").primaryKey().default(nanoid()),
      type: text("type").notNull(),
      // 'pharmacy', 'laboratory', 'hospital', 'clinic'
      organizationName: text("organization_name").notNull(),
      subdomain: text("subdomain").notNull(),
      contactEmail: text("contact_email").notNull(),
      contactPhone: text("contact_phone"),
      // Registration Data (JSON blob containing all form data)
      registrationData: jsonb("registration_data").notNull(),
      // Admin User Data
      adminData: jsonb("admin_data").notNull(),
      // Status Management
      status: text("status").notNull().default("pending"),
      // pending, approved, rejected
      submittedAt: timestamp("submitted_at").default(sql`CURRENT_TIMESTAMP`),
      reviewedAt: timestamp("reviewed_at"),
      reviewedBy: uuid("reviewed_by").references(() => users.id),
      // User ID of reviewer
      reviewNotes: text("review_notes"),
      // Tenant ID (populated after approval)
      approvedTenantId: uuid("approved_tenant_id").references(() => tenants.id),
      approvedUserId: uuid("approved_user_id").references(() => users.id),
      // Metadata
      ipAddress: text("ip_address"),
      userAgent: text("user_agent"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    labResults = pgTable("lab_results", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      labOrderId: uuid("lab_order_id").references(() => labOrders.id).notNull(),
      laboratoryId: uuid("laboratory_id").references(() => laboratories.id).notNull(),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      testName: text("test_name").notNull(),
      result: text("result"),
      normalRange: text("normal_range"),
      unit: text("unit"),
      status: text("status").notNull().default("pending"),
      // pending, in_progress, completed, cancelled
      abnormalFlag: text("abnormal_flag"),
      // normal, high, low, critical
      notes: text("notes"),
      performedBy: text("performed_by"),
      // Lab technician name
      reviewedBy: uuid("reviewed_by").references(() => users.id),
      // Doctor who reviewed
      completedAt: timestamp("completed_at"),
      reportedAt: timestamp("reported_at"),
      externalLabId: text("external_lab_id"),
      // ID from external lab system
      rawData: jsonb("raw_data"),
      // Raw data from lab system
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    pricingPlans = pgTable("pricing_plans", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      name: text("name").notNull(),
      // Starter, Professional, Enterprise, White Label
      plan: subscriptionPlanEnum("plan").notNull(),
      displayName: text("display_name").notNull(),
      description: text("description"),
      monthlyPrice: decimal("monthly_price", { precision: 10, scale: 2 }).notNull(),
      yearlyPrice: decimal("yearly_price", { precision: 10, scale: 2 }),
      currency: text("currency").default("USD"),
      trialDays: integer("trial_days").default(14),
      // Feature limits
      maxUsers: integer("max_users").default(5),
      maxPatients: integer("max_patients").default(100),
      maxStorageGb: integer("max_storage_gb").default(1),
      apiCallsPerMonth: integer("api_calls_per_month").default(1e3),
      // Feature flags
      whitelabelEnabled: boolean("whitelabel_enabled").default(false),
      offlineEnabled: boolean("offline_enabled").default(false),
      multiLanguageEnabled: boolean("multi_language_enabled").default(false),
      advancedReportsEnabled: boolean("advanced_reports_enabled").default(false),
      customIntegrationsEnabled: boolean("custom_integrations_enabled").default(false),
      prioritySupport: boolean("priority_support").default(false),
      isActive: boolean("is_active").default(true),
      sortOrder: integer("sort_order").default(0),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    pharmacyReceipts = pgTable("pharmacy_receipts", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      // Pharmacy tenant
      prescriptionId: uuid("prescription_id").references(() => prescriptions.id).notNull(),
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      // Receipt Details
      receiptNumber: text("receipt_number").notNull().unique(),
      dispensedBy: uuid("dispensed_by").references(() => users.id).notNull(),
      // Pharmacist who dispensed
      // Medication Information
      medicationName: text("medication_name").notNull(),
      genericName: text("generic_name"),
      dosage: text("dosage").notNull(),
      quantity: integer("quantity").notNull(),
      daysSupply: integer("days_supply"),
      // Pricing Breakdown
      totalCost: decimal("total_cost", { precision: 10, scale: 2 }).notNull(),
      insuranceProvider: text("insurance_provider"),
      insuranceAmount: decimal("insurance_amount", { precision: 10, scale: 2 }).default("0"),
      patientCopay: decimal("patient_copay", { precision: 10, scale: 2 }).notNull(),
      // Payment Information
      paymentMethod: text("payment_method").notNull(),
      // cash, card, check, etc.
      paymentAmount: decimal("payment_amount", { precision: 10, scale: 2 }).notNull(),
      changeGiven: decimal("change_given", { precision: 10, scale: 2 }).default("0"),
      // Prescription Details
      prescribedBy: text("prescribed_by").notNull(),
      // Doctor name
      prescribedDate: timestamp("prescribed_date").notNull(),
      dispensedDate: timestamp("dispensed_date").notNull(),
      refillsRemaining: integer("refills_remaining").default(0),
      // Receipt Notes
      pharmacyNotes: text("pharmacy_notes"),
      patientInstructions: text("patient_instructions"),
      // Status
      isPrinted: boolean("is_printed").default(false),
      isEmailed: boolean("is_emailed").default(false),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    labBills = pgTable("lab_bills", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      // Laboratory tenant
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      // Bill Details
      amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
      description: text("description").notNull(),
      status: text("status").default("pending").notNull(),
      // pending, paid, overdue, cancelled
      serviceType: text("service_type").default("laboratory_test").notNull(),
      // Lab Order Reference
      labOrderId: uuid("lab_order_id").references(() => labOrders.id),
      testName: text("test_name"),
      // Additional Information
      notes: text("notes"),
      generatedBy: uuid("generated_by").references(() => users.id).notNull(),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    hospitalBills = pgTable("hospital_bills", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      // Hospital tenant
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      appointmentId: uuid("appointment_id").references(() => appointments.id),
      // Bill Details
      billNumber: text("bill_number").notNull().unique(),
      amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
      description: text("description").notNull(),
      status: billStatusEnum("status").default("pending").notNull(),
      serviceType: serviceTypeEnum("service_type").notNull(),
      // Insurance Information
      insuranceProvider: text("insurance_provider"),
      insuranceAmount: decimal("insurance_amount", { precision: 10, scale: 2 }).default("0"),
      patientCopay: decimal("patient_copay", { precision: 10, scale: 2 }).notNull(),
      // Additional Information
      procedureCodes: text("procedure_codes").array().default([]),
      diagnosisCodes: text("diagnosis_codes").array().default([]),
      notes: text("notes"),
      generatedBy: uuid("generated_by").references(() => users.id).notNull(),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    pharmacyBills = pgTable("pharmacy_bills", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      // Pharmacy tenant
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      prescriptionId: uuid("prescription_id").references(() => prescriptions.id),
      // Bill Details
      billNumber: text("bill_number").notNull().unique(),
      amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
      description: text("description").notNull(),
      status: billStatusEnum("status").default("pending").notNull(),
      // Medication Information
      medicationName: text("medication_name").notNull(),
      quantity: integer("quantity").notNull(),
      unitPrice: decimal("unit_price", { precision: 10, scale: 2 }).notNull(),
      // Insurance Information
      insuranceProvider: text("insurance_provider"),
      insuranceAmount: decimal("insurance_amount", { precision: 10, scale: 2 }).default("0"),
      patientCopay: decimal("patient_copay", { precision: 10, scale: 2 }).notNull(),
      // Additional Information
      notes: text("notes"),
      generatedBy: uuid("generated_by").references(() => users.id).notNull(),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    financialTransactions = pgTable("financial_transactions", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      // Transaction Identification
      transactionNumber: text("transaction_number").notNull().unique(),
      transactionType: text("transaction_type").notNull(),
      // payment, refund, adjustment, fee, copay, insurance_payment
      category: text("category").notNull(),
      // pharmacy_sale, hospital_service, lab_test, insurance_claim
      // Financial Details
      amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
      currency: currencyEnum("currency").notNull().default("USD"),
      description: text("description").notNull(),
      // Related Entities
      patientId: uuid("patient_id").references(() => patients.id),
      billId: uuid("bill_id"),
      // References any bill (hospital, pharmacy, lab)
      receiptId: uuid("receipt_id"),
      // References any receipt
      paymentId: uuid("payment_id"),
      // References payment records
      // Payment Method Details
      paymentMethod: text("payment_method"),
      // cash, card, check, insurance, online
      paymentReference: text("payment_reference"),
      // transaction ID, check number, etc.
      // Accounting Categories
      accountCode: text("account_code"),
      // Chart of accounts code
      debitAccount: text("debit_account"),
      // Account being debited
      creditAccount: text("credit_account"),
      // Account being credited
      // Status and Dates
      status: text("status").notNull().default("completed"),
      // pending, completed, reversed, failed
      transactionDate: timestamp("transaction_date").notNull(),
      postedDate: timestamp("posted_date"),
      // Audit Trail
      recordedBy: uuid("recorded_by").references(() => users.id).notNull(),
      approvedBy: uuid("approved_by").references(() => users.id),
      // Additional Information
      notes: text("notes"),
      metadata: jsonb("metadata"),
      // Additional transaction-specific data
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    offlineSyncData = pgTable("offline_sync_data", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      userId: uuid("user_id").references(() => users.id).notNull(),
      entityType: text("entity_type").notNull(),
      // patients, appointments, prescriptions, etc.
      entityId: uuid("entity_id").notNull(),
      action: text("action").notNull(),
      // create, update, delete
      data: jsonb("data").notNull(),
      timestamp: timestamp("timestamp").default(sql`CURRENT_TIMESTAMP`),
      syncedAt: timestamp("synced_at"),
      conflictResolved: boolean("conflict_resolved").default(false),
      deviceId: text("device_id"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`)
    });
    translations = pgTable("translations", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id),
      key: text("key").notNull(),
      // translation key like "dashboard.welcome"
      language: varchar("language", { length: 10 }).notNull(),
      // en, es, fr, etc.
      value: text("value").notNull(),
      // translated text
      context: text("context"),
      // additional context for translators
      isDefault: boolean("is_default").default(false),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    labOrderAssignments = pgTable("lab_order_assignments", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      labOrderId: uuid("lab_order_id").references(() => labOrders.id).notNull(),
      laboratoryId: uuid("laboratory_id").references(() => laboratories.id).notNull(),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      assignedBy: uuid("assigned_by").references(() => users.id).notNull(),
      status: text("status").notNull().default("assigned"),
      // assigned, sent, received, processing, completed
      sentAt: timestamp("sent_at"),
      estimatedCompletionTime: timestamp("estimated_completion_time"),
      actualCompletionTime: timestamp("actual_completion_time"),
      trackingNumber: text("tracking_number"),
      // For tracking samples
      notes: text("notes"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    vitalSigns = pgTable("vital_signs", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      appointmentId: uuid("appointment_id").references(() => appointments.id),
      recordedBy: uuid("recorded_by_id").references(() => users.id).notNull(),
      // receptionist/nurse
      // Standard vital signs
      systolicBp: integer("blood_pressure_systolic"),
      // mmHg
      diastolicBp: integer("blood_pressure_diastolic"),
      // mmHg
      heartRate: integer("heart_rate"),
      // bpm
      temperature: decimal("temperature", { precision: 4, scale: 1 }),
      // °F or °C
      temperatureUnit: text("temperature_unit").default("F"),
      // F or C
      respiratoryRate: integer("respiratory_rate"),
      // breaths per minute
      oxygenSaturation: integer("oxygen_saturation"),
      // %
      weight: decimal("weight", { precision: 5, scale: 2 }),
      // lbs or kg
      height: decimal("height", { precision: 5, scale: 2 }),
      // inches or cm
      bmi: decimal("body_mass_index", { precision: 4, scale: 1 }),
      // calculated
      painLevel: integer("pain_level"),
      // 0-10 scale
      // Additional measurements
      glucoseLevel: integer("glucose_level"),
      // mg/dL
      notes: text("notes"),
      recordedAt: timestamp("recorded_at").default(sql`CURRENT_TIMESTAMP`),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    specialtyQuestionnaires = pgTable("specialty_questionnaires", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      appointmentId: uuid("appointment_id").references(() => appointments.id),
      specialty: medicalSpecialtyEnum("specialty").notNull(),
      completedBy: uuid("completed_by").references(() => users.id).notNull(),
      // receptionist/nurse
      // Questionnaire responses stored as JSON
      responses: jsonb("responses").notNull().$type(),
      chiefComplaint: text("chief_complaint"),
      symptoms: text("symptoms").array().default([]),
      symptomDuration: text("symptom_duration"),
      severity: integer("severity"),
      // 1-10 scale
      previousTreatments: text("previous_treatments"),
      currentMedications: text("current_medications").array().default([]),
      allergies: text("allergies").array().default([]),
      familyHistory: text("family_history"),
      socialHistory: text("social_history"),
      reviewOfSystems: jsonb("review_of_systems").default("{}"),
      additionalNotes: text("additional_notes"),
      isComplete: boolean("is_complete").default(false),
      completedAt: timestamp("completed_at"),
      reviewedBy: uuid("reviewed_by").references(() => users.id),
      // doctor who reviewed
      reviewedAt: timestamp("reviewed_at"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    patientCheckIns = pgTable("patient_check_ins", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      appointmentId: uuid("appointment_id").references(() => appointments.id),
      checkedInBy: uuid("checked_in_by").references(() => users.id).notNull(),
      // receptionist
      checkedInAt: timestamp("checked_in_at").default(sql`CURRENT_TIMESTAMP`),
      reasonForVisit: text("reason_for_visit").notNull(),
      chiefComplaint: text("chief_complaint"),
      priorityLevel: text("priority_level", { enum: ["low", "normal", "high", "urgent", "emergency"] }).default("normal"),
      specialInstructions: text("special_instructions"),
      accompaniedBy: text("accompanied_by"),
      insuranceVerified: boolean("insurance_verified").default(false),
      copayCollected: decimal("copay_collected", { precision: 10, scale: 2 }),
      estimatedWaitTime: integer("estimated_wait_time"),
      // minutes
      vitalSignsId: uuid("vital_signs_id").references(() => vitalSigns.id),
      questionnaireId: uuid("questionnaire_id").references(() => specialtyQuestionnaires.id),
      status: text("status", { enum: ["waiting", "in-room", "with-provider", "completed", "cancelled"] }).default("waiting"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    patientBills = pgTable("patient_bills", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      billNumber: text("bill_number").notNull().unique(),
      description: text("description").notNull(),
      serviceDate: timestamp("service_date").notNull(),
      dueDate: timestamp("due_date").notNull(),
      currency: currencyEnum("currency").notNull().default("USD"),
      originalAmount: decimal("original_amount", { precision: 10, scale: 2 }).notNull(),
      paidAmount: decimal("paid_amount", { precision: 10, scale: 2 }).default("0"),
      remainingBalance: decimal("remaining_balance", { precision: 10, scale: 2 }).notNull(),
      status: billStatusEnum("status").notNull().default("pending"),
      appointmentId: uuid("appointment_id").references(() => appointments.id),
      prescriptionId: uuid("prescription_id").references(() => prescriptions.id),
      labOrderId: uuid("lab_order_id").references(() => labOrders.id),
      servicePriceId: uuid("service_price_id").references(() => servicePrices.id),
      insuranceClaimId: uuid("insurance_claim_id").references(() => insuranceClaims.id),
      insuranceCovered: decimal("insurance_covered", { precision: 10, scale: 2 }).default("0"),
      patientResponsibility: decimal("patient_responsibility", { precision: 10, scale: 2 }).notNull(),
      notes: text("notes"),
      lateFeesApplied: decimal("late_fees_applied", { precision: 10, scale: 2 }).default("0"),
      discountApplied: decimal("discount_applied", { precision: 10, scale: 2 }).default("0"),
      paymentTerms: text("payment_terms"),
      // "Net 30", "Due on receipt", etc.
      lastReminderSent: timestamp("last_reminder_sent"),
      reminderCount: integer("reminder_count").default(0),
      createdBy: uuid("created_by").references(() => users.id).notNull(),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    patientPayments = pgTable("patient_payments", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      patientBillId: uuid("patient_bill_id").references(() => patientBills.id).notNull(),
      patientId: uuid("patient_id").references(() => patients.id).notNull(),
      currency: currencyEnum("currency").notNull().default("USD"),
      amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
      paymentMethod: text("payment_method").notNull(),
      // cash, check, credit_card, bank_transfer, online
      paymentReference: text("payment_reference"),
      // transaction ID, check number, etc.
      paymentDate: timestamp("payment_date").notNull(),
      processedBy: uuid("processed_by").references(() => users.id),
      notes: text("notes"),
      refundAmount: decimal("refund_amount", { precision: 10, scale: 2 }).default("0"),
      refundDate: timestamp("refund_date"),
      refundReason: text("refund_reason"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    achievements = pgTable("achievements", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      name: text("name").notNull(),
      description: text("description").notNull(),
      type: achievementTypeEnum("type").notNull(),
      difficulty: achievementDifficultyEnum("difficulty").notNull(),
      points: integer("points").notNull().default(0),
      iconName: text("icon_name").notNull(),
      // Lucide icon name
      criteria: jsonb("criteria").notNull(),
      // JSON criteria for achievement
      isActive: boolean("is_active").default(true),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    userAchievements = pgTable("user_achievements", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: uuid("user_id").references(() => users.id).notNull(),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      achievementId: uuid("achievement_id").references(() => achievements.id).notNull(),
      progress: integer("progress").default(0),
      // Current progress toward achievement
      maxProgress: integer("max_progress").notNull(),
      // Target progress to complete
      isCompleted: boolean("is_completed").default(false),
      completedAt: timestamp("completed_at"),
      earnedAt: timestamp("earned_at").default(sql`CURRENT_TIMESTAMP`)
    });
    userStats = pgTable("user_stats", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: uuid("user_id").references(() => users.id).notNull(),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      level: integer("level").default(1),
      totalPoints: integer("total_points").default(0),
      testsCompleted: integer("tests_completed").default(0),
      averageCompletionTime: integer("average_completion_time").default(0),
      // in minutes
      qualityScore: decimal("quality_score", { precision: 5, scale: 2 }).default("0.00"),
      // 0-100
      consistencyStreak: integer("consistency_streak").default(0),
      // days
      lastActivityDate: timestamp("last_activity_date"),
      weeklyGoal: integer("weekly_goal").default(50),
      // weekly test completion goal
      monthlyGoal: integer("monthly_goal").default(200),
      // monthly test completion goal
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    leaderboards = pgTable("leaderboards", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      userId: uuid("user_id").references(() => users.id).notNull(),
      userName: text("user_name").notNull(),
      position: integer("position").notNull(),
      points: integer("points").notNull(),
      level: integer("level").notNull(),
      testsCompleted: integer("tests_completed").notNull(),
      qualityScore: decimal("quality_score", { precision: 5, scale: 2 }).notNull(),
      period: text("period").notNull(),
      // daily, weekly, monthly, all-time
      periodStart: timestamp("period_start").notNull(),
      periodEnd: timestamp("period_end").notNull(),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`)
    });
    activityLogs = pgTable("activity_logs", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: uuid("user_id").references(() => users.id).notNull(),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      activityType: text("activity_type").notNull(),
      // lab_test_completed, achievement_earned, streak_milestone, etc.
      points: integer("points").default(0),
      metadata: jsonb("metadata"),
      // Additional activity-specific data
      timestamp: timestamp("timestamp").default(sql`CURRENT_TIMESTAMP`)
    });
    medicalSuppliers = pgTable("medical_suppliers", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      companyName: text("company_name").notNull(),
      organizationSlug: text("organization_slug").notNull().unique(),
      // URL-friendly unique identifier for authentication
      businessType: text("business_type").notNull(),
      contactPersonName: text("contact_person_name").notNull(),
      contactEmail: text("contact_email").notNull(),
      contactPhone: text("contact_phone").notNull(),
      websiteUrl: text("website_url"),
      businessAddress: text("business_address").notNull(),
      city: text("city").notNull(),
      state: text("state").notNull(),
      country: text("country").notNull(),
      zipCode: text("zip_code").notNull(),
      businessDescription: text("business_description").notNull(),
      productCategories: text("product_categories").array().default([]),
      yearsInBusiness: text("years_in_business").notNull(),
      numberOfEmployees: text("number_of_employees").notNull(),
      annualRevenue: text("annual_revenue").notNull(),
      certifications: text("certifications").array().default([]),
      // Authentication credentials for supplier login
      username: text("username").notNull().unique(),
      passwordHash: text("password_hash").notNull(),
      status: supplierStatusEnum("status").default("pending_review").notNull(),
      termsAccepted: boolean("terms_accepted").notNull(),
      marketingConsent: boolean("marketing_consent").default(false),
      tenantId: uuid("tenant_id").references(() => tenants.id),
      // Will be set when approved
      approvedBy: uuid("approved_by").references(() => users.id),
      approvedAt: timestamp("approved_at"),
      rejectionReason: text("rejection_reason"),
      rejectedAt: timestamp("rejected_at"),
      notes: text("notes"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    departmentsRelations = relations(departments, ({ one }) => ({
      tenant: one(tenants, {
        fields: [departments.tenantId],
        references: [tenants.id]
      }),
      headOfDepartment: one(users, {
        fields: [departments.headOfDepartment],
        references: [users.id]
      })
    }));
    tenantsRelations = relations(tenants, ({ one, many }) => ({
      country: one(countries, {
        fields: [tenants.countryId],
        references: [countries.id]
      }),
      users: many(users),
      patients: many(patients),
      appointments: many(appointments),
      prescriptions: many(prescriptions),
      labOrders: many(labOrders),
      insuranceClaims: many(insuranceClaims),
      insuranceProviders: many(insuranceProviders),
      patientInsurance: many(patientInsurance),
      servicePrices: many(servicePrices),
      insurancePlanCoverage: many(insurancePlanCoverage),
      claimLineItems: many(claimLineItems),
      medicationCopays: many(medicationCopays),
      auditLogs: many(auditLogs),
      subscription: one(subscriptions),
      reports: many(reports),
      laboratories: many(laboratories),
      labResults: many(labResults),
      labOrderAssignments: many(labOrderAssignments),
      vitalSigns: many(vitalSigns),
      visitSummaries: many(visitSummaries),
      patientCheckIns: many(patientCheckIns),
      patientBills: many(patientBills),
      patientPayments: many(patientPayments),
      hospitalBills: many(hospitalBills),
      pharmacyBills: many(pharmacyBills),
      financialTransactions: many(financialTransactions),
      userAchievements: many(userAchievements),
      userStats: many(userStats),
      leaderboards: many(leaderboards),
      activityLogs: many(activityLogs),
      departments: many(departments)
    }));
    insuranceProvidersRelations = relations(insuranceProviders, ({ one, many }) => ({
      tenant: one(tenants, {
        fields: [insuranceProviders.tenantId],
        references: [tenants.id]
      }),
      patientInsurance: many(patientInsurance),
      coverages: many(insurancePlanCoverage)
    }));
    patientInsuranceRelations = relations(patientInsurance, ({ one, many }) => ({
      tenant: one(tenants, {
        fields: [patientInsurance.tenantId],
        references: [tenants.id]
      }),
      patient: one(patients, {
        fields: [patientInsurance.patientId],
        references: [patients.id]
      }),
      insuranceProvider: one(insuranceProviders, {
        fields: [patientInsurance.insuranceProviderId],
        references: [insuranceProviders.id]
      }),
      claims: many(insuranceClaims),
      medicationCopays: many(medicationCopays)
    }));
    servicePricesRelations = relations(servicePrices, ({ one, many }) => ({
      tenant: one(tenants, {
        fields: [servicePrices.tenantId],
        references: [tenants.id]
      }),
      coverages: many(insurancePlanCoverage),
      claimLineItems: many(claimLineItems)
    }));
    insurancePlanCoverageRelations = relations(insurancePlanCoverage, ({ one }) => ({
      tenant: one(tenants, {
        fields: [insurancePlanCoverage.tenantId],
        references: [tenants.id]
      }),
      insuranceProvider: one(insuranceProviders, {
        fields: [insurancePlanCoverage.insuranceProviderId],
        references: [insuranceProviders.id]
      }),
      servicePrice: one(servicePrices, {
        fields: [insurancePlanCoverage.servicePriceId],
        references: [servicePrices.id]
      })
    }));
    claimLineItemsRelations = relations(claimLineItems, ({ one }) => ({
      tenant: one(tenants, {
        fields: [claimLineItems.tenantId],
        references: [tenants.id]
      }),
      claim: one(insuranceClaims, {
        fields: [claimLineItems.claimId],
        references: [insuranceClaims.id]
      }),
      servicePrice: one(servicePrices, {
        fields: [claimLineItems.servicePriceId],
        references: [servicePrices.id]
      })
    }));
    insuranceClaimsRelations = relations(insuranceClaims, ({ one, many }) => ({
      tenant: one(tenants, {
        fields: [insuranceClaims.tenantId],
        references: [tenants.id]
      }),
      patient: one(patients, {
        fields: [insuranceClaims.patientId],
        references: [patients.id]
      }),
      appointment: one(appointments, {
        fields: [insuranceClaims.appointmentId],
        references: [appointments.id]
      }),
      patientInsurance: one(patientInsurance, {
        fields: [insuranceClaims.patientInsuranceId],
        references: [patientInsurance.id]
      }),
      lineItems: many(claimLineItems)
    }));
    subscriptionsRelations = relations(subscriptions, ({ one }) => ({
      tenant: one(tenants, {
        fields: [subscriptions.tenantId],
        references: [tenants.id]
      })
    }));
    reportsRelations = relations(reports, ({ one }) => ({
      tenant: one(tenants, {
        fields: [reports.tenantId],
        references: [tenants.id]
      }),
      generatedByUser: one(users, {
        fields: [reports.generatedBy],
        references: [users.id]
      })
    }));
    medicalCommunicationsRelations = relations(medicalCommunications, ({ one, many }) => ({
      tenant: one(tenants, {
        fields: [medicalCommunications.tenantId],
        references: [tenants.id]
      }),
      patient: one(patients, {
        fields: [medicalCommunications.patientId],
        references: [patients.id]
      }),
      sender: one(users, {
        fields: [medicalCommunications.senderId],
        references: [users.id],
        relationName: "senderCommunications"
      }),
      recipient: one(users, {
        fields: [medicalCommunications.recipientId],
        references: [users.id],
        relationName: "recipientCommunications"
      }),
      appointment: one(appointments, {
        fields: [medicalCommunications.appointmentId],
        references: [appointments.id]
      }),
      prescription: one(prescriptions, {
        fields: [medicalCommunications.prescriptionId],
        references: [prescriptions.id]
      }),
      labOrder: one(labOrders, {
        fields: [medicalCommunications.labOrderId],
        references: [labOrders.id]
      }),
      translations: many(communicationTranslations)
    }));
    communicationTranslationsRelations = relations(communicationTranslations, ({ one }) => ({
      communication: one(medicalCommunications, {
        fields: [communicationTranslations.communicationId],
        references: [medicalCommunications.id]
      }),
      reviewedByUser: one(users, {
        fields: [communicationTranslations.reviewedBy],
        references: [users.id]
      })
    }));
    supportedLanguagesRelations = relations(supportedLanguages, ({ one }) => ({
      tenant: one(tenants, {
        fields: [supportedLanguages.tenantId],
        references: [tenants.id]
      })
    }));
    medicalPhrasesRelations = relations(medicalPhrases, ({ one, many }) => ({
      tenant: one(tenants, {
        fields: [medicalPhrases.tenantId],
        references: [tenants.id]
      }),
      translations: many(phraseTranslations)
    }));
    phraseTranslationsRelations = relations(phraseTranslations, ({ one }) => ({
      phrase: one(medicalPhrases, {
        fields: [phraseTranslations.phraseId],
        references: [medicalPhrases.id]
      }),
      translatedByUser: one(users, {
        fields: [phraseTranslations.translatedBy],
        references: [users.id],
        relationName: "translatedPhrases"
      }),
      verifiedByUser: one(users, {
        fields: [phraseTranslations.verifiedBy],
        references: [users.id],
        relationName: "verifiedPhrases"
      })
    }));
    usersRelations = relations(users, ({ one, many }) => ({
      tenant: one(tenants, {
        fields: [users.tenantId],
        references: [tenants.id]
      }),
      appointmentsAsProvider: many(appointments, { relationName: "providerAppointments" }),
      prescriptions: many(prescriptions),
      labOrders: many(labOrders),
      auditLogs: many(auditLogs),
      labResults: many(labResults),
      labOrderAssignments: many(labOrderAssignments),
      vitalSignsRecorded: many(vitalSigns, { relationName: "recordedBy" }),
      visitSummariesAsProvider: many(visitSummaries, { relationName: "providerSummaries" }),
      medicationCopaysAsDefined: many(medicationCopays, { relationName: "pharmacistCopays" }),
      userAchievements: many(userAchievements),
      userStats: many(userStats),
      leaderboards: many(leaderboards),
      activityLogs: many(activityLogs)
    }));
    pharmaciesRelations = relations(pharmacies, ({ one, many }) => ({
      tenant: one(tenants, {
        fields: [pharmacies.tenantId],
        references: [tenants.id]
      }),
      patients: many(patients)
    }));
    patientsRelations = relations(patients, ({ one, many }) => ({
      tenant: one(tenants, {
        fields: [patients.tenantId],
        references: [tenants.id]
      }),
      preferredPharmacy: one(pharmacies, {
        fields: [patients.preferredPharmacyId],
        references: [pharmacies.id]
      }),
      appointments: many(appointments),
      prescriptions: many(prescriptions),
      labOrders: many(labOrders),
      insuranceClaims: many(insuranceClaims),
      labResults: many(labResults),
      vitalSigns: many(vitalSigns),
      medicationCopays: many(medicationCopays),
      visitSummaries: many(visitSummaries),
      patientBills: many(patientBills),
      patientPayments: many(patientPayments)
    }));
    laboratoriesRelations = relations(laboratories, ({ one, many }) => ({
      tenant: one(tenants, {
        fields: [laboratories.tenantId],
        references: [tenants.id]
      }),
      labResults: many(labResults),
      labOrderAssignments: many(labOrderAssignments),
      approvedByUser: one(users, {
        fields: [laboratories.approvedBy],
        references: [users.id]
      })
    }));
    laboratoryApplicationsRelations = relations(laboratoryApplications, ({ one }) => ({
      reviewedByUser: one(users, {
        fields: [laboratoryApplications.reviewedBy],
        references: [users.id]
      })
    }));
    labResultsRelations = relations(labResults, ({ one }) => ({
      tenant: one(tenants, {
        fields: [labResults.tenantId],
        references: [tenants.id]
      }),
      patient: one(patients, {
        fields: [labResults.patientId],
        references: [patients.id]
      }),
      labOrder: one(labOrders, {
        fields: [labResults.labOrderId],
        references: [labOrders.id]
      }),
      laboratory: one(laboratories, {
        fields: [labResults.laboratoryId],
        references: [laboratories.id]
      }),
      reviewedByUser: one(users, {
        fields: [labResults.reviewedBy],
        references: [users.id]
      })
    }));
    labOrderAssignmentsRelations = relations(labOrderAssignments, ({ one }) => ({
      tenant: one(tenants, {
        fields: [labOrderAssignments.tenantId],
        references: [tenants.id]
      }),
      labOrder: one(labOrders, {
        fields: [labOrderAssignments.labOrderId],
        references: [labOrders.id]
      }),
      laboratory: one(laboratories, {
        fields: [labOrderAssignments.laboratoryId],
        references: [laboratories.id]
      }),
      assignedByUser: one(users, {
        fields: [labOrderAssignments.assignedBy],
        references: [users.id]
      })
    }));
    appointmentsRelations = relations(appointments, ({ one, many }) => ({
      tenant: one(tenants, {
        fields: [appointments.tenantId],
        references: [tenants.id]
      }),
      patient: one(patients, {
        fields: [appointments.patientId],
        references: [patients.id]
      }),
      provider: one(users, {
        fields: [appointments.providerId],
        references: [users.id],
        relationName: "providerAppointments"
      }),
      prescriptions: many(prescriptions),
      labOrders: many(labOrders),
      insuranceClaims: many(insuranceClaims),
      vitalSigns: many(vitalSigns),
      visitSummaries: many(visitSummaries)
    }));
    vitalSignsRelations = relations(vitalSigns, ({ one }) => ({
      tenant: one(tenants, {
        fields: [vitalSigns.tenantId],
        references: [tenants.id]
      }),
      patient: one(patients, {
        fields: [vitalSigns.patientId],
        references: [patients.id]
      }),
      appointment: one(appointments, {
        fields: [vitalSigns.appointmentId],
        references: [appointments.id]
      }),
      recordedBy: one(users, {
        fields: [vitalSigns.recordedBy],
        references: [users.id],
        relationName: "recordedBy"
      })
    }));
    patientCheckInsRelations = relations(patientCheckIns, ({ one }) => ({
      tenant: one(tenants, {
        fields: [patientCheckIns.tenantId],
        references: [tenants.id]
      }),
      patient: one(patients, {
        fields: [patientCheckIns.patientId],
        references: [patients.id]
      }),
      appointment: one(appointments, {
        fields: [patientCheckIns.appointmentId],
        references: [appointments.id]
      }),
      vitalSigns: one(vitalSigns, {
        fields: [patientCheckIns.vitalSignsId],
        references: [vitalSigns.id]
      }),
      questionnaire: one(specialtyQuestionnaires, {
        fields: [patientCheckIns.questionnaireId],
        references: [specialtyQuestionnaires.id]
      }),
      checkedInBy: one(users, {
        fields: [patientCheckIns.checkedInBy],
        references: [users.id],
        relationName: "checkedInBy"
      })
    }));
    medicationCopaysRelations = relations(medicationCopays, ({ one }) => ({
      tenant: one(tenants, {
        fields: [medicationCopays.tenantId],
        references: [tenants.id]
      }),
      patient: one(patients, {
        fields: [medicationCopays.patientId],
        references: [patients.id]
      }),
      patientInsurance: one(patientInsurance, {
        fields: [medicationCopays.patientInsuranceId],
        references: [patientInsurance.id]
      }),
      prescription: one(prescriptions, {
        fields: [medicationCopays.prescriptionId],
        references: [prescriptions.id]
      }),
      definedBy: one(users, {
        fields: [medicationCopays.definedByPharmacist],
        references: [users.id],
        relationName: "pharmacistCopays"
      })
    }));
    visitSummariesRelations = relations(visitSummaries, ({ one }) => ({
      tenant: one(tenants, {
        fields: [visitSummaries.tenantId],
        references: [tenants.id]
      }),
      patient: one(patients, {
        fields: [visitSummaries.patientId],
        references: [patients.id]
      }),
      appointment: one(appointments, {
        fields: [visitSummaries.appointmentId],
        references: [appointments.id]
      }),
      provider: one(users, {
        fields: [visitSummaries.providerId],
        references: [users.id],
        relationName: "providerSummaries"
      }),
      vitalSigns: one(vitalSigns, {
        fields: [visitSummaries.vitalSignsId],
        references: [vitalSigns.id]
      })
    }));
    patientBillsRelations = relations(patientBills, ({ one, many }) => ({
      tenant: one(tenants, {
        fields: [patientBills.tenantId],
        references: [tenants.id]
      }),
      patient: one(patients, {
        fields: [patientBills.patientId],
        references: [patients.id]
      }),
      appointment: one(appointments, {
        fields: [patientBills.appointmentId],
        references: [appointments.id]
      }),
      prescription: one(prescriptions, {
        fields: [patientBills.prescriptionId],
        references: [prescriptions.id]
      }),
      labOrder: one(labOrders, {
        fields: [patientBills.labOrderId],
        references: [labOrders.id]
      }),
      servicePrice: one(servicePrices, {
        fields: [patientBills.servicePriceId],
        references: [servicePrices.id]
      }),
      insuranceClaim: one(insuranceClaims, {
        fields: [patientBills.insuranceClaimId],
        references: [insuranceClaims.id]
      }),
      createdByUser: one(users, {
        fields: [patientBills.createdBy],
        references: [users.id]
      }),
      payments: many(patientPayments)
    }));
    patientPaymentsRelations = relations(patientPayments, ({ one }) => ({
      tenant: one(tenants, {
        fields: [patientPayments.tenantId],
        references: [tenants.id]
      }),
      patientBill: one(patientBills, {
        fields: [patientPayments.patientBillId],
        references: [patientBills.id]
      }),
      patient: one(patients, {
        fields: [patientPayments.patientId],
        references: [patients.id]
      }),
      processedByUser: one(users, {
        fields: [patientPayments.processedBy],
        references: [users.id]
      })
    }));
    achievementsRelations = relations(achievements, ({ many }) => ({
      userAchievements: many(userAchievements)
    }));
    userAchievementsRelations = relations(userAchievements, ({ one }) => ({
      user: one(users, {
        fields: [userAchievements.userId],
        references: [users.id]
      }),
      tenant: one(tenants, {
        fields: [userAchievements.tenantId],
        references: [tenants.id]
      }),
      achievement: one(achievements, {
        fields: [userAchievements.achievementId],
        references: [achievements.id]
      })
    }));
    userStatsRelations = relations(userStats, ({ one }) => ({
      user: one(users, {
        fields: [userStats.userId],
        references: [users.id]
      }),
      tenant: one(tenants, {
        fields: [userStats.tenantId],
        references: [tenants.id]
      })
    }));
    leaderboardsRelations = relations(leaderboards, ({ one }) => ({
      user: one(users, {
        fields: [leaderboards.userId],
        references: [users.id]
      }),
      tenant: one(tenants, {
        fields: [leaderboards.tenantId],
        references: [tenants.id]
      })
    }));
    activityLogsRelations = relations(activityLogs, ({ one }) => ({
      user: one(users, {
        fields: [activityLogs.userId],
        references: [users.id]
      }),
      tenant: one(tenants, {
        fields: [activityLogs.tenantId],
        references: [tenants.id]
      })
    }));
    hospitalBillsRelations = relations(hospitalBills, ({ one }) => ({
      tenant: one(tenants, {
        fields: [hospitalBills.tenantId],
        references: [tenants.id]
      }),
      patient: one(patients, {
        fields: [hospitalBills.patientId],
        references: [patients.id]
      }),
      appointment: one(appointments, {
        fields: [hospitalBills.appointmentId],
        references: [appointments.id]
      }),
      generatedByUser: one(users, {
        fields: [hospitalBills.generatedBy],
        references: [users.id]
      })
    }));
    pharmacyBillsRelations = relations(pharmacyBills, ({ one }) => ({
      tenant: one(tenants, {
        fields: [pharmacyBills.tenantId],
        references: [tenants.id]
      }),
      patient: one(patients, {
        fields: [pharmacyBills.patientId],
        references: [patients.id]
      }),
      prescription: one(prescriptions, {
        fields: [pharmacyBills.prescriptionId],
        references: [prescriptions.id]
      }),
      generatedByUser: one(users, {
        fields: [pharmacyBills.generatedBy],
        references: [users.id]
      })
    }));
    financialTransactionsRelations = relations(financialTransactions, ({ one }) => ({
      tenant: one(tenants, {
        fields: [financialTransactions.tenantId],
        references: [tenants.id]
      }),
      patient: one(patients, {
        fields: [financialTransactions.patientId],
        references: [patients.id]
      }),
      recordedByUser: one(users, {
        fields: [financialTransactions.recordedBy],
        references: [users.id]
      }),
      approvedByUser: one(users, {
        fields: [financialTransactions.approvedBy],
        references: [users.id]
      })
    }));
    workShiftsRelations = relations(workShifts, ({ one, many }) => ({
      tenant: one(tenants, {
        fields: [workShifts.tenantId],
        references: [tenants.id]
      }),
      user: one(users, {
        fields: [workShifts.userId],
        references: [users.id]
      }),
      archivedRecords: many(archivedRecords)
    }));
    pharmacyPatientInsuranceRelations = relations(pharmacyPatientInsurance, ({ one }) => ({
      tenant: one(tenants, {
        fields: [pharmacyPatientInsurance.tenantId],
        references: [tenants.id]
      }),
      patient: one(patients, {
        fields: [pharmacyPatientInsurance.patientId],
        references: [patients.id]
      }),
      verifiedByUser: one(users, {
        fields: [pharmacyPatientInsurance.verifiedBy],
        references: [users.id]
      })
    }));
    archivedRecordsRelations = relations(archivedRecords, ({ one }) => ({
      tenant: one(tenants, {
        fields: [archivedRecords.tenantId],
        references: [tenants.id]
      }),
      workShift: one(workShifts, {
        fields: [archivedRecords.workShiftId],
        references: [workShifts.id]
      }),
      patient: one(patients, {
        fields: [archivedRecords.patientId],
        references: [patients.id]
      }),
      archivedByUser: one(users, {
        fields: [archivedRecords.archivedBy],
        references: [users.id],
        relationName: "archivedBy"
      }),
      lastAccessedByUser: one(users, {
        fields: [archivedRecords.lastAccessedBy],
        references: [users.id],
        relationName: "lastAccessedBy"
      })
    }));
    pharmacyReportTemplatesRelations = relations(pharmacyReportTemplates, ({ one }) => ({
      tenant: one(tenants, {
        fields: [pharmacyReportTemplates.tenantId],
        references: [tenants.id]
      }),
      createdByUser: one(users, {
        fields: [pharmacyReportTemplates.createdBy],
        references: [users.id]
      })
    }));
    insertTenantSchema = createInsertSchema(tenants).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertUserSchema = createInsertSchema(users).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      lastLogin: true
    });
    insertPatientSchema = createInsertSchema(patients).omit({
      id: true,
      tenantPatientId: true,
      // Auto-generated per tenant
      createdAt: true,
      updatedAt: true
    });
    insertCrossTenantPatientSchema = createInsertSchema(crossTenantPatients).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertAppointmentSchema = createInsertSchema(appointments).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertPrescriptionSchema = createInsertSchema(prescriptions).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertLabOrderSchema = createInsertSchema(labOrders).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertPharmacySchema = createInsertSchema(pharmacies).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertInsuranceProviderSchema = createInsertSchema(insuranceProviders).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertPatientInsuranceSchema = createInsertSchema(patientInsurance).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertInsuranceClaimSchema = z.object({
      tenantId: z.string().uuid(),
      patientId: z.string().uuid(),
      patientInsuranceId: z.string().uuid().nullable().optional(),
      providerId: z.string().uuid(),
      claimNumber: z.string(),
      medicalSpecialty: z.string().nullable().optional(),
      appointmentId: z.string().uuid().nullable().optional(),
      visitSummaryId: z.string().uuid().nullable().optional(),
      primaryDiagnosisCode: z.string().nullable().optional(),
      primaryDiagnosisDescription: z.string().nullable().optional(),
      secondaryDiagnosisCodes: z.array(z.object({
        code: z.string(),
        description: z.string()
      })).default([]),
      procedureCodes: z.array(z.object({
        code: z.string(),
        description: z.string(),
        amount: z.number().min(0)
      })).default([]),
      diagnosisCodes: z.array(z.string()).default([]),
      clinicalFindings: z.string().nullable().optional(),
      treatmentProvided: z.string().nullable().optional(),
      durationOfTreatment: z.string().nullable().optional(),
      medicalNecessity: z.string().nullable().optional(),
      totalAmount: z.string(),
      totalPatientCopay: z.string().default("0"),
      totalInsuranceAmount: z.string().default("0"),
      approvedAmount: z.string().nullable().optional(),
      paidAmount: z.string().nullable().optional(),
      status: z.enum(["draft", "submitted", "processing", "approved", "denied", "paid"]).default("draft"),
      submittedDate: z.date().nullable().optional(),
      processedDate: z.date().nullable().optional(),
      paidDate: z.date().nullable().optional(),
      rejectionReason: z.string().nullable().optional(),
      notes: z.string().nullable().optional(),
      attachments: z.array(z.any()).default([])
    });
    claimFormSchema = z.object({
      primaryDiagnosisCode: z.string().min(1, "Primary diagnosis code is required"),
      primaryDiagnosisDescription: z.string().min(1, "Primary diagnosis description is required"),
      secondaryDiagnosisCodes: z.array(z.object({
        code: z.string(),
        description: z.string()
      })).default([]),
      procedureCodes: z.array(z.object({
        code: z.string(),
        description: z.string(),
        amount: z.number().min(0)
      })).min(1, "At least one procedure is required"),
      clinicalFindings: z.string().min(1, "Clinical findings are required"),
      treatmentProvided: z.string().min(1, "Treatment provided is required"),
      durationOfTreatment: z.string().optional(),
      medicalNecessity: z.string().min(1, "Medical necessity justification is required"),
      notes: z.string().optional()
    });
    insertServicePriceSchema = createInsertSchema(servicePrices).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertInsurancePlanCoverageSchema = createInsertSchema(insurancePlanCoverage).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertClaimLineItemSchema = createInsertSchema(claimLineItems).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertMedicationCopaySchema = createInsertSchema(medicationCopays).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertVitalSignsSchema = createInsertSchema(vitalSigns).omit({
      id: true,
      createdAt: true
    });
    insertVisitSummarySchema = createInsertSchema(visitSummaries).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertPatientCheckInSchema = createInsertSchema(patientCheckIns).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertRolePermissionSchema = createInsertSchema(rolePermissions).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertPatientBillSchema = createInsertSchema(patientBills).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertPatientPaymentSchema = createInsertSchema(patientPayments).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertSubscriptionSchema = createInsertSchema(subscriptions).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertReportSchema = createInsertSchema(reports).omit({
      id: true,
      createdAt: true,
      completedAt: true
    });
    insertMedicalCommunicationSchema = createInsertSchema(medicalCommunications).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      readAt: true
    });
    insertCommunicationTranslationSchema = createInsertSchema(communicationTranslations).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      reviewedAt: true
    });
    insertSupportedLanguageSchema = createInsertSchema(supportedLanguages).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertMedicalPhraseSchema = createInsertSchema(medicalPhrases).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertPhraseTranslationSchema = createInsertSchema(phraseTranslations).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertLaboratorySchema = createInsertSchema(laboratories).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      approvedAt: true
    });
    insertLabResultSchema = createInsertSchema(labResults).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertLabOrderAssignmentSchema = createInsertSchema(labOrderAssignments).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertLaboratoryApplicationSchema = createInsertSchema(laboratoryApplications).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      reviewedAt: true
    });
    insertHealthRecommendationSchema = createInsertSchema(healthRecommendations).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      acknowledgedAt: true
    });
    insertHealthAnalysisSchema = createInsertSchema(healthAnalyses).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      reviewedAt: true
    });
    insertPricingPlanSchema = createInsertSchema(pricingPlans).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertOfflineSyncDataSchema = createInsertSchema(offlineSyncData).omit({
      id: true,
      createdAt: true
    });
    insertTranslationSchema = createInsertSchema(translations).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertPharmacyReceiptSchema = createInsertSchema(pharmacyReceipts);
    insertLabBillSchema = createInsertSchema(labBills);
    insertHospitalBillSchema = createInsertSchema(hospitalBills);
    insertPharmacyBillSchema = createInsertSchema(pharmacyBills);
    insertFinancialTransactionSchema = createInsertSchema(financialTransactions);
    insertAchievementSchema = createInsertSchema(achievements).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertUserAchievementSchema = createInsertSchema(userAchievements).omit({
      id: true,
      earnedAt: true
    });
    insertUserStatsSchema = createInsertSchema(userStats).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertLeaderboardSchema = createInsertSchema(leaderboards).omit({
      id: true,
      createdAt: true
    });
    insertActivityLogSchema = createInsertSchema(activityLogs).omit({
      id: true,
      timestamp: true
    });
    insertPatientAccessRequestSchema = createInsertSchema(patientAccessRequests).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      requestedDate: true,
      reviewedDate: true
    });
    insertPatientAccessAuditLogSchema = createInsertSchema(patientAccessAuditLog2).omit({
      id: true,
      accessedAt: true
    });
    insertWorkShiftSchema = createInsertSchema(workShifts).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertPharmacyPatientInsuranceSchema = createInsertSchema(pharmacyPatientInsurance).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertArchivedRecordSchema = createInsertSchema(archivedRecords).omit({
      id: true,
      createdAt: true
    });
    insertPharmacyReportTemplateSchema = createInsertSchema(pharmacyReportTemplates).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertDepartmentSchema = createInsertSchema(departments).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    advertisements = pgTable("advertisements", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      tenantId: uuid("tenant_id").references(() => tenants.id).notNull(),
      // Advertiser's tenant
      companyName: text("company_name").notNull(),
      contactEmail: text("contact_email").notNull(),
      contactPhone: text("contact_phone"),
      websiteUrl: text("website_url"),
      // Advertisement Content
      title: text("title").notNull(),
      description: text("description").notNull(),
      category: adCategoryEnum("category").notNull(),
      targetAudience: text("target_audience").array().default([]),
      // ["hospitals", "pharmacies", "laboratories"]
      keywords: text("keywords").array().default([]),
      // Media Assets
      imageUrls: text("image_urls").array().default([]),
      videoUrl: text("video_url"),
      brochureUrl: text("brochure_url"),
      // Pricing and Product Info
      priceRange: text("price_range"),
      // e.g., "$1,000 - $5,000"
      currency: currencyEnum("currency").default("USD"),
      productSpecifications: jsonb("product_specifications").default("{}"),
      certifications: text("certifications").array().default([]),
      // Advertisement Settings
      status: adStatusEnum("status").default("draft"),
      priority: adPriorityEnum("priority").default("standard"),
      billingType: adBillingTypeEnum("billing_type").default("monthly"),
      monthlyFee: decimal("monthly_fee", { precision: 10, scale: 2 }),
      clickRate: decimal("click_rate", { precision: 10, scale: 4 }),
      // Per click cost
      impressionRate: decimal("impression_rate", { precision: 10, scale: 6 }),
      // Per impression cost
      // Campaign Duration
      startDate: timestamp("start_date"),
      endDate: timestamp("end_date"),
      isActive: boolean("is_active").default(false),
      autoRenew: boolean("auto_renew").default(false),
      // Analytics
      impressions: integer("impressions").default(0),
      clicks: integer("clicks").default(0),
      conversions: integer("conversions").default(0),
      // Approval Process
      submittedAt: timestamp("submitted_at"),
      reviewedAt: timestamp("reviewed_at"),
      reviewedBy: uuid("reviewed_by").references(() => users.id),
      reviewNotes: text("review_notes"),
      rejectionReason: text("rejection_reason"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    adViews = pgTable("ad_views", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      advertisementId: uuid("advertisement_id").references(() => advertisements.id).notNull(),
      viewerTenantId: uuid("viewer_tenant_id").references(() => tenants.id),
      viewerUserId: uuid("viewer_user_id").references(() => users.id),
      ipAddress: text("ip_address"),
      userAgent: text("user_agent"),
      referrer: text("referrer"),
      // View Details
      viewDuration: integer("view_duration"),
      // seconds
      clickedThrough: boolean("clicked_through").default(false),
      conversionTracked: boolean("conversion_tracked").default(false),
      viewedAt: timestamp("viewed_at").default(sql`CURRENT_TIMESTAMP`)
    });
    adInquiries = pgTable("ad_inquiries", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      advertisementId: uuid("advertisement_id").references(() => advertisements.id).notNull(),
      inquirerTenantId: uuid("inquirer_tenant_id").references(() => tenants.id).notNull(),
      inquirerUserId: uuid("inquirer_user_id").references(() => users.id).notNull(),
      subject: text("subject").notNull(),
      message: text("message").notNull(),
      inquirerContactInfo: jsonb("inquirer_contact_info").notNull(),
      status: text("status").default("pending"),
      // pending, responded, closed
      respondedAt: timestamp("responded_at"),
      response: text("response"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    marketplaceProducts = pgTable("marketplace_products", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      supplierTenantId: uuid("supplier_tenant_id").references(() => tenants.id).notNull(),
      // Medical supplier's tenant
      name: text("name").notNull(),
      sku: text("sku").notNull(),
      // Stock Keeping Unit - unique per supplier
      description: text("description").notNull(),
      shortDescription: text("short_description"),
      category: adCategoryEnum("category").notNull(),
      subcategory: text("subcategory"),
      brand: text("brand"),
      manufacturer: text("manufacturer"),
      // Pricing - Multi-currency support
      price: decimal("price", { precision: 10, scale: 2 }).notNull(),
      currency: currencyEnum("currency").default("USD"),
      compareAtPrice: decimal("compare_at_price", { precision: 10, scale: 2 }),
      // Original price for discount display
      costPrice: decimal("cost_price", { precision: 10, scale: 2 }),
      // Supplier's cost (private)
      // Inventory Management
      stockQuantity: integer("stock_quantity").default(0),
      lowStockThreshold: integer("low_stock_threshold").default(10),
      trackInventory: boolean("track_inventory").default(true),
      backordersAllowed: boolean("backorders_allowed").default(false),
      // Product Status and Visibility
      status: productStatusEnum("status").default("draft"),
      isActive: boolean("is_active").default(false),
      isFeatured: boolean("is_featured").default(false),
      requiresPrescription: boolean("requires_prescription").default(false),
      // Product Specifications and Media
      specifications: jsonb("specifications").default("{}"),
      // Technical specs, dimensions, etc.
      features: text("features").array().default([]),
      imageUrls: text("image_urls").array().default([]),
      documentUrls: text("document_urls").array().default([]),
      // Manuals, certificates, etc.
      videoUrl: text("video_url"),
      // Regulatory and Compliance
      regulatoryApprovals: text("regulatory_approvals").array().default([]),
      // FDA, CE, etc.
      certifications: text("certifications").array().default([]),
      warrantPeriod: text("warranty_period"),
      // "2 years", "1 year", etc.
      complianceNotes: text("compliance_notes"),
      // SEO and Searchability
      metaTitle: text("meta_title"),
      metaDescription: text("meta_description"),
      searchKeywords: text("search_keywords").array().default([]),
      // Shipping and Logistics
      weight: decimal("weight", { precision: 8, scale: 2 }),
      // kg
      dimensions: jsonb("dimensions").$type(),
      shippingClass: text("shipping_class"),
      // standard, hazardous, fragile, etc.
      leadTime: integer("lead_time_days").default(1),
      // Days to process order
      // Analytics and Performance
      viewCount: integer("view_count").default(0),
      orderCount: integer("order_count").default(0),
      avgRating: decimal("avg_rating", { precision: 3, scale: 2 }).default("0.00"),
      totalReviews: integer("total_reviews").default(0),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    marketplaceOrders = pgTable("marketplace_orders", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      orderNumber: text("order_number").notNull().unique(),
      // Human-readable order number
      // Tenant Isolation: Buyer and Seller
      buyerTenantId: uuid("buyer_tenant_id").references(() => tenants.id).notNull(),
      // Hospital/Pharmacy/Lab placing order
      buyerUserId: uuid("buyer_user_id").references(() => users.id).notNull(),
      // User who placed the order
      supplierTenantId: uuid("supplier_tenant_id").references(() => tenants.id).notNull(),
      // Medical supplier fulfilling order
      // Order Details
      status: orderStatusEnum("status").default("pending"),
      subtotal: decimal("subtotal", { precision: 12, scale: 2 }).notNull(),
      taxAmount: decimal("tax_amount", { precision: 10, scale: 2 }).default("0.00"),
      shippingAmount: decimal("shipping_amount", { precision: 10, scale: 2 }).default("0.00"),
      discountAmount: decimal("discount_amount", { precision: 10, scale: 2 }).default("0.00"),
      totalAmount: decimal("total_amount", { precision: 12, scale: 2 }).notNull(),
      currency: currencyEnum("currency").default("USD"),
      // Shipping Information
      shippingAddress: jsonb("shipping_address").notNull().$type(),
      billingAddress: jsonb("billing_address").$type(),
      // Order Processing
      orderDate: timestamp("order_date").default(sql`CURRENT_TIMESTAMP`),
      expectedDeliveryDate: timestamp("expected_delivery_date"),
      actualDeliveryDate: timestamp("actual_delivery_date"),
      shippingCarrier: text("shipping_carrier"),
      trackingNumber: text("tracking_number"),
      // Order Notes and Communication
      buyerNotes: text("buyer_notes"),
      supplierNotes: text("supplier_notes"),
      internalNotes: text("internal_notes"),
      // For platform admins
      // Payment Information (reference to external payment system)
      paymentMethod: text("payment_method"),
      // credit_card, purchase_order, net_terms
      paymentStatus: text("payment_status").default("pending"),
      // pending, paid, failed, refunded
      paymentReference: text("payment_reference"),
      // External payment ID
      purchaseOrderNumber: text("purchase_order_number"),
      // Cancellation and Returns
      cancelledAt: timestamp("cancelled_at"),
      cancellationReason: text("cancellation_reason"),
      refundAmount: decimal("refund_amount", { precision: 10, scale: 2 }),
      refundedAt: timestamp("refunded_at"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    marketplaceOrderItems = pgTable("marketplace_order_items", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      orderId: uuid("order_id").references(() => marketplaceOrders.id).notNull(),
      productId: uuid("product_id").references(() => marketplaceProducts.id).notNull(),
      // Product snapshot at time of order (prevents price/detail changes affecting historical orders)
      productName: text("product_name").notNull(),
      productSku: text("product_sku").notNull(),
      productDescription: text("product_description"),
      // Pricing at time of order
      unitPrice: decimal("unit_price", { precision: 10, scale: 2 }).notNull(),
      quantity: integer("quantity").notNull(),
      lineTotal: decimal("line_total", { precision: 12, scale: 2 }).notNull(),
      // Individual item status (allows partial fulfillment)
      status: orderItemStatusEnum("status").default("pending"),
      // Item-specific shipping
      shippedQuantity: integer("shipped_quantity").default(0),
      shippedAt: timestamp("shipped_at"),
      deliveredQuantity: integer("delivered_quantity").default(0),
      deliveredAt: timestamp("delivered_at"),
      // Returns and exchanges
      returnedQuantity: integer("returned_quantity").default(0),
      returnReason: text("return_reason"),
      returnedAt: timestamp("returned_at"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    productReviews = pgTable("product_reviews", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      productId: uuid("product_id").references(() => marketplaceProducts.id).notNull(),
      reviewerTenantId: uuid("reviewer_tenant_id").references(() => tenants.id).notNull(),
      // Organization that purchased
      reviewerUserId: uuid("reviewer_user_id").references(() => users.id).notNull(),
      // User who wrote review
      orderId: uuid("order_id").references(() => marketplaceOrders.id),
      // Verified purchase
      rating: integer("rating").notNull(),
      // 1-5 stars
      title: text("title"),
      review: text("review"),
      pros: text("pros").array().default([]),
      cons: text("cons").array().default([]),
      // Review moderation
      isVerifiedPurchase: boolean("is_verified_purchase").default(false),
      isApproved: boolean("is_approved").default(false),
      moderatedBy: uuid("moderated_by").references(() => users.id),
      moderatedAt: timestamp("moderated_at"),
      // Helpfulness voting
      helpfulVotes: integer("helpful_votes").default(0),
      totalVotes: integer("total_votes").default(0),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    quoteRequests = pgTable("quote_requests", {
      id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
      productId: uuid("product_id").references(() => marketplaceProducts.id).notNull(),
      productName: text("product_name").notNull(),
      supplierName: text("supplier_name").notNull(),
      companyName: text("company_name").notNull(),
      contactName: text("contact_name").notNull(),
      email: text("email").notNull(),
      phone: text("phone"),
      quantity: integer("quantity").notNull(),
      message: text("message"),
      status: quoteRequestStatusEnum("status").default("pending").notNull(),
      requestedAt: timestamp("requested_at").default(sql`CURRENT_TIMESTAMP`),
      quotedPrice: decimal("quoted_price", { precision: 10, scale: 2 }),
      quotedAt: timestamp("quoted_at"),
      quotedBy: text("quoted_by"),
      notes: text("notes"),
      createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
      updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`)
    });
    marketplaceProductsRelations = relations(marketplaceProducts, ({ one, many }) => ({
      supplierTenant: one(tenants, {
        fields: [marketplaceProducts.supplierTenantId],
        references: [tenants.id]
      }),
      orderItems: many(marketplaceOrderItems),
      reviews: many(productReviews)
    }));
    marketplaceOrdersRelations = relations(marketplaceOrders, ({ one, many }) => ({
      buyerTenant: one(tenants, {
        fields: [marketplaceOrders.buyerTenantId],
        references: [tenants.id]
      }),
      supplierTenant: one(tenants, {
        fields: [marketplaceOrders.supplierTenantId],
        references: [tenants.id]
      }),
      buyerUser: one(users, {
        fields: [marketplaceOrders.buyerUserId],
        references: [users.id]
      }),
      orderItems: many(marketplaceOrderItems),
      reviews: many(productReviews)
    }));
    marketplaceOrderItemsRelations = relations(marketplaceOrderItems, ({ one }) => ({
      order: one(marketplaceOrders, {
        fields: [marketplaceOrderItems.orderId],
        references: [marketplaceOrders.id]
      }),
      product: one(marketplaceProducts, {
        fields: [marketplaceOrderItems.productId],
        references: [marketplaceProducts.id]
      })
    }));
    productReviewsRelations = relations(productReviews, ({ one }) => ({
      product: one(marketplaceProducts, {
        fields: [productReviews.productId],
        references: [marketplaceProducts.id]
      }),
      reviewerTenant: one(tenants, {
        fields: [productReviews.reviewerTenantId],
        references: [tenants.id]
      }),
      reviewerUser: one(users, {
        fields: [productReviews.reviewerUserId],
        references: [users.id]
      }),
      order: one(marketplaceOrders, {
        fields: [productReviews.orderId],
        references: [marketplaceOrders.id]
      }),
      moderatedByUser: one(users, {
        fields: [productReviews.moderatedBy],
        references: [users.id]
      })
    }));
    advertisementsRelations = relations(advertisements, ({ one, many }) => ({
      tenant: one(tenants, {
        fields: [advertisements.tenantId],
        references: [tenants.id]
      }),
      reviewedByUser: one(users, {
        fields: [advertisements.reviewedBy],
        references: [users.id]
      }),
      views: many(adViews),
      inquiries: many(adInquiries)
    }));
    adViewsRelations = relations(adViews, ({ one }) => ({
      advertisement: one(advertisements, {
        fields: [adViews.advertisementId],
        references: [advertisements.id]
      }),
      viewerTenant: one(tenants, {
        fields: [adViews.viewerTenantId],
        references: [tenants.id]
      }),
      viewerUser: one(users, {
        fields: [adViews.viewerUserId],
        references: [users.id]
      })
    }));
    adInquiriesRelations = relations(adInquiries, ({ one }) => ({
      advertisement: one(advertisements, {
        fields: [adInquiries.advertisementId],
        references: [advertisements.id]
      }),
      inquirerTenant: one(tenants, {
        fields: [adInquiries.inquirerTenantId],
        references: [tenants.id]
      }),
      inquirerUser: one(users, {
        fields: [adInquiries.inquirerUserId],
        references: [users.id]
      })
    }));
    countriesRelations = relations(countries, ({ many }) => ({
      tenants: many(tenants),
      medicalCodes: many(countryMedicalCodes),
      codeUploads: many(medicalCodeUploads)
    }));
    countryMedicalCodesRelations = relations(countryMedicalCodes, ({ one }) => ({
      country: one(countries, {
        fields: [countryMedicalCodes.countryId],
        references: [countries.id]
      }),
      uploadedByUser: one(users, {
        fields: [countryMedicalCodes.uploadedBy],
        references: [users.id]
      })
    }));
    medicalCodeUploadsRelations = relations(medicalCodeUploads, ({ one }) => ({
      country: one(countries, {
        fields: [medicalCodeUploads.countryId],
        references: [countries.id]
      }),
      uploadedByUser: one(users, {
        fields: [medicalCodeUploads.uploadedBy],
        references: [users.id]
      })
    }));
    insertAdvertisementSchema = createInsertSchema(advertisements).omit({
      id: true,
      impressions: true,
      clicks: true,
      conversions: true,
      reviewedAt: true,
      reviewedBy: true,
      reviewNotes: true,
      rejectionReason: true,
      createdAt: true,
      updatedAt: true
    });
    insertAdViewSchema = createInsertSchema(adViews).omit({
      id: true,
      viewedAt: true
    });
    insertAdInquirySchema = createInsertSchema(adInquiries).omit({
      id: true,
      respondedAt: true,
      response: true,
      createdAt: true,
      updatedAt: true
    });
    insertCountrySchema = createInsertSchema(countries).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertCountryMedicalCodeSchema = createInsertSchema(countryMedicalCodes).omit({
      id: true,
      uploadedAt: true,
      createdAt: true,
      updatedAt: true
    });
    insertMedicalCodeUploadSchema = createInsertSchema(medicalCodeUploads).omit({
      id: true,
      recordsProcessed: true,
      recordsImported: true,
      recordsSkipped: true,
      errors: true,
      status: true,
      createdAt: true,
      completedAt: true
    });
    insertMedicalSupplierSchema = createInsertSchema(medicalSuppliers).omit({
      id: true,
      organizationSlug: true,
      // Generated automatically
      status: true,
      // Set automatically
      createdAt: true,
      updatedAt: true,
      tenantId: true,
      approvedBy: true,
      approvedAt: true,
      rejectionReason: true,
      notes: true
    });
    insertMarketplaceProductSchema = createInsertSchema(marketplaceProducts).omit({
      id: true,
      viewCount: true,
      orderCount: true,
      avgRating: true,
      totalReviews: true,
      createdAt: true,
      updatedAt: true
    });
    insertMarketplaceOrderSchema = createInsertSchema(marketplaceOrders).omit({
      id: true,
      orderDate: true,
      cancelledAt: true,
      refundedAt: true,
      createdAt: true,
      updatedAt: true
    });
    insertMarketplaceOrderItemSchema = createInsertSchema(marketplaceOrderItems).omit({
      id: true,
      shippedAt: true,
      deliveredAt: true,
      returnedAt: true,
      createdAt: true,
      updatedAt: true
    });
    insertProductReviewSchema = createInsertSchema(productReviews).omit({
      id: true,
      moderatedAt: true,
      helpfulVotes: true,
      totalVotes: true,
      createdAt: true,
      updatedAt: true
    });
    insertQuoteRequestSchema = createInsertSchema(quoteRequests).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
  }
});

// server/db.ts
import { Pool, neonConfig } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-serverless";
import ws from "ws";
var pool, db;
var init_db = __esm({
  "server/db.ts"() {
    "use strict";
    init_schema();
    neonConfig.webSocketConstructor = ws;
    if (!process.env.DATABASE_URL) {
      throw new Error(
        "DATABASE_URL must be set. Did you forget to provision a database?"
      );
    }
    pool = new Pool({ connectionString: process.env.DATABASE_URL });
    db = drizzle({ client: pool, schema: schema_exports });
  }
});

// server/currency-utils.ts
var currency_utils_exports = {};
__export(currency_utils_exports, {
  convertCurrency: () => convertCurrency,
  formatCurrency: () => formatCurrency,
  getAfricanCurrencies: () => getAfricanCurrencies,
  getAllCurrencies: () => getAllCurrencies,
  getCurrencyInfo: () => getCurrencyInfo,
  getTenantBaseCurrency: () => getTenantBaseCurrency,
  getTenantCurrencies: () => getTenantCurrencies,
  updateExchangeRate: () => updateExchangeRate
});
import { eq, and, desc } from "drizzle-orm";
async function formatCurrency(amount, currencyCode, currencyInfo) {
  const numAmount = typeof amount === "string" ? parseFloat(amount) : amount;
  const info = currencyInfo || await getCurrencyInfo(currencyCode);
  if (!info) {
    return `${currencyCode} ${numAmount.toFixed(2)}`;
  }
  const formatted = numAmount.toFixed(info.decimalPlaces);
  switch (currencyCode) {
    case "USD":
    case "CAD":
    case "AUD":
    case "LRD":
    case "NAD":
    case "ZWL":
      return `${info.symbol}${formatted}`;
    case "EUR":
      return `${formatted} ${info.symbol}`;
    case "GBP":
    case "EGP":
    case "SSP":
      return `${info.symbol}${formatted}`;
    case "NGN":
      return `${info.symbol}${formatted}`;
    case "ZAR":
      return `R ${formatted}`;
    case "KES":
    case "TZS":
    case "UGX":
    case "SOS":
      return `${info.symbol} ${formatted}`;
    case "XOF":
    case "XAF":
      return `${formatted} ${info.symbol}`;
    default:
      return `${info.symbol} ${formatted}`;
  }
}
async function getCurrencyInfo(currencyCode) {
  try {
    const [currency] = await db.select().from(currencies).where(and(
      eq(currencies.code, currencyCode),
      eq(currencies.isActive, true)
    ));
    if (!currency) return null;
    return {
      code: currency.code,
      name: currency.name,
      symbol: currency.symbol,
      decimalPlaces: currency.decimalPlaces || 2,
      region: currency.region || "",
      country: currency.country || ""
    };
  } catch (error) {
    console.error("Error fetching currency info:", error);
    return null;
  }
}
async function getTenantCurrencies(tenantId) {
  try {
    const [tenant] = await db.select().from(tenants).where(eq(tenants.id, tenantId));
    if (!tenant) return ["USD"];
    const supportedCurrencies = tenant.supportedCurrencies || ["USD"];
    return supportedCurrencies;
  } catch (error) {
    console.error("Error fetching tenant currencies:", error);
    return ["USD"];
  }
}
async function getTenantBaseCurrency(tenantId) {
  try {
    const [tenant] = await db.select().from(tenants).where(eq(tenants.id, tenantId));
    return tenant?.baseCurrency || "USD";
  } catch (error) {
    console.error("Error fetching tenant base currency:", error);
    return "USD";
  }
}
async function convertCurrency(amount, fromCurrency, toCurrency) {
  try {
    if (fromCurrency === toCurrency) {
      return {
        originalAmount: amount,
        originalCurrency: fromCurrency,
        convertedAmount: amount,
        targetCurrency: toCurrency,
        exchangeRate: 1,
        timestamp: /* @__PURE__ */ new Date()
      };
    }
    let rate = 1;
    const [directRate] = await db.select().from(exchangeRates).where(and(
      eq(exchangeRates.baseCurrency, fromCurrency),
      eq(exchangeRates.targetCurrency, toCurrency),
      eq(exchangeRates.isActive, true)
    )).orderBy(desc(exchangeRates.validFrom)).limit(1);
    if (directRate) {
      rate = parseFloat(directRate.rate);
    } else {
      const [fromCurrencyInfo] = await db.select().from(currencies).where(eq(currencies.code, fromCurrency));
      const [toCurrencyInfo] = await db.select().from(currencies).where(eq(currencies.code, toCurrency));
      if (fromCurrencyInfo && toCurrencyInfo) {
        const fromUsdRate = parseFloat(fromCurrencyInfo.exchangeRateToUSD);
        const toUsdRate = parseFloat(toCurrencyInfo.exchangeRateToUSD);
        rate = fromUsdRate / toUsdRate;
      } else {
        return null;
      }
    }
    const convertedAmount = amount * rate;
    return {
      originalAmount: amount,
      originalCurrency: fromCurrency,
      convertedAmount,
      targetCurrency: toCurrency,
      exchangeRate: rate,
      timestamp: /* @__PURE__ */ new Date()
    };
  } catch (error) {
    console.error("Error converting currency:", error);
    return null;
  }
}
async function getAfricanCurrencies() {
  try {
    const africanCurrencies = await db.select().from(currencies).where(and(
      eq(currencies.region, "Africa"),
      eq(currencies.isActive, true)
    ));
    return africanCurrencies.map((c) => ({
      code: c.code,
      name: c.name,
      symbol: c.symbol,
      decimalPlaces: c.decimalPlaces || 2,
      region: c.region || "",
      country: c.country || ""
    }));
  } catch (error) {
    console.error("Error fetching African currencies:", error);
    return [];
  }
}
async function getAllCurrencies() {
  try {
    const allCurrencies = await db.select().from(currencies).where(eq(currencies.isActive, true));
    return allCurrencies.map((c) => ({
      code: c.code,
      name: c.name,
      symbol: c.symbol,
      decimalPlaces: c.decimalPlaces || 2,
      region: c.region || "",
      country: c.country || ""
    }));
  } catch (error) {
    console.error("Error fetching all currencies:", error);
    return [];
  }
}
async function updateExchangeRate(baseCurrency, targetCurrency, rate, provider = "manual") {
  try {
    await db.insert(exchangeRates).values({
      baseCurrency,
      targetCurrency,
      rate: rate.toString(),
      provider,
      validFrom: /* @__PURE__ */ new Date(),
      isActive: true
    });
    return true;
  } catch (error) {
    console.error("Error updating exchange rate:", error);
    return false;
  }
}
var init_currency_utils = __esm({
  "server/currency-utils.ts"() {
    "use strict";
    init_db();
    init_schema();
  }
});

// server/email-service.ts
var email_service_exports = {};
__export(email_service_exports, {
  generateTemporaryPassword: () => generateTemporaryPassword,
  sendEmail: () => sendEmail,
  sendRegistrationConfirmationEmail: () => sendRegistrationConfirmationEmail,
  sendWelcomeEmail: () => sendWelcomeEmail
});
import { MailService } from "@sendgrid/mail";
async function sendEmail(params) {
  if (!mailService) {
    console.log("Email would be sent (SendGrid not configured):", {
      to: params.to,
      from: params.from,
      subject: params.subject
    });
    return true;
  }
  try {
    const emailData = {
      to: params.to,
      from: params.from,
      subject: params.subject
    };
    if (params.text) emailData.text = params.text;
    if (params.html) emailData.html = params.html;
    await mailService.send(emailData);
    return true;
  } catch (error) {
    console.error("SendGrid email error:", error);
    return false;
  }
}
async function sendRegistrationConfirmationEmail(userEmail, userName, organizationName, loginUrl = "https://navimed-healthcare.replit.app/login") {
  const confirmationHtml = `
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Welcome to NaviMED Healthcare Platform</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #2563eb, #10b981); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f8f9fa; padding: 30px; border-radius: 0 0 8px 8px; }
            .welcome-message { background: white; padding: 25px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #2563eb; }
            .features { background: white; padding: 25px; border-radius: 8px; margin-bottom: 20px; }
            .feature-item { margin: 15px 0; padding: 10px 0; border-bottom: 1px solid #e5e7eb; }
            .feature-item:last-child { border-bottom: none; }
            .feature-icon { color: #10b981; font-weight: bold; margin-right: 10px; }
            .button { background: #2563eb; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; display: inline-block; margin: 20px 0; }
            .footer { text-align: center; color: #6b7280; font-size: 14px; margin-top: 30px; }
            .logo { font-size: 28px; font-weight: bold; margin-bottom: 10px; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <div class="logo">\u{1F3E5} NAVIMED</div>
                <h1 style="margin: 0;">Welcome to NaviMED Healthcare Platform!</h1>
                <p style="margin: 10px 0 0 0; opacity: 0.9;">Your registration was successful</p>
            </div>
            
            <div class="content">
                <div class="welcome-message">
                    <h2 style="color: #2563eb; margin-top: 0;">Hello ${userName}!</h2>
                    <p>Thank you for registering with NaviMED Healthcare Platform. Your account for <strong>${organizationName}</strong> has been successfully created and is ready to use.</p>
                    <p>You now have access to our comprehensive suite of healthcare management tools designed to streamline your operations and improve patient care.</p>
                </div>

                <div class="features">
                    <h3 style="color: #2563eb; margin-top: 0;">What you can do with NaviMED:</h3>
                    
                    <div class="feature-item">
                        <span class="feature-icon">\u{1F4C5}</span>
                        <strong>Appointment Management:</strong> Schedule, track, and manage patient appointments
                    </div>
                    
                    <div class="feature-item">
                        <span class="feature-icon">\u{1F468}\u200D\u2695\uFE0F</span>
                        <strong>Patient Records:</strong> Secure electronic health records with comprehensive patient data
                    </div>
                    
                    <div class="feature-item">
                        <span class="feature-icon">\u{1F48A}</span>
                        <strong>Prescription Management:</strong> Digital prescriptions with pharmacy integration
                    </div>
                    
                    <div class="feature-item">
                        <span class="feature-icon">\u{1F9EA}</span>
                        <strong>Laboratory Integration:</strong> Lab order management and results tracking
                    </div>
                    
                    <div class="feature-item">
                        <span class="feature-icon">\u{1F4B0}</span>
                        <strong>Billing & Insurance:</strong> Automated insurance claims and billing management
                    </div>
                    
                    <div class="feature-item">
                        <span class="feature-icon">\u{1F6D2}</span>
                        <strong>Medical Marketplace:</strong> Access to medical supplies and equipment vendors
                    </div>
                </div>

                <div style="text-align: center; margin: 30px 0;">
                    <p style="margin-bottom: 20px;">Ready to get started? Access your dashboard:</p>
                    <a href="${loginUrl}" class="button">Login to Your Dashboard</a>
                </div>

                <div style="background: #e0f2fe; padding: 20px; border-radius: 8px; border-left: 4px solid #0288d1;">
                    <h4 style="color: #0288d1; margin-top: 0;">Need Help?</h4>
                    <p style="margin-bottom: 0;">Our support team is here to help you get the most out of NaviMED. Contact us anytime for assistance with setup, training, or technical support.</p>
                </div>
            </div>

            <div class="footer">
                <p>Thank you for choosing NaviMED Healthcare Platform</p>
                <p style="font-size: 12px; color: #9ca3af;">This email was sent to ${userEmail} because you registered for a NaviMED account.</p>
            </div>
        </div>
    </body>
    </html>
  `;
  const confirmationText = `
Welcome to NaviMED Healthcare Platform!

Hello ${userName},

Thank you for registering with NaviMED Healthcare Platform. Your account for ${organizationName} has been successfully created and is ready to use.

You now have access to our comprehensive healthcare management tools:

\u2022 Appointment Management - Schedule and track patient appointments
\u2022 Patient Records - Secure electronic health records  
\u2022 Prescription Management - Digital prescriptions with pharmacy integration
\u2022 Laboratory Integration - Lab order management and results tracking
\u2022 Billing & Insurance - Automated insurance claims and billing
\u2022 Medical Marketplace - Access to medical supplies and equipment

Ready to get started? Log in to your dashboard at: ${loginUrl}

Need help? Our support team is here to assist you with setup, training, and technical support.

Thank you for choosing NaviMED Healthcare Platform!
  `;
  return await sendEmail({
    to: userEmail,
    from: "noreply@navimedi.org",
    subject: "Welcome to NaviMED - Registration Confirmed",
    text: confirmationText,
    html: confirmationHtml
  });
}
async function sendWelcomeEmail(params) {
  const htmlContent = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Welcome to NaviMed Healthcare Platform</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background-color: #10b981; color: white; padding: 20px; text-align: center; }
            .content { background-color: #f9f9f9; padding: 30px; }
            .credentials { background-color: #e5f7f0; border: 1px solid #10b981; padding: 15px; margin: 20px 0; border-radius: 5px; }
            .button { display: inline-block; background-color: #10b981; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
            .warning { background-color: #fef3cd; border: 1px solid #f6d55c; padding: 15px; margin: 20px 0; border-radius: 5px; color: #856404; }
            .footer { text-align: center; padding: 20px; color: #666; font-size: 14px; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Welcome to NaviMed</h1>
                <p>Healthcare Management Platform</p>
            </div>
            
            <div class="content">
                <h2>Hello ${params.firstName} ${params.lastName},</h2>
                
                <p>Welcome to the NaviMed Healthcare Management Platform! Your account has been successfully created for <strong>${params.organizationName}</strong>.</p>
                
                <div class="credentials">
                    <h3>Your Login Credentials:</h3>
                    <p><strong>Username:</strong> ${params.username}</p>
                    <p><strong>Email:</strong> ${params.userEmail}</p>
                    <p><strong>Temporary Password:</strong> ${params.temporaryPassword}</p>
                </div>
                
                <div class="warning">
                    <h4>\u26A0\uFE0F Important Security Notice</h4>
                    <p>This is a <strong>temporary password</strong>. For your security, you will be required to change this password when you first log in to the system.</p>
                </div>
                
                <p>To get started:</p>
                <ol>
                    <li>Click the login button below</li>
                    <li>Enter your username and temporary password</li>
                    <li>Create a new secure password when prompted</li>
                    <li>Begin using the NaviMed platform</li>
                </ol>
                
                <div style="text-align: center;">
                    <a href="${params.loginUrl}" class="button">Login to NaviMed</a>
                </div>
                
                <h3>What you can do with NaviMed:</h3>
                <ul>
                    <li>Manage patient records and appointments</li>
                    <li>Process prescriptions and lab orders</li>
                    <li>Handle billing and insurance claims</li>
                    <li>Secure medical communications</li>
                    <li>Generate comprehensive reports</li>
                </ul>
                
                <p>If you have any questions or need assistance, please don't hesitate to contact our support team.</p>
                
                <p>Best regards,<br>
                The NaviMed Team</p>
            </div>
            
            <div class="footer">
                <p>This email was sent from noreply@navimedi.org</p>
                <p>\xA9 2025 NaviMed Healthcare Platform. All rights reserved.</p>
            </div>
        </div>
    </body>
    </html>
  `;
  const textContent = `
Welcome to NaviMed Healthcare Platform!

Hello ${params.firstName} ${params.lastName},

Your account has been successfully created for ${params.organizationName}.

LOGIN CREDENTIALS:
Username: ${params.username}
Email: ${params.userEmail}
Temporary Password: ${params.temporaryPassword}

IMPORTANT SECURITY NOTICE:
This is a temporary password. You will be required to change this password when you first log in.

To get started:
1. Visit: ${params.loginUrl}
2. Enter your username and temporary password
3. Create a new secure password when prompted
4. Begin using the NaviMed platform

If you have any questions, please contact our support team.

Best regards,
The NaviMed Team

This email was sent from noreply@navimedi.org
\xA9 2025 NaviMed Healthcare Platform. All rights reserved.
  `;
  return await sendEmail({
    to: params.userEmail,
    from: "noreply@navimedi.org",
    subject: `Welcome to NaviMed - Your Account Details for ${params.organizationName}`,
    text: textContent,
    html: htmlContent
  });
}
function generateTemporaryPassword() {
  const length = 12;
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%&*";
  let password = "";
  password += "ABCDEFGHJKLMNPQRSTUVWXYZ"[Math.floor(Math.random() * 24)];
  password += "abcdefghijkmnpqrstuvwxyz"[Math.floor(Math.random() * 24)];
  password += "23456789"[Math.floor(Math.random() * 8)];
  password += "!@#$%&*"[Math.floor(Math.random() * 7)];
  for (let i = password.length; i < length; i++) {
    password += chars[Math.floor(Math.random() * chars.length)];
  }
  return password.split("").sort(() => Math.random() - 0.5).join("");
}
var mailService;
var init_email_service = __esm({
  "server/email-service.ts"() {
    "use strict";
    mailService = null;
    if (process.env.SENDGRID_API_KEY && process.env.SENDGRID_API_KEY.startsWith("SG.")) {
      mailService = new MailService();
      mailService.setApiKey(process.env.SENDGRID_API_KEY);
    } else if (process.env.SENDGRID_API_KEY && !process.env.SENDGRID_API_KEY.startsWith("SG.")) {
      console.warn("Invalid SENDGRID_API_KEY format. API key must start with 'SG.' - Email functionality will be disabled.");
    } else {
      console.warn("SENDGRID_API_KEY environment variable not set. Email functionality will be disabled.");
    }
  }
});

// server/index.ts
import express2 from "express";

// server/routes.ts
import { createServer } from "http";

// server/storage.ts
init_schema();
init_db();
import { eq as eq2, and as and2, desc as desc2, sql as sql2, like, or, isNull, gt, ilike, gte, lt, ne, inArray } from "drizzle-orm";
import { randomUUID } from "crypto";
var DatabaseStorage = class {
  // User management - SECURITY: All user queries must include tenantId for isolation
  async getUser(id, tenantId) {
    if (tenantId) {
      const [user2] = await db.select().from(users).where(
        and2(eq2(users.id, id), eq2(users.tenantId, tenantId))
      );
      return user2 || void 0;
    }
    console.log("[SECURITY] Cross-tenant user access by super admin:", id);
    const [user] = await db.select().from(users).where(eq2(users.id, id));
    return user || void 0;
  }
  async getAllUsers() {
    return await db.select().from(users);
  }
  async getUserByUsername(username, tenantId) {
    const [user] = await db.select().from(users).where(
      and2(eq2(users.username, username), eq2(users.tenantId, tenantId))
    );
    return user || void 0;
  }
  async getUserByEmailOrUsername(emailOrUsername, tenantId) {
    const [user] = await db.select().from(users).where(
      and2(
        or(eq2(users.email, emailOrUsername), eq2(users.username, emailOrUsername)),
        eq2(users.tenantId, tenantId)
      )
    );
    return user || void 0;
  }
  async getUserByEmail(email, tenantId) {
    const [user] = await db.select().from(users).where(
      and2(eq2(users.email, email), eq2(users.tenantId, tenantId))
    );
    return user || void 0;
  }
  async createUser(insertUser) {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  async updateUser(id, updates) {
    const [user] = await db.update(users).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(eq2(users.id, id)).returning();
    return user || void 0;
  }
  async updateUserStatus(id, tenantId, isActive) {
    const [user] = await db.update(users).set({
      isActive,
      updatedAt: sql2`CURRENT_TIMESTAMP`
    }).where(and2(eq2(users.id, id), eq2(users.tenantId, tenantId))).returning();
    return user || void 0;
  }
  async upsertUser(userData) {
    const [user] = await db.insert(users).values(userData).onConflictDoUpdate({
      target: users.id,
      set: {
        ...userData,
        updatedAt: sql2`CURRENT_TIMESTAMP`
      }
    }).returning();
    return user;
  }
  // Stripe integration method implementations
  async updateStripeCustomerId(userId, stripeCustomerId) {
    const [user] = await db.update(users).set({ stripeCustomerId, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(eq2(users.id, userId)).returning();
    return user || void 0;
  }
  async updateUserStripeInfo(userId, stripeCustomerId, stripeSubscriptionId) {
    const [user] = await db.update(users).set({
      stripeCustomerId,
      stripeSubscriptionId,
      updatedAt: sql2`CURRENT_TIMESTAMP`
    }).where(eq2(users.id, userId)).returning();
    return user || void 0;
  }
  async getUsersByTenant(tenantId) {
    return await db.select().from(users).where(eq2(users.tenantId, tenantId));
  }
  // User permissions methods for role-based access control
  async getUserPermissions(userId, tenantId) {
    try {
      const user = await db.select().from(users).where(and2(eq2(users.id, userId), eq2(users.tenantId, tenantId))).limit(1);
      if (!user.length) return [];
      const role = user[0].role;
      switch (role) {
        case "physician":
          return [];
        // By default, doctors have NO scheduling/confirmation permissions
        case "receptionist":
          return ["schedule_appointments", "confirm_appointments", "cancel_appointments"];
        case "tenant_admin":
        case "director":
        case "super_admin":
          return ["schedule_appointments", "confirm_appointments", "cancel_appointments", "manage_permissions"];
        default:
          return [];
      }
    } catch (error) {
      console.error("Error getting user permissions:", error);
      return [];
    }
  }
  // Grant specific permission to a user (for admin use)
  async grantUserPermission(userId, permission, tenantId) {
    try {
      console.log(`[PERMISSIONS] Granting ${permission} to user ${userId} in tenant ${tenantId}`);
      return true;
    } catch (error) {
      console.error("Error granting user permission:", error);
      return false;
    }
  }
  async getUsersByRole(role, tenantId) {
    return await db.select().from(users).where(
      and2(
        sql2`${users.role} = ${role}`,
        eq2(users.tenantId, tenantId),
        eq2(users.isActive, true)
      )
    );
  }
  // Tenant management
  async getTenant(id) {
    const [tenant] = await db.select().from(tenants).where(eq2(tenants.id, id));
    return tenant || void 0;
  }
  async getTenantBySubdomain(subdomain) {
    const [tenant] = await db.select().from(tenants).where(eq2(tenants.subdomain, subdomain));
    return tenant || void 0;
  }
  async createTenant(insertTenant) {
    const [tenant] = await db.insert(tenants).values(insertTenant).returning();
    return tenant;
  }
  async updateTenant(id, updates) {
    const [tenant] = await db.update(tenants).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(eq2(tenants.id, id)).returning();
    return tenant || void 0;
  }
  async getAllTenants() {
    return await db.select().from(tenants).where(eq2(tenants.isActive, true));
  }
  async getTenantsByType(tenantType) {
    return await db.select().from(tenants).where(
      and2(eq2(tenants.type, tenantType), eq2(tenants.isActive, true))
    );
  }
  // Patient management
  async getPatient(id, tenantId) {
    const [patient] = await db.select().from(patients).where(
      and2(eq2(patients.id, id), eq2(patients.tenantId, tenantId))
    );
    return patient || void 0;
  }
  // SECURITY: Cross-tenant patient access only for authorized pharmacy billing
  async getPatientById(id, accessContext) {
    if (!accessContext) {
      console.error("[SECURITY VIOLATION] getPatientById called without access context");
      throw new Error("Cross-tenant patient access requires explicit context for security audit");
    }
    console.log(`[SECURITY AUDIT] Cross-tenant patient access: ${accessContext.type} by tenant ${accessContext.tenantId} for patient ${id}`);
    const [patient] = await db.select().from(patients).where(eq2(patients.id, id));
    return patient || void 0;
  }
  async getPatientByMRN(mrn, tenantId) {
    const [patient] = await db.select().from(patients).where(
      and2(eq2(patients.mrn, mrn), eq2(patients.tenantId, tenantId))
    );
    return patient || void 0;
  }
  async getPatientByTenantPatientId(tenantPatientId, tenantId) {
    const [patient] = await db.select().from(patients).where(
      and2(eq2(patients.tenantPatientId, tenantPatientId), eq2(patients.tenantId, tenantId))
    );
    return patient || void 0;
  }
  async getNextPatientNumber(tenantId) {
    const result = await db.select({ count: sql2`count(*)` }).from(patients).where(eq2(patients.tenantId, tenantId));
    return (result[0]?.count || 0) + 1;
  }
  async generateTenantPatientId(tenantId) {
    try {
      const tenant = await this.getTenant(tenantId);
      if (!tenant) {
        throw new Error(`Tenant not found: ${tenantId}`);
      }
      const tenantPrefix = tenant.name.substring(0, 3).toUpperCase().replace(/[^A-Z]/g, "X");
      const patientCounter = await this.getNextPatientNumber(tenantId);
      return `${tenantPrefix}-${patientCounter.toString().padStart(6, "0")}`;
    } catch (error) {
      console.error("Error generating tenant patient ID:", error);
      throw error;
    }
  }
  async createPatient(insertPatient) {
    const tenantPatientId = await this.generateTenantPatientId(insertPatient.tenantId);
    const mrn = tenantPatientId;
    const patientData = {
      ...insertPatient,
      tenantPatientId,
      mrn
    };
    const [patient] = await db.insert(patients).values(patientData).returning();
    return patient;
  }
  async updatePatient(id, updates, tenantId) {
    const [patient] = await db.update(patients).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(eq2(patients.id, id), eq2(patients.tenantId, tenantId))).returning();
    return patient || void 0;
  }
  async getPatientsByTenant(tenantId, limit = 50, offset = 0) {
    return await db.select().from(patients).where(and2(eq2(patients.tenantId, tenantId), eq2(patients.isActive, true))).limit(limit).offset(offset).orderBy(desc2(patients.createdAt));
  }
  async searchPatients(tenantId, query) {
    return await db.select().from(patients).where(
      and2(
        eq2(patients.tenantId, tenantId),
        eq2(patients.isActive, true),
        sql2`(LOWER(${patients.firstName}) LIKE LOWER('%' || ${query} || '%') OR 
             LOWER(${patients.lastName}) LIKE LOWER('%' || ${query} || '%') OR 
             ${patients.mrn} LIKE '%' || ${query} || '%')`
      )
    );
  }
  // Get patients assigned to a specific physician
  async getPatientsByPhysician(physicianId, tenantId, limit, offset) {
    const query = db.select().from(patients).where(
      and2(
        eq2(patients.tenantId, tenantId),
        eq2(patients.primaryPhysicianId, physicianId),
        eq2(patients.isActive, true)
      )
    ).orderBy(desc2(patients.createdAt));
    if (limit !== void 0 && offset !== void 0) {
      return await query.limit(limit).offset(offset);
    }
    return await query;
  }
  // Search within a physician's assigned patients
  async searchAssignedPatients(physicianId, tenantId, query) {
    return await db.select().from(patients).where(
      and2(
        eq2(patients.tenantId, tenantId),
        eq2(patients.primaryPhysicianId, physicianId),
        eq2(patients.isActive, true),
        sql2`(LOWER(${patients.firstName}) LIKE LOWER('%' || ${query} || '%') OR 
             LOWER(${patients.lastName}) LIKE LOWER('%' || ${query} || '%') OR 
             ${patients.mrn} LIKE '%' || ${query} || '%')`
      )
    ).orderBy(desc2(patients.createdAt));
  }
  async getAllPatients(limit = 50, offset = 0) {
    console.error("[SECURITY VIOLATION] getAllPatients called without tenant filtering");
    throw new Error("Direct patient access without tenant filtering is not permitted for security");
  }
  async searchPatientsGlobal(query) {
    console.error("[SECURITY VIOLATION] searchPatientsGlobal called without tenant filtering");
    throw new Error("Global patient search without tenant filtering is not permitted for security");
  }
  // Cross-tenant patients for pharmacy billing (patients with prescriptions sent to this pharmacy)
  async getPatientsWithPrescriptionsForPharmacy(pharmacyTenantId) {
    const patientsWithPrescriptions = await db.select({
      id: patients.id,
      tenantId: patients.tenantId,
      firstName: patients.firstName,
      lastName: patients.lastName,
      dateOfBirth: patients.dateOfBirth,
      gender: patients.gender,
      phone: patients.phone,
      email: patients.email,
      address: patients.address,
      mrn: patients.mrn,
      emergencyContact: patients.emergencyContact,
      insuranceInfo: patients.insuranceInfo,
      allergies: patients.allergies,
      medications: patients.medications,
      medicalHistory: patients.medicalHistory,
      isActive: patients.isActive,
      createdAt: patients.createdAt,
      updatedAt: patients.updatedAt
    }).from(patients).innerJoin(prescriptions, eq2(prescriptions.patientId, patients.id)).where(
      and2(
        eq2(prescriptions.pharmacyTenantId, pharmacyTenantId),
        eq2(patients.isActive, true)
      )
    ).groupBy(
      patients.id,
      patients.tenantId,
      patients.firstName,
      patients.lastName,
      patients.dateOfBirth,
      patients.gender,
      patients.phone,
      patients.email,
      patients.address,
      patients.mrn,
      patients.emergencyContact,
      patients.insuranceInfo,
      patients.allergies,
      patients.medications,
      patients.medicalHistory,
      patients.isActive,
      patients.createdAt,
      patients.updatedAt
    ).orderBy(patients.lastName, patients.firstName);
    return patientsWithPrescriptions;
  }
  // Cross-tenant patient insurance access for pharmacy billing  
  async getPatientInsuranceCrossTenant(patientId, accessContext) {
    console.log(`[SECURITY AUDIT] Cross-tenant insurance access: ${accessContext.type} by user ${accessContext.userId} from tenant ${accessContext.tenantId} for patient ${patientId}`);
    const allowedAccessTypes = ["pharmacy_billing", "emergency_care"];
    if (!allowedAccessTypes.includes(accessContext.type)) {
      throw new Error("Unauthorized cross-tenant insurance access type");
    }
    try {
      const insuranceRecords = await db.select().from(patientInsurance).where(eq2(patientInsurance.patientId, patientId)).orderBy(desc2(patientInsurance.isPrimary), patientInsurance.effectiveDate);
      console.log(`[SECURITY AUDIT] Found ${insuranceRecords.length} insurance records for patient ${patientId}`);
      return insuranceRecords;
    } catch (error) {
      console.error("[CROSS-TENANT INSURANCE] Query error:", error);
      throw error;
    }
  }
  // Enhanced medical records methods for healthcare professionals
  async getPatientsWithMedicalRecords(tenantId) {
    const patientsList = await db.select({
      id: patients.id,
      tenantId: patients.tenantId,
      firstName: patients.firstName,
      lastName: patients.lastName,
      dateOfBirth: patients.dateOfBirth,
      gender: patients.gender,
      phone: patients.phone,
      email: patients.email,
      address: patients.address,
      mrn: patients.mrn,
      emergencyContact: patients.emergencyContact,
      allergies: patients.allergies,
      medications: patients.medications,
      medicalHistory: patients.medicalHistory,
      isActive: patients.isActive,
      createdAt: patients.createdAt,
      updatedAt: patients.updatedAt
    }).from(patients).where(and2(eq2(patients.tenantId, tenantId), eq2(patients.isActive, true))).orderBy(desc2(patients.updatedAt));
    const enhancedPatients = await Promise.all(
      patientsList.map(async (patient) => {
        const latestAppointments = await db.select({ appointmentDate: appointments.appointmentDate }).from(appointments).where(eq2(appointments.patientId, patient.id)).orderBy(desc2(appointments.appointmentDate)).limit(1);
        const upcomingCount = await db.select({ count: sql2`count(*)` }).from(appointments).where(
          and2(
            eq2(appointments.patientId, patient.id),
            sql2`${appointments.appointmentDate} > NOW()`
          )
        );
        const prescriptionCount = await db.select({ count: sql2`count(*)` }).from(prescriptions).where(
          and2(
            eq2(prescriptions.patientId, patient.id),
            sql2`${prescriptions.status} IN ('prescribed', 'sent_to_pharmacy', 'filled')`
          )
        );
        const labOrderCount = await db.select({ count: sql2`count(*)` }).from(labOrders).where(
          and2(
            eq2(labOrders.patientId, patient.id),
            sql2`${labOrders.status} IN ('ordered', 'collected', 'processing')`
          )
        );
        return {
          ...patient,
          lastVisit: latestAppointments[0]?.appointmentDate || null,
          upcomingAppointments: Number(upcomingCount[0]?.count) || 0,
          activePrescriptions: Number(prescriptionCount[0]?.count) || 0,
          pendingLabOrders: Number(labOrderCount[0]?.count) || 0
        };
      })
    );
    return enhancedPatients;
  }
  async getCompletePatientRecord(patientId, tenantId) {
    const [patient] = await db.select().from(patients).where(and2(eq2(patients.id, patientId), eq2(patients.tenantId, tenantId)));
    if (!patient) return null;
    const patientAppointments = await db.select({
      appointment: appointments,
      providerName: users.firstName,
      providerLastName: users.lastName,
      providerRole: users.role
    }).from(appointments).leftJoin(users, eq2(appointments.providerId, users.id)).where(eq2(appointments.patientId, patientId)).orderBy(desc2(appointments.appointmentDate));
    const patientPrescriptions = await db.select({
      prescription: prescriptions,
      providerName: users.firstName,
      providerLastName: users.lastName
    }).from(prescriptions).leftJoin(users, eq2(prescriptions.providerId, users.id)).where(eq2(prescriptions.patientId, patientId)).orderBy(desc2(prescriptions.prescribedDate));
    const patientLabOrders = await db.select().from(labOrders).where(eq2(labOrders.patientId, patientId)).orderBy(desc2(labOrders.createdAt));
    const patientVitalSigns = await db.select().from(vitalSigns).where(eq2(vitalSigns.patientId, patientId)).orderBy(desc2(vitalSigns.recordedAt));
    const patientVisitSummaries = await db.select({
      visitSummary: visitSummaries,
      providerName: users.firstName,
      providerLastName: users.lastName,
      providerRole: users.role
    }).from(visitSummaries).leftJoin(users, eq2(visitSummaries.providerId, users.id)).where(eq2(visitSummaries.patientId, patientId)).orderBy(desc2(visitSummaries.visitDate));
    return {
      ...patient,
      appointments: patientAppointments,
      prescriptions: patientPrescriptions,
      labOrders: patientLabOrders,
      vitalSigns: patientVitalSigns,
      visitSummaries: patientVisitSummaries
    };
  }
  // Cross-tenant patient sharing for healthcare networks
  async sharePatientWithTenant(originalPatientId, originalTenantId, targetTenantId, sharedByUserId, shareReason, shareType) {
    const originalPatient = await this.getPatient(originalPatientId, originalTenantId);
    if (!originalPatient) {
      throw new Error("Original patient not found");
    }
    const shareData = {
      originalPatientId,
      originalTenantId,
      sharedWithTenantId: targetTenantId,
      tenantPatientId: originalPatient.tenantPatientId,
      sharedByUserId,
      shareReason,
      shareType,
      accessLevel: "read_only",
      isActive: true
    };
    const [sharedPatient] = await db.insert(crossTenantPatients).values(shareData).returning();
    return sharedPatient;
  }
  async findSharedPatient(tenantPatientId, tenantId) {
    const directPatient = await this.getPatientByTenantPatientId(tenantPatientId, tenantId);
    if (directPatient) {
      return directPatient;
    }
    const [sharedRecord] = await db.select().from(crossTenantPatients).where(
      and2(
        eq2(crossTenantPatients.tenantPatientId, tenantPatientId),
        eq2(crossTenantPatients.sharedWithTenantId, tenantId),
        eq2(crossTenantPatients.isActive, true)
      )
    );
    if (sharedRecord) {
      return await this.getPatient(sharedRecord.originalPatientId, sharedRecord.originalTenantId);
    }
    return void 0;
  }
  async getSharedPatientsForTenant(tenantId) {
    return await db.select().from(crossTenantPatients).where(
      and2(
        eq2(crossTenantPatients.sharedWithTenantId, tenantId),
        eq2(crossTenantPatients.isActive, true)
      )
    ).orderBy(desc2(crossTenantPatients.createdAt));
  }
  // Appointment management
  async getAppointment(id, tenantId) {
    const [appointment] = await db.select().from(appointments).where(
      and2(eq2(appointments.id, id), eq2(appointments.tenantId, tenantId))
    );
    return appointment || void 0;
  }
  async createAppointment(insertAppointment) {
    const [appointment] = await db.insert(appointments).values(insertAppointment).returning();
    return appointment;
  }
  async updateAppointment(id, updates, tenantId) {
    const [appointment] = await db.update(appointments).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(eq2(appointments.id, id), eq2(appointments.tenantId, tenantId))).returning();
    return appointment || void 0;
  }
  async getAppointmentsByTenant(tenantId, date) {
    if (date) {
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);
      return await db.select().from(appointments).where(
        and2(
          eq2(appointments.tenantId, tenantId),
          sql2`${appointments.appointmentDate} >= ${startOfDay}`,
          sql2`${appointments.appointmentDate} <= ${endOfDay}`
        )
      ).orderBy(appointments.appointmentDate);
    }
    return await db.select().from(appointments).where(eq2(appointments.tenantId, tenantId)).orderBy(appointments.appointmentDate);
  }
  async getAppointmentsByProvider(providerId, tenantId, date) {
    let whereCondition = and2(eq2(appointments.providerId, providerId), eq2(appointments.tenantId, tenantId));
    if (date) {
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);
      whereCondition = and2(
        whereCondition,
        sql2`${appointments.appointmentDate} >= ${startOfDay}`,
        sql2`${appointments.appointmentDate} <= ${endOfDay}`
      );
    }
    return await db.select().from(appointments).where(whereCondition).orderBy(appointments.appointmentDate);
  }
  async getAppointmentsByPatient(patientId, tenantId) {
    return await db.select({
      // Appointment details
      id: appointments.id,
      patientId: appointments.patientId,
      providerId: appointments.providerId,
      appointmentDate: appointments.appointmentDate,
      type: appointments.type,
      status: appointments.status,
      notes: appointments.notes,
      chiefComplaint: appointments.chiefComplaint,
      tenantId: appointments.tenantId,
      createdAt: appointments.createdAt,
      updatedAt: appointments.updatedAt,
      // Provider information
      providerFirstName: users.firstName,
      providerLastName: users.lastName,
      providerEmail: users.email,
      providerRole: users.role,
      // Visit summary information (if exists)
      visitSummaryId: visitSummaries.id,
      visitSummaryStatus: visitSummaries.status,
      visitSummaryChiefComplaint: visitSummaries.chiefComplaint,
      visitSummaryAssessment: visitSummaries.assessment,
      visitSummaryClinicalImpression: visitSummaries.clinicalImpression,
      visitSummaryTreatmentPlan: visitSummaries.treatmentPlan,
      visitSummaryReturnVisitRecommended: visitSummaries.returnVisitRecommended,
      visitSummaryReturnVisitTimeframe: visitSummaries.returnVisitTimeframe,
      visitSummaryProviderNotes: visitSummaries.providerNotes
    }).from(appointments).leftJoin(users, eq2(appointments.providerId, users.id)).leftJoin(visitSummaries, eq2(appointments.id, visitSummaries.appointmentId)).where(and2(eq2(appointments.patientId, patientId), eq2(appointments.tenantId, tenantId))).orderBy(desc2(appointments.appointmentDate));
  }
  async getAppointmentsByPatientWithDoctorInfo(patientId, tenantId) {
    return await db.select({
      id: appointments.id,
      appointment_date: appointments.appointmentDate,
      type: appointments.type,
      status: appointments.status,
      notes: appointments.notes,
      chief_complaint: appointments.chiefComplaint,
      doctor_first_name: users.firstName,
      doctor_last_name: users.lastName,
      doctor_role: users.role
    }).from(appointments).leftJoin(users, eq2(appointments.providerId, users.id)).where(and2(eq2(appointments.patientId, patientId), eq2(appointments.tenantId, tenantId))).orderBy(desc2(appointments.appointmentDate));
  }
  // Prescription management
  async getPrescription(id, tenantId) {
    const [prescription] = await db.select().from(prescriptions).where(
      and2(eq2(prescriptions.id, id), eq2(prescriptions.tenantId, tenantId))
    );
    return prescription || void 0;
  }
  // Get prescription by ID for pharmacy (regardless of which hospital created it)
  async getPrescriptionForPharmacy(id, pharmacyTenantId) {
    const [prescription] = await db.select().from(prescriptions).where(
      and2(eq2(prescriptions.id, id), eq2(prescriptions.pharmacyTenantId, pharmacyTenantId))
    );
    return prescription || void 0;
  }
  async createPrescription(insertPrescription) {
    const [prescription] = await db.insert(prescriptions).values(insertPrescription).returning();
    return prescription;
  }
  async getPrescriptionsByPatient(patientId, tenantId) {
    return await db.select().from(prescriptions).where(
      and2(eq2(prescriptions.patientId, patientId), eq2(prescriptions.tenantId, tenantId))
    ).orderBy(desc2(prescriptions.prescribedDate));
  }
  async getPrescriptionsByTenant(tenantId) {
    console.log(`[HOSPITAL API] \u{1F50D} Getting prescriptions for hospital: ${tenantId}`);
    const prescriptionsResult = await db.execute(sql2`
      SELECT 
        id,
        medication_name,
        dosage,
        frequency,
        quantity,
        refills,
        instructions,
        status,
        prescribed_date,
        expiry_date,
        pharmacy_tenant_id,
        patient_id,
        provider_id
      FROM prescriptions 
      WHERE tenant_id = ${tenantId}::uuid
      ORDER BY prescribed_date DESC
    `);
    const prescriptionsWithNames = [];
    const prescriptionsList = Array.isArray(prescriptionsResult) ? prescriptionsResult : prescriptionsResult.rows || [];
    for (const prescription of prescriptionsList) {
      const patientResult = await db.execute(sql2`
        SELECT first_name, last_name, mrn, email, phone 
        FROM patients 
        WHERE id = ${prescription.patient_id}::uuid
      `);
      const doctorResult = await db.execute(sql2`
        SELECT first_name, last_name, role 
        FROM users 
        WHERE id = ${prescription.provider_id}::text
      `);
      const patient = patientResult.rows[0] || {};
      const doctor = doctorResult.rows[0] || {};
      prescriptionsWithNames.push({
        ...prescription,
        patient_first_name: patient.first_name,
        patient_last_name: patient.last_name,
        patient_mrn: patient.mrn,
        patient_email: patient.email,
        patient_phone: patient.phone,
        provider_first_name: doctor.first_name,
        provider_last_name: doctor.last_name,
        provider_role: doctor.role
      });
    }
    console.log(`[HOSPITAL API] \u2705 Found ${prescriptionsWithNames.length} prescriptions with patient/doctor names`);
    const formattedPrescriptions = prescriptionsWithNames.map((p) => ({
      id: p.id,
      patientName: p.patient_first_name && p.patient_last_name ? `${p.patient_first_name} ${p.patient_last_name}` : `Patient ${p.patient_id}`,
      patientMrn: p.patient_mrn,
      medication: p.medication_name,
      medicationName: p.medication_name,
      // Include both for compatibility
      dosage: p.dosage,
      frequency: p.frequency,
      quantity: p.quantity,
      refills: p.refills,
      instructions: p.instructions,
      providerName: p.provider_first_name && p.provider_last_name ? `Dr. ${p.provider_first_name} ${p.provider_last_name}` : `Provider ${p.provider_id}`,
      doctorRole: p.provider_role,
      status: p.status,
      prescribedDate: p.prescribed_date,
      expiryDate: p.expiry_date,
      pharmacyTenantId: p.pharmacy_tenant_id,
      // Patient contact information
      patientEmail: p.patient_email,
      patientPhone: p.patient_phone
    }));
    console.log(
      `[HOSPITAL API] \u{1F4CB} Returning ${formattedPrescriptions.length} formatted prescriptions:`,
      formattedPrescriptions.map((p) => ({
        patient: p.patientName,
        doctor: p.providerName,
        medication: p.medication
      }))
    );
    return formattedPrescriptions;
  }
  async getPrescriptionsByPharmacyTenant(pharmacyTenantId) {
    return await db.select().from(prescriptions).where(eq2(prescriptions.pharmacyTenantId, pharmacyTenantId)).orderBy(desc2(prescriptions.prescribedDate));
  }
  async getPrescriptionsByPharmacy(pharmacyTenantId) {
    console.log(`[PHARMACY API] \u{1F50D} Getting prescriptions for pharmacy: ${pharmacyTenantId}`);
    const prescriptionsResult = await db.execute(sql2`
      SELECT 
        id,
        medication_name,
        dosage,
        frequency,
        quantity,
        instructions,
        status,
        prescribed_date,
        expiry_date,
        pharmacy_tenant_id,
        patient_id,
        provider_id
      FROM prescriptions 
      WHERE pharmacy_tenant_id = ${pharmacyTenantId}::uuid
      ORDER BY prescribed_date DESC
    `);
    const prescriptionsWithNames = [];
    const prescriptionsList = Array.isArray(prescriptionsResult) ? prescriptionsResult : prescriptionsResult.rows || [];
    for (const prescription of prescriptionsList) {
      const patientResult = await db.execute(sql2`
        SELECT first_name, last_name, mrn, email, phone, insurance_info
        FROM patients 
        WHERE id = ${prescription.patient_id}::uuid
      `);
      const doctorResult = await db.execute(sql2`
        SELECT first_name, last_name, role 
        FROM users 
        WHERE id = ${prescription.provider_id}::text
      `);
      const patient = patientResult.rows[0] || {};
      const doctor = doctorResult.rows[0] || {};
      let insuranceData = {};
      try {
        if (patient.insurance_info) {
          insuranceData = typeof patient.insurance_info === "string" ? JSON.parse(patient.insurance_info) : patient.insurance_info;
        }
      } catch (e) {
        console.log("Error parsing insurance data:", e);
        insuranceData = {};
      }
      prescriptionsWithNames.push({
        ...prescription,
        patient_first_name: patient.first_name,
        patient_last_name: patient.last_name,
        patient_mrn: patient.mrn,
        patient_email: patient.email,
        patient_phone: patient.phone,
        patient_insurance: insuranceData,
        provider_first_name: doctor.first_name,
        provider_last_name: doctor.last_name,
        provider_role: doctor.role
      });
    }
    console.log(`[PHARMACY API] \u2705 Found ${prescriptionsWithNames.length} prescriptions with patient/doctor names`);
    const formattedPrescriptions = prescriptionsWithNames.map((p) => ({
      id: p.id,
      patientName: p.patient_first_name && p.patient_last_name ? `${p.patient_first_name} ${p.patient_last_name}` : `Patient ${p.patient_id}`,
      patientMrn: p.patient_mrn,
      medication: p.medication_name,
      dosage: p.dosage,
      frequency: p.frequency,
      quantity: p.quantity,
      instructions: p.instructions,
      prescribingDoctor: p.provider_first_name && p.provider_last_name ? `Dr. ${p.provider_first_name} ${p.provider_last_name}` : `Provider ${p.provider_id}`,
      providerName: p.provider_first_name && p.provider_last_name ? `Dr. ${p.provider_first_name} ${p.provider_last_name}` : `Unknown Provider`,
      doctorName: p.provider_first_name && p.provider_last_name ? `Dr. ${p.provider_first_name} ${p.provider_last_name}` : `Unknown Provider`,
      doctorRole: p.provider_role,
      status: p.status === "prescribed" ? "new" : p.status === "dispensed" ? "ready" : p.status,
      prescribedDate: p.prescribed_date,
      expiryDate: p.expiry_date,
      // Patient contact information
      patientEmail: p.patient_email,
      patientPhone: p.patient_phone,
      // Real insurance information from patient records - CRITICAL FOR PHARMACY FILING
      insuranceProvider: p.patient_insurance?.provider || p.patient_insurance?.insuranceProvider || "No Insurance on File",
      policyNumber: p.patient_insurance?.policyNumber || "Not Available",
      copayAmount: p.patient_insurance?.copayAmount || p.patient_insurance?.copay || 0,
      deductibleAmount: p.patient_insurance?.deductibleAmount || p.patient_insurance?.deductible || 0,
      groupNumber: p.patient_insurance?.groupNumber || "N/A",
      memberNumber: p.patient_insurance?.memberNumber || p.patient_insurance?.memberId || "N/A",
      insurancePlan: p.patient_insurance?.planName || p.patient_insurance?.plan || "N/A",
      waitTime: Math.floor(Math.random() * 20),
      // Demo wait time
      priority: "normal",
      insuranceStatus: p.patient_insurance?.provider ? "verified" : "pending"
    }));
    console.log(
      `[PHARMACY API] \u{1F4CB} Returning ${formattedPrescriptions.length} formatted prescriptions:`,
      formattedPrescriptions.map((p) => ({
        patient: p.patientName,
        doctor: p.prescribingDoctor,
        medication: p.medication
      }))
    );
    return formattedPrescriptions;
  }
  async updatePrescriptionStatus(prescriptionId, newStatus) {
    console.log(`[PHARMACY API] \u{1F504} Updating prescription ${prescriptionId} to status: ${newStatus}`);
    try {
      if (newStatus === "dispensed") {
        console.log(`[PHARMACY API] \u{1F4E6} Archiving dispensed prescription: ${prescriptionId}`);
        const [currentPrescription] = await db.select().from(prescriptions).where(eq2(prescriptions.id, prescriptionId));
        if (!currentPrescription) {
          throw new Error("Prescription not found");
        }
        await db.execute(sql2`
          INSERT INTO prescription_archives (
            tenant_id, 
            shift_id,
            original_prescription_id,
            patient_data,
            prescription_data,
            receipt_data,
            archived_by
          ) VALUES (
            ${currentPrescription.pharmacyTenantId || currentPrescription.tenantId},
            NULL,
            ${currentPrescription.id},
            ${JSON.stringify({
          id: currentPrescription.patientId,
          name: "Patient",
          // We'll get this from a join if needed
          medication: currentPrescription.medicationName
        })},
            ${JSON.stringify({
          id: currentPrescription.id,
          medicationName: currentPrescription.medicationName,
          dosage: currentPrescription.dosage,
          frequency: currentPrescription.frequency,
          quantity: currentPrescription.quantity,
          refills: currentPrescription.refills,
          instructions: currentPrescription.instructions,
          status: "dispensed",
          prescribedDate: currentPrescription.prescribedDate,
          dispensedDate: /* @__PURE__ */ new Date(),
          insuranceProvider: currentPrescription.insuranceProvider,
          insuranceCopay: currentPrescription.insuranceCopay,
          insuranceCoveragePercentage: currentPrescription.insuranceCoveragePercentage,
          totalCost: currentPrescription.totalCost,
          pharmacyNotes: currentPrescription.pharmacyNotes
        })},
            ${JSON.stringify({
          claimNumber: `CLM-${(/* @__PURE__ */ new Date()).getFullYear()}-${String(Date.now()).slice(-6)}`,
          transactionId: `TXN-${(/* @__PURE__ */ new Date()).getFullYear()}-${String(Date.now()).slice(-8)}`,
          dispensedAt: /* @__PURE__ */ new Date(),
          dispensedBy: "system"
        })},
            NULL
          )
        `);
        await db.delete(prescriptions).where(eq2(prescriptions.id, prescriptionId));
        console.log(`[PHARMACY API] \u2705 Prescription ${prescriptionId} archived and removed from active queue`);
        return { ...currentPrescription, status: "dispensed", archived: true };
      } else {
        const [updatedPrescription] = await db.update(prescriptions).set({
          status: newStatus,
          updatedAt: /* @__PURE__ */ new Date()
        }).where(eq2(prescriptions.id, prescriptionId)).returning();
        if (!updatedPrescription) {
          throw new Error("Prescription not found");
        }
        console.log(`[PHARMACY API] \u2705 Successfully updated prescription status to: ${newStatus}`);
        return updatedPrescription;
      }
    } catch (error) {
      console.error(`[PHARMACY API] \u274C Error updating prescription status:`, error);
      throw error;
    }
  }
  async getPrescriptionArchives(tenantId) {
    try {
      console.log(`[PHARMACY API] \u{1F50D} Getting prescription archives for tenant: ${tenantId}`);
      const archiveResults = await db.execute(sql2`
        SELECT * FROM prescription_archives 
        WHERE tenant_id = ${tenantId}
        ORDER BY archived_at DESC
      `);
      console.log(`[PHARMACY API] \u2705 Found ${Array.isArray(archiveResults.rows) ? archiveResults.rows.length : 0} archived prescriptions`);
      return (archiveResults.rows || []).map((row) => ({
        id: row.id,
        originalPrescriptionId: row.original_prescription_id,
        tenantId: row.tenant_id,
        patientData: row.patient_data,
        prescriptionData: row.prescription_data,
        receiptData: row.receipt_data,
        archivedAt: row.archived_at,
        archivedBy: row.archived_by
      }));
    } catch (error) {
      console.error(`[PHARMACY API] \u274C Error getting prescription archives:`, error);
      throw error;
    }
  }
  async updatePrescription(id, updates, tenantId) {
    const [prescription] = await db.update(prescriptions).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(
      and2(
        eq2(prescriptions.id, id),
        or(
          eq2(prescriptions.tenantId, tenantId),
          // Hospital/clinic that created it
          eq2(prescriptions.pharmacyTenantId, tenantId)
          // Pharmacy that received it
        )
      )
    ).returning();
    return prescription || void 0;
  }
  // Lab order management
  async getLabOrder(id, tenantId) {
    const [labOrder] = await db.select().from(labOrders).where(
      and2(eq2(labOrders.id, id), eq2(labOrders.tenantId, tenantId))
    );
    return labOrder || void 0;
  }
  async createLabOrder(insertLabOrder) {
    const [labOrder] = await db.insert(labOrders).values(insertLabOrder).returning();
    return labOrder;
  }
  async updateLabOrder(id, updates, tenantId) {
    const [labOrder] = await db.update(labOrders).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(eq2(labOrders.id, id), eq2(labOrders.tenantId, tenantId))).returning();
    if (labOrder && updates.status === "completed") {
      try {
        const [associatedBill] = await db.select().from(labBills).where(eq2(labBills.labOrderId, id));
        if (associatedBill) {
          await db.update(labBills).set({
            status: "completed",
            updatedAt: sql2`CURRENT_TIMESTAMP`
          }).where(eq2(labBills.id, associatedBill.id));
          console.log(`[LAB BILLING SYNC] Updated bill status to 'completed' for lab order ${id}, bill ID: ${associatedBill.id}`);
        }
      } catch (error) {
        console.error(`[LAB BILLING SYNC] Error updating bill status for lab order ${id}:`, error);
      }
    }
    return labOrder || void 0;
  }
  async getLabOrdersByPatient(patientId, tenantId) {
    const whereConditions = tenantId ? and2(eq2(labOrders.patientId, patientId), eq2(labOrders.tenantId, tenantId)) : eq2(labOrders.patientId, patientId);
    return await db.select().from(labOrders).where(whereConditions).orderBy(desc2(labOrders.orderedDate));
  }
  async getLabOrdersByTenant(tenantId) {
    return await db.select().from(labOrders).where(
      and2(
        eq2(labOrders.tenantId, tenantId),
        sql2`${labOrders.status} NOT IN ('completed', 'cancelled')`
      )
    ).orderBy(desc2(labOrders.orderedDate));
  }
  async getArchivedLabOrdersByTenant(tenantId) {
    return await db.select().from(labOrders).where(
      and2(
        eq2(labOrders.tenantId, tenantId),
        sql2`${labOrders.status} IN ('completed', 'cancelled')`
      )
    ).orderBy(desc2(labOrders.orderedDate));
  }
  // Get lab orders sent TO a specific laboratory (cross-tenant)
  async getLabOrdersByLabTenant(labTenantId) {
    return await db.select().from(labOrders).where(eq2(labOrders.labTenantId, labTenantId)).orderBy(desc2(labOrders.orderedDate));
  }
  // Get patient record by user ID (for patient portal)
  async getPatientByUserId(userId, tenantId) {
    const user = await this.getUser(userId);
    if (!user) return void 0;
    const [patient] = await db.select().from(patients).where(
      and2(
        eq2(patients.firstName, user.firstName),
        eq2(patients.lastName, user.lastName),
        eq2(patients.tenantId, tenantId)
      )
    );
    return patient || void 0;
  }
  // Get lab orders sent to a specific laboratory (cross-tenant)
  async getLabOrdersForLaboratory(laboratoryTenantId) {
    const orders = await db.select({
      id: labOrders.id,
      testName: labOrders.testName,
      testCode: labOrders.testCode,
      instructions: labOrders.instructions,
      priority: labOrders.priority,
      status: labOrders.status,
      orderedDate: labOrders.orderedDate,
      patientId: labOrders.patientId,
      originatingHospitalId: labOrders.tenantId
    }).from(labOrders).where(eq2(labOrders.labTenantId, laboratoryTenantId)).orderBy(desc2(labOrders.orderedDate));
    const enrichedOrders = await Promise.all(orders.map(async (order) => {
      const patientInfo = await db.select({
        firstName: patients.firstName,
        lastName: patients.lastName,
        mrn: patients.mrn
      }).from(patients).where(eq2(patients.id, order.patientId)).limit(1);
      const hospitalInfo = await db.select({
        name: tenants.name
      }).from(tenants).where(eq2(tenants.id, order.originatingHospitalId)).limit(1);
      return {
        ...order,
        patientFirstName: patientInfo[0]?.firstName || "Unknown",
        patientLastName: patientInfo[0]?.lastName || "Patient",
        patientMrn: patientInfo[0]?.mrn || "N/A",
        originatingHospital: hospitalInfo[0]?.name || "Unknown Hospital"
      };
    }));
    return enrichedOrders;
  }
  async getPendingLabOrders(tenantId) {
    return await db.select().from(labOrders).where(
      and2(
        eq2(labOrders.tenantId, tenantId),
        sql2`${labOrders.status} IN ('ordered', 'collected', 'processing')`
      )
    ).orderBy(labOrders.orderedDate);
  }
  async getArchivedLabOrdersForLaboratory(tenantId) {
    const orders = await db.select().from(labOrders).where(
      and2(
        eq2(labOrders.labTenantId, tenantId),
        sql2`${labOrders.status} IN ('completed', 'cancelled')`
      )
    ).orderBy(desc2(labOrders.orderedDate));
    const enrichedOrders = await Promise.all(orders.map(async (order) => {
      const patient = await db.select().from(patients).where(eq2(patients.id, order.patientId)).limit(1);
      const hospital = await db.select().from(tenants).where(eq2(tenants.id, order.tenantId)).limit(1);
      return {
        ...order,
        patientMrn: patient[0]?.mrn,
        patientFirstName: patient[0]?.firstName,
        patientLastName: patient[0]?.lastName,
        patientDateOfBirth: patient[0]?.dateOfBirth,
        originatingHospital: hospital[0]?.name
      };
    }));
    return enrichedOrders;
  }
  // Get patients who have lab orders at this laboratory (for billing purposes)
  async getPatientsWithLabOrdersForLaboratory(laboratoryTenantId) {
    const orders = await db.select({
      patientId: labOrders.patientId
    }).from(labOrders).where(eq2(labOrders.labTenantId, laboratoryTenantId)).groupBy(labOrders.patientId);
    const patientsWithLabOrders = await Promise.all(orders.map(async (order) => {
      const [patient] = await db.select().from(patients).where(eq2(patients.id, order.patientId)).limit(1);
      if (!patient) return null;
      const [latestOrder] = await db.select({
        tenantId: labOrders.tenantId
      }).from(labOrders).where(and2(
        eq2(labOrders.patientId, order.patientId),
        eq2(labOrders.labTenantId, laboratoryTenantId)
      )).orderBy(desc2(labOrders.orderedDate)).limit(1);
      let hospitalName = "Unknown Hospital";
      if (latestOrder) {
        const [hospital] = await db.select({
          name: tenants.name
        }).from(tenants).where(eq2(tenants.id, latestOrder.tenantId)).limit(1);
        hospitalName = hospital?.name || "Unknown Hospital";
      }
      return {
        ...patient,
        originatingHospital: hospitalName
      };
    }));
    const validPatients = patientsWithLabOrders.filter((p) => p !== null);
    console.log(`\u{1F9EA} STORAGE - Found ${validPatients.length} unique patients with lab orders for laboratory`);
    return validPatients;
  }
  async getLabOrdersByPatientMrn(patientMrn) {
    const patientResult = await db.select().from(patients).where(eq2(patients.mrn, patientMrn));
    if (patientResult.length === 0) {
      return [];
    }
    const patient = patientResult[0];
    const orders = await db.select().from(labOrders).where(eq2(labOrders.patientId, patient.id)).orderBy(desc2(labOrders.orderedDate));
    const enrichedOrders = await Promise.all(orders.map(async (order) => {
      const hospital = await db.select().from(tenants).where(eq2(tenants.id, order.tenantId)).limit(1);
      return {
        ...order,
        patientMrn: patient.mrn,
        patientFirstName: patient.firstName,
        patientLastName: patient.lastName,
        patientDateOfBirth: patient.dateOfBirth,
        originatingHospital: hospital[0]?.name
      };
    }));
    return enrichedOrders;
  }
  // Pharmacy management
  async getPharmacy(id, tenantId) {
    const [pharmacy] = await db.select().from(pharmacies).where(
      and2(eq2(pharmacies.id, id), eq2(pharmacies.tenantId, tenantId))
    );
    return pharmacy || void 0;
  }
  async createPharmacy(insertPharmacy) {
    const [pharmacy] = await db.insert(pharmacies).values([insertPharmacy]).returning();
    return pharmacy;
  }
  async updatePharmacy(id, updates, tenantId) {
    const [pharmacy] = await db.update(pharmacies).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(eq2(pharmacies.id, id), eq2(pharmacies.tenantId, tenantId))).returning();
    return pharmacy || void 0;
  }
  async getPharmaciesByTenant(tenantId) {
    return await db.select().from(pharmacies).where(eq2(pharmacies.tenantId, tenantId)).orderBy(pharmacies.name);
  }
  async getActivePharmacies(tenantId) {
    return await db.select().from(pharmacies).where(
      and2(eq2(pharmacies.tenantId, tenantId), eq2(pharmacies.isActive, true))
    ).orderBy(pharmacies.name);
  }
  async getPharmaciesForPrescriptionRouting() {
    const pharmacyTenants = await db.select({
      id: tenants.id,
      name: tenants.name,
      type: tenants.type,
      subdomain: tenants.subdomain,
      isActive: tenants.isActive
    }).from(tenants).where(
      and2(eq2(tenants.type, "pharmacy"), eq2(tenants.isActive, true))
    ).orderBy(tenants.name);
    return pharmacyTenants;
  }
  // Insurance claims management
  async getInsuranceClaim(id, tenantId) {
    try {
      const [claim] = await db.select().from(insuranceClaims).where(and2(eq2(insuranceClaims.id, id), eq2(insuranceClaims.tenantId, tenantId)));
      if (!claim) {
        return void 0;
      }
      const [patient] = await db.select({
        firstName: patients.firstName,
        lastName: patients.lastName,
        mrn: patients.mrn
      }).from(patients).where(eq2(patients.id, claim.patientId));
      return {
        ...claim,
        patientFirstName: patient?.firstName || "N/A",
        patientLastName: patient?.lastName || "N/A",
        patientMrn: patient?.mrn || "N/A"
      };
    } catch (error) {
      console.error("Error in getInsuranceClaim:", error);
      return void 0;
    }
  }
  async createInsuranceClaim(insertClaim) {
    const [claim] = await db.insert(insuranceClaims).values(insertClaim).returning();
    return claim;
  }
  async updateInsuranceClaim(id, updates, tenantId) {
    const [claim] = await db.update(insuranceClaims).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(eq2(insuranceClaims.id, id), eq2(insuranceClaims.tenantId, tenantId))).returning();
    return claim || void 0;
  }
  async getInsuranceClaimsByTenant(tenantId) {
    try {
      const claims = await db.select().from(insuranceClaims).where(eq2(insuranceClaims.tenantId, tenantId));
      const claimsWithPatients = await Promise.all(
        claims.map(async (claim) => {
          try {
            const [patient] = await db.select({
              firstName: patients.firstName,
              lastName: patients.lastName,
              mrn: patients.mrn
            }).from(patients).where(eq2(patients.id, claim.patientId));
            let medicationName = "";
            let dosage = "";
            let quantity = "";
            if (claim.notes) {
              const noteMatch = claim.notes.match(/Medication: ([^,]+), Dosage: ([^,]+), Quantity: ([^,]+)/);
              if (noteMatch) {
                medicationName = noteMatch[1].trim();
                dosage = noteMatch[2].trim();
                quantity = noteMatch[3].trim();
              }
            }
            return {
              ...claim,
              patientFirstName: patient?.firstName || "N/A",
              patientLastName: patient?.lastName || "N/A",
              patientMrn: patient?.mrn || "N/A",
              // Map database fields to frontend expected names - CRITICAL FOR CLAIMS DISPLAY
              medicationName,
              dosage,
              quantity,
              claimAmount: claim.totalAmount,
              submittedAt: claim.submittedDate,
              claimNumber: claim.claimNumber
            };
          } catch (error) {
            console.error("Error fetching patient for claim:", claim.id, error);
            let medicationName = "";
            let dosage = "";
            let quantity = "";
            if (claim.notes) {
              const noteMatch = claim.notes.match(/Medication: ([^,]+), Dosage: ([^,]+), Quantity: ([^,]+)/);
              if (noteMatch) {
                medicationName = noteMatch[1].trim();
                dosage = noteMatch[2].trim();
                quantity = noteMatch[3].trim();
              }
            }
            return {
              ...claim,
              patientFirstName: "Unknown",
              patientLastName: "Patient",
              patientMrn: "N/A",
              // Map database fields to frontend expected names - CRITICAL FOR CLAIMS DISPLAY
              medicationName,
              dosage,
              quantity,
              claimAmount: claim.totalAmount,
              submittedAt: claim.submittedDate,
              claimNumber: claim.claimNumber
            };
          }
        })
      );
      return claimsWithPatients.sort(
        (a, b) => new Date(b.submittedDate || 0).getTime() - new Date(a.submittedDate || 0).getTime()
      );
    } catch (error) {
      console.error("Error in getInsuranceClaimsByTenant:", error);
      throw error;
    }
  }
  async getInsuranceClaimsByPatient(patientId, tenantId) {
    return await db.select().from(insuranceClaims).where(
      and2(eq2(insuranceClaims.patientId, patientId), eq2(insuranceClaims.tenantId, tenantId))
    ).orderBy(desc2(insuranceClaims.createdAt));
  }
  // Insurance Provider management
  async getInsuranceProviders(tenantId) {
    return await db.select().from(insuranceProviders).where(
      and2(eq2(insuranceProviders.tenantId, tenantId), eq2(insuranceProviders.isActive, true))
    ).orderBy(insuranceProviders.name);
  }
  async createInsuranceProvider(provider) {
    const [insuranceProvider] = await db.insert(insuranceProviders).values(provider).returning();
    return insuranceProvider;
  }
  // Patient Insurance management
  async getPatientInsurance(patientId, tenantId) {
    return await db.select().from(patientInsurance).where(
      and2(eq2(patientInsurance.patientId, patientId), eq2(patientInsurance.tenantId, tenantId))
    ).orderBy(desc2(patientInsurance.isPrimary), patientInsurance.effectiveDate);
  }
  async createPatientInsurance(insurance) {
    const [patientIns] = await db.insert(patientInsurance).values(insurance).returning();
    return patientIns;
  }
  // Service Pricing management
  async getServicePrices(tenantId) {
    return await db.select().from(servicePrices).where(
      and2(eq2(servicePrices.tenantId, tenantId), eq2(servicePrices.isActive, true))
    ).orderBy(servicePrices.serviceName);
  }
  async getServicePrice(id, tenantId) {
    const [servicePrice] = await db.select().from(servicePrices).where(
      and2(eq2(servicePrices.id, id), eq2(servicePrices.tenantId, tenantId))
    );
    return servicePrice || void 0;
  }
  async createServicePrice(servicePrice) {
    const [newServicePrice] = await db.insert(servicePrices).values(servicePrice).returning();
    return newServicePrice;
  }
  async updateServicePrice(id, updates, tenantId) {
    const [servicePrice] = await db.update(servicePrices).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(eq2(servicePrices.id, id), eq2(servicePrices.tenantId, tenantId))).returning();
    return servicePrice || void 0;
  }
  async getServicePriceByCode(serviceCode, tenantId) {
    const [servicePrice] = await db.select().from(servicePrices).where(
      and2(
        eq2(servicePrices.serviceCode, serviceCode),
        eq2(servicePrices.tenantId, tenantId),
        eq2(servicePrices.isActive, true)
      )
    );
    return servicePrice || void 0;
  }
  // Insurance Plan Coverage management
  async getInsurancePlanCoverages(tenantId) {
    return await db.select().from(insurancePlanCoverage).where(
      and2(eq2(insurancePlanCoverage.tenantId, tenantId), eq2(insurancePlanCoverage.isActive, true))
    ).orderBy(insurancePlanCoverage.effectiveDate);
  }
  async getInsurancePlanCoverageByServiceAndProvider(servicePriceId, insuranceProviderId, tenantId) {
    const [coverage] = await db.select().from(insurancePlanCoverage).where(
      and2(
        eq2(insurancePlanCoverage.servicePriceId, servicePriceId),
        eq2(insurancePlanCoverage.insuranceProviderId, insuranceProviderId),
        eq2(insurancePlanCoverage.tenantId, tenantId),
        eq2(insurancePlanCoverage.isActive, true)
      )
    );
    return coverage || void 0;
  }
  async createInsurancePlanCoverage(coverage) {
    const [newCoverage] = await db.insert(insurancePlanCoverage).values(coverage).returning();
    return newCoverage;
  }
  async updateInsurancePlanCoverage(id, updates, tenantId) {
    const [coverage] = await db.update(insurancePlanCoverage).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(eq2(insurancePlanCoverage.id, id), eq2(insurancePlanCoverage.tenantId, tenantId))).returning();
    return coverage || void 0;
  }
  // Claim Line Items management
  async getClaimLineItems(claimId, tenantId) {
    return await db.select().from(claimLineItems).where(
      and2(eq2(claimLineItems.claimId, claimId), eq2(claimLineItems.tenantId, tenantId))
    ).orderBy(claimLineItems.createdAt);
  }
  async createClaimLineItem(lineItem) {
    const [newLineItem] = await db.insert(claimLineItems).values(lineItem).returning();
    return newLineItem;
  }
  async updateClaimLineItem(id, updates, tenantId) {
    const [lineItem] = await db.update(claimLineItems).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(eq2(claimLineItems.id, id), eq2(claimLineItems.tenantId, tenantId))).returning();
    return lineItem || void 0;
  }
  async deleteClaimLineItem(id, tenantId) {
    const result = await db.delete(claimLineItems).where(and2(eq2(claimLineItems.id, id), eq2(claimLineItems.tenantId, tenantId)));
    return result.rowCount > 0;
  }
  // Pricing calculations
  async calculateCopayAndInsuranceAmount(servicePriceId, insuranceProviderId, patientInsuranceId, tenantId) {
    const servicePrice = await this.getServicePrice(servicePriceId, tenantId);
    if (!servicePrice) {
      throw new Error("Service price not found");
    }
    const unitPrice = parseFloat(servicePrice.basePrice);
    const coverage = await this.getInsurancePlanCoverageByServiceAndProvider(
      servicePriceId,
      insuranceProviderId,
      tenantId
    );
    if (!coverage) {
      const [patientIns] = await db.select().from(patientInsurance).where(
        and2(eq2(patientInsurance.id, patientInsuranceId), eq2(patientInsurance.tenantId, tenantId))
      );
      if (patientIns && patientIns.copayAmount) {
        const copayAmount3 = Math.min(parseFloat(patientIns.copayAmount), unitPrice);
        return {
          unitPrice,
          copayAmount: copayAmount3,
          insuranceAmount: unitPrice - copayAmount3,
          deductibleAmount: 0
        };
      }
      const copayAmount2 = unitPrice * 0.2;
      return {
        unitPrice,
        copayAmount: copayAmount2,
        insuranceAmount: unitPrice - copayAmount2,
        deductibleAmount: 0
      };
    }
    let copayAmount = 0;
    let deductibleAmount = 0;
    if (coverage.copayAmount) {
      copayAmount = Math.min(parseFloat(coverage.copayAmount), unitPrice);
    } else if (coverage.copayPercentage) {
      copayAmount = unitPrice * (parseFloat(coverage.copayPercentage) / 100);
    }
    let insuranceAmount = unitPrice - copayAmount - deductibleAmount;
    if (coverage.maxCoverageAmount) {
      const maxCoverage = parseFloat(coverage.maxCoverageAmount);
      if (insuranceAmount > maxCoverage) {
        const excess = insuranceAmount - maxCoverage;
        insuranceAmount = maxCoverage;
        copayAmount += excess;
      }
    }
    return {
      unitPrice,
      copayAmount,
      insuranceAmount,
      deductibleAmount
    };
  }
  // Audit logging
  async createAuditLog(log2) {
    const [auditLog] = await db.insert(auditLogs).values(log2).returning();
    return auditLog;
  }
  async getAuditLogs(tenantId, limit = 50, offset = 0) {
    return await db.select().from(auditLogs).where(eq2(auditLogs.tenantId, tenantId)).orderBy(desc2(auditLogs.timestamp)).limit(limit).offset(offset);
  }
  // Dashboard metrics
  async getDashboardMetrics(tenantId) {
    const today = /* @__PURE__ */ new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const [todayAppointmentsResult] = await db.select({ count: sql2`count(*)` }).from(appointments).where(
      and2(
        eq2(appointments.tenantId, tenantId),
        sql2`${appointments.appointmentDate} >= ${today}`,
        sql2`${appointments.appointmentDate} < ${tomorrow}`
      )
    );
    const [pendingLabResultsResult] = await db.select({ count: sql2`count(*)` }).from(labOrders).where(
      and2(
        eq2(labOrders.tenantId, tenantId),
        sql2`${labOrders.status} IN ('ordered', 'collected', 'processing')`
      )
    );
    const [activePrescriptionsResult] = await db.select({ count: sql2`count(*)` }).from(prescriptions).where(
      and2(
        eq2(prescriptions.tenantId, tenantId),
        sql2`${prescriptions.status} IN ('prescribed', 'sent_to_pharmacy', 'filled')`
      )
    );
    const [monthlyClaimsResult] = await db.select({
      total: sql2`COALESCE(SUM(${insuranceClaims.totalAmount}), 0)`
    }).from(insuranceClaims).where(
      and2(
        eq2(insuranceClaims.tenantId, tenantId),
        sql2`${insuranceClaims.createdAt} >= ${firstDayOfMonth}`
      )
    );
    return {
      todayAppointments: Number(todayAppointmentsResult.count) || 0,
      pendingLabResults: Number(pendingLabResultsResult.count) || 0,
      activePrescriptions: Number(activePrescriptionsResult.count) || 0,
      monthlyClaimsTotal: Number(monthlyClaimsResult.total) || 0
    };
  }
  // Subscription management
  async getSubscription(tenantId) {
    const [subscription] = await db.select().from(subscriptions).where(eq2(subscriptions.tenantId, tenantId));
    return subscription || void 0;
  }
  async createSubscription(insertSubscription) {
    const [subscription] = await db.insert(subscriptions).values(insertSubscription).returning();
    return subscription;
  }
  async updateSubscription(tenantId, updates) {
    const [subscription] = await db.update(subscriptions).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(eq2(subscriptions.tenantId, tenantId)).returning();
    return subscription || void 0;
  }
  async getAllSubscriptions() {
    return await db.select().from(subscriptions).orderBy(desc2(subscriptions.createdAt));
  }
  // Report management
  async getReport(id, tenantId) {
    const [report] = await db.select().from(reports).where(
      and2(eq2(reports.id, id), eq2(reports.tenantId, tenantId))
    );
    return report || void 0;
  }
  async createReport(insertReport) {
    const [report] = await db.insert(reports).values(insertReport).returning();
    return report;
  }
  async updateReport(id, updates, tenantId) {
    const [report] = await db.update(reports).set(updates).where(and2(eq2(reports.id, id), eq2(reports.tenantId, tenantId))).returning();
    return report || void 0;
  }
  async getReportsByTenant(tenantId) {
    return await db.select().from(reports).where(eq2(reports.tenantId, tenantId)).orderBy(desc2(reports.createdAt));
  }
  async getAllReports() {
    return await db.select().from(reports).orderBy(desc2(reports.createdAt));
  }
  // Platform metrics for super admin
  async getPlatformMetrics() {
    const [tenantsResult] = await db.select({
      total: sql2`count(*)::int`,
      active: sql2`count(case when ${tenants.isActive} then 1 end)::int`
    }).from(tenants);
    const [usersResult] = await db.select({ count: sql2`count(*)::int` }).from(users);
    const [patientsResult] = await db.select({ count: sql2`count(*)::int` }).from(patients);
    const [subscriptionsResult] = await db.select({
      totalRevenue: sql2`COALESCE(SUM(${subscriptions.monthlyPrice}), 0)::numeric`
    }).from(subscriptions).where(eq2(subscriptions.status, "active"));
    const firstDayOfMonth = /* @__PURE__ */ new Date();
    firstDayOfMonth.setDate(1);
    firstDayOfMonth.setHours(0, 0, 0, 0);
    const [monthlyRevenueResult] = await db.select({
      monthlyRevenue: sql2`COALESCE(SUM(${subscriptions.monthlyPrice}), 0)::numeric`
    }).from(subscriptions).where(
      and2(
        eq2(subscriptions.status, "active"),
        sql2`${subscriptions.lastPaymentDate} >= ${firstDayOfMonth}`
      )
    );
    return {
      totalTenants: Number(tenantsResult.total),
      activeTenants: Number(tenantsResult.active),
      totalSubscriptionRevenue: Number(subscriptionsResult.totalRevenue),
      monthlyRevenue: Number(monthlyRevenueResult.monthlyRevenue),
      totalUsers: Number(usersResult.count),
      totalPatients: Number(patientsResult.count)
    };
  }
  // Multilingual Communication management
  async getMedicalCommunication(id, tenantId) {
    const [communication] = await db.select().from(medicalCommunications).where(
      and2(eq2(medicalCommunications.id, id), eq2(medicalCommunications.tenantId, tenantId))
    );
    return communication || void 0;
  }
  async createMedicalCommunication(insertCommunication) {
    const [communication] = await db.insert(medicalCommunications).values(insertCommunication).returning();
    return communication;
  }
  async updateMedicalCommunication(id, updates, tenantId) {
    const [communication] = await db.update(medicalCommunications).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(eq2(medicalCommunications.id, id), eq2(medicalCommunications.tenantId, tenantId))).returning();
    return communication || void 0;
  }
  async getMedicalCommunicationsByPatient(patientId, tenantId) {
    return await db.select({
      id: medicalCommunications.id,
      tenantId: medicalCommunications.tenantId,
      patientId: medicalCommunications.patientId,
      senderId: medicalCommunications.senderId,
      recipientId: medicalCommunications.recipientId,
      type: medicalCommunications.type,
      priority: medicalCommunications.priority,
      originalLanguage: medicalCommunications.originalLanguage,
      targetLanguages: medicalCommunications.targetLanguages,
      originalContent: medicalCommunications.originalContent,
      metadata: medicalCommunications.metadata,
      appointmentId: medicalCommunications.appointmentId,
      prescriptionId: medicalCommunications.prescriptionId,
      labOrderId: medicalCommunications.labOrderId,
      isRead: medicalCommunications.isRead,
      readAt: medicalCommunications.readAt,
      createdAt: medicalCommunications.createdAt,
      updatedAt: medicalCommunications.updatedAt,
      senderRole: users.role,
      senderFirstName: users.firstName,
      senderLastName: users.lastName
    }).from(medicalCommunications).leftJoin(users, eq2(medicalCommunications.senderId, users.id)).where(
      and2(eq2(medicalCommunications.patientId, patientId), eq2(medicalCommunications.tenantId, tenantId))
    ).orderBy(desc2(medicalCommunications.createdAt));
  }
  async getMedicalCommunicationsByTenant(tenantId) {
    return await db.select().from(medicalCommunications).where(
      eq2(medicalCommunications.tenantId, tenantId)
    ).orderBy(desc2(medicalCommunications.createdAt));
  }
  async getMedicalCommunicationsByTenantWithSenderInfo(tenantId) {
    return await db.select({
      id: medicalCommunications.id,
      tenantId: medicalCommunications.tenantId,
      patientId: medicalCommunications.patientId,
      senderId: medicalCommunications.senderId,
      recipientId: medicalCommunications.recipientId,
      type: medicalCommunications.type,
      priority: medicalCommunications.priority,
      originalLanguage: medicalCommunications.originalLanguage,
      targetLanguages: medicalCommunications.targetLanguages,
      originalContent: medicalCommunications.originalContent,
      metadata: medicalCommunications.metadata,
      appointmentId: medicalCommunications.appointmentId,
      prescriptionId: medicalCommunications.prescriptionId,
      labOrderId: medicalCommunications.labOrderId,
      isRead: medicalCommunications.isRead,
      readAt: medicalCommunications.readAt,
      createdAt: medicalCommunications.createdAt,
      updatedAt: medicalCommunications.updatedAt,
      senderRole: users.role,
      senderFirstName: users.firstName,
      senderLastName: users.lastName
    }).from(medicalCommunications).leftJoin(users, eq2(medicalCommunications.senderId, users.id)).where(eq2(medicalCommunications.tenantId, tenantId)).orderBy(desc2(medicalCommunications.createdAt));
  }
  // Communication Translation management
  async createCommunicationTranslation(insertTranslation) {
    const [translation] = await db.insert(communicationTranslations).values(insertTranslation).returning();
    return translation;
  }
  async getCommunicationTranslations(communicationId) {
    return await db.select().from(communicationTranslations).where(
      eq2(communicationTranslations.communicationId, communicationId)
    );
  }
  // Supported Languages management
  async getSupportedLanguages(tenantId) {
    return await db.select().from(supportedLanguages).where(
      and2(eq2(supportedLanguages.tenantId, tenantId), eq2(supportedLanguages.isActive, true))
    ).orderBy(supportedLanguages.languageName);
  }
  async createSupportedLanguage(insertLanguage) {
    const [language] = await db.insert(supportedLanguages).values(insertLanguage).returning();
    return language;
  }
  async updateSupportedLanguage(id, updates, tenantId) {
    const [language] = await db.update(supportedLanguages).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(eq2(supportedLanguages.id, id), eq2(supportedLanguages.tenantId, tenantId))).returning();
    return language || void 0;
  }
  // Medical Phrases management
  async getMedicalPhrases(tenantId, category) {
    const conditions = [eq2(medicalPhrases.tenantId, tenantId), eq2(medicalPhrases.isActive, true)];
    if (category) {
      conditions.push(eq2(medicalPhrases.category, category));
    }
    return await db.select().from(medicalPhrases).where(and2(...conditions)).orderBy(medicalPhrases.category, medicalPhrases.phraseKey);
  }
  async createMedicalPhrase(insertPhrase) {
    const [phrase] = await db.insert(medicalPhrases).values(insertPhrase).returning();
    return phrase;
  }
  // Phrase Translation management
  async getPhraseTranslations(phraseId) {
    return await db.select().from(phraseTranslations).where(
      eq2(phraseTranslations.phraseId, phraseId)
    ).orderBy(phraseTranslations.languageCode);
  }
  async createPhraseTranslation(insertTranslation) {
    const [translation] = await db.insert(phraseTranslations).values(insertTranslation).returning();
    return translation;
  }
  // Laboratory Management
  async getLaboratory(id, tenantId) {
    const [laboratory] = await db.select().from(laboratories).where(
      and2(eq2(laboratories.id, id), eq2(laboratories.tenantId, tenantId))
    );
    return laboratory || void 0;
  }
  async createLaboratory(insertLaboratory) {
    const [laboratory] = await db.insert(laboratories).values(insertLaboratory).returning();
    return laboratory;
  }
  async updateLaboratory(id, updates, tenantId) {
    const [laboratory] = await db.update(laboratories).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(eq2(laboratories.id, id), eq2(laboratories.tenantId, tenantId))).returning();
    return laboratory || void 0;
  }
  async getLaboratoriesByTenant(tenantId) {
    return await db.select().from(laboratories).where(
      eq2(laboratories.tenantId, tenantId)
    ).orderBy(laboratories.name);
  }
  async getActiveLaboratoriesByTenant(tenantId) {
    return await db.select().from(laboratories).where(
      and2(eq2(laboratories.tenantId, tenantId), eq2(laboratories.isActive, true))
    ).orderBy(laboratories.name);
  }
  async getActiveLaboratoryTenants() {
    return await db.select({
      id: tenants.id,
      name: tenants.name,
      type: tenants.type,
      subdomain: tenants.subdomain,
      isActive: tenants.isActive,
      organizationType: tenants.organizationType
    }).from(tenants).where(
      and2(eq2(tenants.type, "laboratory"), eq2(tenants.isActive, true))
    ).orderBy(tenants.name);
  }
  // Lab Results Management
  async getLabResult(id, tenantId) {
    const [labResult] = await db.select().from(labResults).where(
      and2(eq2(labResults.id, id), eq2(labResults.tenantId, tenantId))
    );
    return labResult || void 0;
  }
  async createLabResult(insertLabResult) {
    const [labResult] = await db.insert(labResults).values(insertLabResult).returning();
    await this.notifyHospitalOfResults(labResult);
    return labResult;
  }
  async updateLabResult(id, updates, tenantId) {
    const [labResult] = await db.update(labResults).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(eq2(labResults.id, id), eq2(labResults.tenantId, tenantId))).returning();
    return labResult || void 0;
  }
  async getLabResultsByOrder(labOrderId, tenantId) {
    return await db.select().from(labResults).where(
      and2(eq2(labResults.labOrderId, labOrderId), eq2(labResults.tenantId, tenantId))
    ).orderBy(labResults.testName);
  }
  async getLabResultsByPatient(patientId, tenantId) {
    return await db.select().from(labResults).where(
      and2(eq2(labResults.patientId, patientId), eq2(labResults.tenantId, tenantId))
    ).orderBy(desc2(labResults.createdAt));
  }
  // SECURITY: Controlled cross-tenant lab results access with explicit authorization
  async getLabResultsForPatientAcrossTenants(patientId, accessContext) {
    console.log(`[SECURITY AUDIT] Cross-tenant lab results access: ${accessContext.type} by user ${accessContext.userId} from tenant ${accessContext.tenantId} for patient ${patientId}`);
    const patient = await db.select().from(patients).where(eq2(patients.id, patientId)).limit(1);
    if (!patient.length) {
      throw new Error("Patient not found");
    }
    if (accessContext.type === "doctor_view") {
    } else if (accessContext.type === "patient_portal") {
    }
    const results = await db.select({
      id: labResults.id,
      labOrderId: labResults.labOrderId,
      testName: labResults.testName,
      result: labResults.result,
      normalRange: labResults.normalRange,
      unit: labResults.unit,
      status: labResults.status,
      abnormalFlag: labResults.abnormalFlag,
      notes: labResults.notes,
      performedBy: labResults.performedBy,
      completedAt: labResults.completedAt,
      reportedAt: labResults.reportedAt,
      createdAt: labResults.createdAt,
      laboratoryTenantId: labResults.tenantId
    }).from(labResults).where(eq2(labResults.patientId, patientId)).orderBy(desc2(labResults.completedAt));
    const enrichedResults = await Promise.all(results.map(async (result) => {
      const lab = await db.select().from(tenants).where(eq2(tenants.id, result.laboratoryTenantId)).limit(1);
      return {
        ...result,
        laboratoryName: lab[0]?.name || "Unknown Laboratory"
      };
    }));
    return enrichedResults;
  }
  // Method to automatically notify hospitals when results are posted
  async notifyHospitalOfResults(labResult) {
    const labOrder = await db.select().from(labOrders).where(eq2(labOrders.id, labResult.labOrderId)).limit(1);
    if (labOrder.length > 0) {
      await db.update(labOrders).set({
        status: "completed",
        results: { completed: true, resultId: labResult.id },
        updatedAt: sql2`CURRENT_TIMESTAMP`
      }).where(eq2(labOrders.id, labResult.labOrderId));
    }
  }
  async getLabResultsByTenant(tenantId) {
    return await db.select().from(labResults).where(
      eq2(labResults.tenantId, tenantId)
    ).orderBy(desc2(labResults.createdAt));
  }
  async getPendingLabResults(tenantId) {
    return await db.select().from(labResults).where(
      and2(eq2(labResults.tenantId, tenantId), eq2(labResults.status, "pending"))
    ).orderBy(labResults.createdAt);
  }
  // Lab Order Assignment Management
  async getLabOrderAssignment(id, tenantId) {
    const [assignment] = await db.select().from(labOrderAssignments).where(
      and2(eq2(labOrderAssignments.id, id), eq2(labOrderAssignments.tenantId, tenantId))
    );
    return assignment || void 0;
  }
  async createLabOrderAssignment(insertAssignment) {
    const [assignment] = await db.insert(labOrderAssignments).values(insertAssignment).returning();
    return assignment;
  }
  async updateLabOrderAssignment(id, updates, tenantId) {
    const [assignment] = await db.update(labOrderAssignments).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(eq2(labOrderAssignments.id, id), eq2(labOrderAssignments.tenantId, tenantId))).returning();
    return assignment || void 0;
  }
  async getLabOrderAssignmentByOrder(labOrderId, tenantId) {
    const [assignment] = await db.select().from(labOrderAssignments).where(
      and2(eq2(labOrderAssignments.labOrderId, labOrderId), eq2(labOrderAssignments.tenantId, tenantId))
    );
    return assignment || void 0;
  }
  async getLabOrderAssignmentsByLaboratory(laboratoryId, tenantId) {
    return await db.select().from(labOrderAssignments).where(
      and2(eq2(labOrderAssignments.laboratoryId, laboratoryId), eq2(labOrderAssignments.tenantId, tenantId))
    ).orderBy(desc2(labOrderAssignments.createdAt));
  }
  async getLabOrderAssignmentsByTenant(tenantId) {
    return await db.select().from(labOrderAssignments).where(
      eq2(labOrderAssignments.tenantId, tenantId)
    ).orderBy(desc2(labOrderAssignments.createdAt));
  }
  async getLabOrderAssignmentsByOrder(labOrderId) {
    return await db.select().from(labOrderAssignments).where(
      eq2(labOrderAssignments.labOrderId, labOrderId)
    ).orderBy(desc2(labOrderAssignments.createdAt));
  }
  // Laboratory Application Management
  async getLaboratoryApplication(id) {
    const [application] = await db.select().from(laboratoryApplications).where(
      eq2(laboratoryApplications.id, id)
    );
    return application || void 0;
  }
  async createLaboratoryApplication(insertApplication) {
    const [application] = await db.insert(laboratoryApplications).values(insertApplication).returning();
    return application;
  }
  async updateLaboratoryApplication(id, updates) {
    const [application] = await db.update(laboratoryApplications).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(eq2(laboratoryApplications.id, id)).returning();
    return application || void 0;
  }
  async getAllLaboratoryApplications() {
    return await db.select().from(laboratoryApplications).orderBy(desc2(laboratoryApplications.createdAt));
  }
  async getLaboratoryApplicationsByStatus(status) {
    return await db.select().from(laboratoryApplications).where(
      eq2(laboratoryApplications.status, status)
    ).orderBy(desc2(laboratoryApplications.createdAt));
  }
  async approveLaboratoryApplication(id, reviewedBy, reviewNotes) {
    const application = await this.getLaboratoryApplication(id);
    if (!application) return void 0;
    const labTenant = await this.createTenant({
      name: application.laboratoryName,
      subdomain: application.laboratoryName.toLowerCase().replace(/[^a-z0-9]/g, ""),
      type: "laboratory",
      isActive: true
    });
    const laboratory = await this.createLaboratory({
      tenantId: labTenant.id,
      name: application.laboratoryName,
      licenseNumber: application.licenseNumber,
      contactPerson: application.contactPerson,
      phone: application.contactPhone,
      email: application.contactEmail,
      address: application.address,
      specializations: application.specializations,
      isActive: true,
      isExternal: true,
      registrationStatus: "approved",
      registrationNotes: reviewNotes,
      approvedBy: reviewedBy,
      websiteUrl: application.websiteUrl,
      accreditations: application.accreditations,
      operatingHours: application.operatingHours,
      servicesOffered: application.servicesOffered,
      equipmentDetails: application.equipmentDetails,
      certificationDocuments: application.certificationDocuments,
      averageTurnaroundTime: application.averageTurnaroundTime
    });
    const updatedApplication = await this.updateLaboratoryApplication(id, {
      status: "approved",
      reviewNotes,
      reviewedBy
    });
    return updatedApplication ? { laboratory, application: updatedApplication } : void 0;
  }
  async rejectLaboratoryApplication(id, reviewedBy, reviewNotes) {
    return await this.updateLaboratoryApplication(id, {
      status: "rejected",
      reviewNotes,
      reviewedBy
    });
  }
  // Vital Signs Management Implementation
  async getVitalSigns(id, tenantId) {
    const [vitalSign] = await db.select().from(vitalSigns).where(
      and2(eq2(vitalSigns.id, id), eq2(vitalSigns.tenantId, tenantId))
    );
    return vitalSign || void 0;
  }
  async createVitalSigns(insertVitalSigns) {
    const vitalSignsWithBMI = { ...insertVitalSigns };
    if (insertVitalSigns.weight && insertVitalSigns.height) {
      const weightKg = parseFloat(insertVitalSigns.weight.toString()) * 0.453592;
      const heightM = parseFloat(insertVitalSigns.height.toString()) * 0.0254;
      const bmi = weightKg / (heightM * heightM);
      vitalSignsWithBMI.bodyMassIndex = bmi.toFixed(1);
    }
    const [vitalSign] = await db.insert(vitalSigns).values(vitalSignsWithBMI).returning();
    return vitalSign;
  }
  async updateVitalSigns(id, updates, tenantId) {
    const updatedData = { ...updates };
    if (updates.weight || updates.height) {
      const current = await this.getVitalSigns(id, tenantId);
      if (current) {
        const weight = updates.weight || current.weight;
        const height = updates.height || current.height;
        if (weight && height) {
          const weightKg = parseFloat(weight.toString()) * 0.453592;
          const heightM = parseFloat(height.toString()) * 0.0254;
          const bmi = weightKg / (heightM * heightM);
          updatedData.bodyMassIndex = bmi.toFixed(1);
        }
      }
    }
    const [vitalSign] = await db.update(vitalSigns).set(updatedData).where(and2(eq2(vitalSigns.id, id), eq2(vitalSigns.tenantId, tenantId))).returning();
    return vitalSign || void 0;
  }
  async getVitalSignsByPatient(patientId, tenantId) {
    return await db.select().from(vitalSigns).where(
      and2(eq2(vitalSigns.patientId, patientId), eq2(vitalSigns.tenantId, tenantId))
    ).orderBy(desc2(vitalSigns.recordedAt));
  }
  async getVitalSignsByAppointment(appointmentId, tenantId) {
    const [vitalSign] = await db.select().from(vitalSigns).where(
      and2(eq2(vitalSigns.appointmentId, appointmentId), eq2(vitalSigns.tenantId, tenantId))
    );
    return vitalSign || void 0;
  }
  async getVitalSignsByTenant(tenantId) {
    return await db.select().from(vitalSigns).where(eq2(vitalSigns.tenantId, tenantId)).orderBy(desc2(vitalSigns.recordedAt));
  }
  // Visit Summary Management Implementation
  async getVisitSummary(id, tenantId) {
    const [visitSummary] = await db.select().from(visitSummaries).where(
      and2(eq2(visitSummaries.id, id), eq2(visitSummaries.tenantId, tenantId))
    );
    return visitSummary || void 0;
  }
  async createVisitSummary(insertVisitSummary) {
    const [visitSummary] = await db.insert(visitSummaries).values(insertVisitSummary).returning();
    return visitSummary;
  }
  async updateVisitSummary(id, updates, tenantId) {
    const [visitSummary] = await db.update(visitSummaries).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(eq2(visitSummaries.id, id), eq2(visitSummaries.tenantId, tenantId))).returning();
    return visitSummary || void 0;
  }
  async getVisitSummariesByPatient(patientId, tenantId) {
    return await db.select().from(visitSummaries).where(
      and2(eq2(visitSummaries.patientId, patientId), eq2(visitSummaries.tenantId, tenantId))
    ).orderBy(desc2(visitSummaries.visitDate));
  }
  async getVisitSummaryByAppointment(appointmentId, tenantId) {
    const [visitSummary] = await db.select().from(visitSummaries).where(
      and2(eq2(visitSummaries.appointmentId, appointmentId), eq2(visitSummaries.tenantId, tenantId))
    );
    return visitSummary || void 0;
  }
  async getVisitSummariesByProvider(providerId, tenantId) {
    return await db.select().from(visitSummaries).where(
      and2(eq2(visitSummaries.providerId, providerId), eq2(visitSummaries.tenantId, tenantId))
    ).orderBy(desc2(visitSummaries.visitDate));
  }
  async getVisitSummariesByTenant(tenantId) {
    return await db.select().from(visitSummaries).where(eq2(visitSummaries.tenantId, tenantId)).orderBy(desc2(visitSummaries.visitDate));
  }
  // AI Health Recommendations Management Implementation
  async getHealthRecommendation(id, tenantId) {
    const [recommendation] = await db.select().from(healthRecommendations).where(
      and2(eq2(healthRecommendations.id, id), eq2(healthRecommendations.tenantId, tenantId))
    );
    return recommendation || void 0;
  }
  async createHealthRecommendation(insertRecommendation) {
    const [recommendation] = await db.insert(healthRecommendations).values(insertRecommendation).returning();
    return recommendation;
  }
  async updateHealthRecommendation(id, updates, tenantId) {
    const [recommendation] = await db.update(healthRecommendations).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(eq2(healthRecommendations.id, id), eq2(healthRecommendations.tenantId, tenantId))).returning();
    return recommendation || void 0;
  }
  async getHealthRecommendationsByPatient(patientId, tenantId) {
    return await db.select().from(healthRecommendations).where(
      and2(eq2(healthRecommendations.patientId, patientId), eq2(healthRecommendations.tenantId, tenantId))
    ).orderBy(desc2(healthRecommendations.createdAt));
  }
  async getActiveHealthRecommendationsByPatient(patientId, tenantId) {
    return await db.select().from(healthRecommendations).where(
      and2(
        eq2(healthRecommendations.patientId, patientId),
        eq2(healthRecommendations.tenantId, tenantId),
        eq2(healthRecommendations.status, "active")
      )
    ).orderBy(desc2(healthRecommendations.createdAt));
  }
  async getHealthRecommendationsByTenant(tenantId) {
    return await db.select().from(healthRecommendations).where(eq2(healthRecommendations.tenantId, tenantId)).orderBy(desc2(healthRecommendations.createdAt));
  }
  async acknowledgeHealthRecommendation(id, acknowledgedBy, tenantId) {
    const [recommendation] = await db.update(healthRecommendations).set({
      acknowledgedAt: sql2`CURRENT_TIMESTAMP`,
      acknowledgedBy,
      updatedAt: sql2`CURRENT_TIMESTAMP`
    }).where(and2(eq2(healthRecommendations.id, id), eq2(healthRecommendations.tenantId, tenantId))).returning();
    return recommendation || void 0;
  }
  // AI Health Analysis Management Implementation
  async getHealthAnalysis(id, tenantId) {
    const [analysis] = await db.select().from(healthAnalyses).where(
      and2(eq2(healthAnalyses.id, id), eq2(healthAnalyses.tenantId, tenantId))
    );
    return analysis || void 0;
  }
  async createHealthAnalysis(insertAnalysis) {
    const [analysis] = await db.insert(healthAnalyses).values(insertAnalysis).returning();
    return analysis;
  }
  async updateHealthAnalysis(id, updates, tenantId) {
    const [analysis] = await db.update(healthAnalyses).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(eq2(healthAnalyses.id, id), eq2(healthAnalyses.tenantId, tenantId))).returning();
    return analysis || void 0;
  }
  async getHealthAnalysesByPatient(patientId, tenantId) {
    return await db.select().from(healthAnalyses).where(
      and2(eq2(healthAnalyses.patientId, patientId), eq2(healthAnalyses.tenantId, tenantId))
    ).orderBy(desc2(healthAnalyses.createdAt));
  }
  async getLatestHealthAnalysis(patientId, tenantId) {
    const [analysis] = await db.select().from(healthAnalyses).where(
      and2(eq2(healthAnalyses.patientId, patientId), eq2(healthAnalyses.tenantId, tenantId))
    ).orderBy(desc2(healthAnalyses.createdAt)).limit(1);
    return analysis || void 0;
  }
  async getHealthAnalysesByTenant(tenantId) {
    return await db.select().from(healthAnalyses).where(eq2(healthAnalyses.tenantId, tenantId)).orderBy(desc2(healthAnalyses.createdAt));
  }
  // Medication Copay Management Implementation
  async getMedicationCopay(id, tenantId) {
    const [copay] = await db.select().from(medicationCopays).where(
      and2(eq2(medicationCopays.id, id), eq2(medicationCopays.tenantId, tenantId))
    );
    return copay || void 0;
  }
  async createMedicationCopay(insertCopay) {
    const [copay] = await db.insert(medicationCopays).values(insertCopay).returning();
    return copay;
  }
  async updateMedicationCopay(id, updates, tenantId) {
    const [copay] = await db.update(medicationCopays).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(eq2(medicationCopays.id, id), eq2(medicationCopays.tenantId, tenantId))).returning();
    return copay || void 0;
  }
  async getMedicationCopaysByPatient(patientId, tenantId) {
    return await db.select().from(medicationCopays).where(
      and2(eq2(medicationCopays.patientId, patientId), eq2(medicationCopays.tenantId, tenantId))
    ).orderBy(desc2(medicationCopays.createdAt));
  }
  async getMedicationCopaysByPatientInsurance(patientInsuranceId, tenantId) {
    return await db.select().from(medicationCopays).where(
      and2(eq2(medicationCopays.patientInsuranceId, patientInsuranceId), eq2(medicationCopays.tenantId, tenantId))
    ).orderBy(desc2(medicationCopays.createdAt));
  }
  async getMedicationCopaysByPrescription(prescriptionId, tenantId) {
    return await db.select().from(medicationCopays).where(
      and2(eq2(medicationCopays.prescriptionId, prescriptionId), eq2(medicationCopays.tenantId, tenantId))
    ).orderBy(desc2(medicationCopays.createdAt));
  }
  async getMedicationCopaysByPharmacist(pharmacistId, tenantId) {
    return await db.select().from(medicationCopays).where(
      and2(eq2(medicationCopays.definedByPharmacist, pharmacistId), eq2(medicationCopays.tenantId, tenantId))
    ).orderBy(desc2(medicationCopays.createdAt));
  }
  async getMedicationCopaysByTenant(tenantId) {
    return await db.select().from(medicationCopays).where(eq2(medicationCopays.tenantId, tenantId)).orderBy(desc2(medicationCopays.createdAt));
  }
  async getActiveMedicationCopaysByPatient(patientId, tenantId) {
    return await db.select().from(medicationCopays).where(
      and2(
        eq2(medicationCopays.patientId, patientId),
        eq2(medicationCopays.tenantId, tenantId),
        eq2(medicationCopays.isActive, true)
      )
    ).orderBy(desc2(medicationCopays.createdAt));
  }
  // Pricing Plans Implementation
  async getPricingPlans() {
    return [
      {
        id: "basic",
        name: "Basic",
        price: 99,
        interval: "month",
        features: ["Up to 100 patients", "Basic reporting", "Email support"]
      },
      {
        id: "professional",
        name: "Professional",
        price: 299,
        interval: "month",
        features: ["Up to 1000 patients", "Advanced reporting", "Phone support", "API access"]
      },
      {
        id: "enterprise",
        name: "Enterprise",
        price: 999,
        interval: "month",
        features: ["Unlimited patients", "Custom reporting", "Dedicated support", "White label", "Multi-language"]
      },
      {
        id: "white_label",
        name: "White Label",
        price: 1999,
        interval: "month",
        features: ["Everything in Enterprise", "Full white labeling", "Custom branding", "Offline sync"]
      }
    ];
  }
  async createPricingPlan(data) {
    return { id: "new-plan", ...data };
  }
  async updatePricingPlan(id, data) {
    return { id, ...data };
  }
  // White Label Settings Implementation
  async updateTenantWhiteLabel(tenantId, settings) {
    try {
      const [tenant] = await db.update(tenants).set({
        brandName: settings.brandName,
        updatedAt: sql2`CURRENT_TIMESTAMP`
      }).where(eq2(tenants.id, tenantId)).returning();
      return tenant || null;
    } catch (error) {
      console.error("Error updating white label settings:", error);
      return null;
    }
  }
  // Offline Sync Implementation
  async syncOfflineData(syncData) {
    console.log("Syncing offline data:", syncData);
    return { success: true, syncedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  async getOfflineData(tenantId) {
    return {
      patients: await this.getPatientsByTenant(tenantId, 50),
      appointments: await this.getAppointmentsByTenant(tenantId),
      prescriptions: await this.getPrescriptionsByTenant(tenantId),
      lastSync: (/* @__PURE__ */ new Date()).toISOString()
    };
  }
  // Translations Implementation
  async getTranslations(tenantId, language) {
    const commonTranslations = {
      "en": {
        "welcome": "Welcome",
        "patient": "Patient",
        "doctor": "Doctor",
        "appointment": "Appointment",
        "prescription": "Prescription"
      },
      "es": {
        "welcome": "Bienvenido",
        "patient": "Paciente",
        "doctor": "Doctor",
        "appointment": "Cita",
        "prescription": "Receta"
      },
      "fr": {
        "welcome": "Bienvenue",
        "patient": "Patient",
        "doctor": "Docteur",
        "appointment": "Rendez-vous",
        "prescription": "Prescription"
      }
    };
    return Object.entries(commonTranslations[language] || commonTranslations.en).map(([key, value]) => ({
      key,
      value,
      language,
      tenantId
    }));
  }
  async createTranslation(data) {
    return { id: "new-translation", ...data, createdAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  // Patient Check-ins for receptionist workflow
  async getPatientCheckIn(id, tenantId) {
    const [checkIn] = await db.select().from(patientCheckIns).where(
      and2(eq2(patientCheckIns.id, id), eq2(patientCheckIns.tenantId, tenantId))
    );
    return checkIn || void 0;
  }
  async createPatientCheckIn(checkIn) {
    const [newCheckIn] = await db.insert(patientCheckIns).values(checkIn).returning();
    return newCheckIn;
  }
  async updatePatientCheckIn(id, updates, tenantId) {
    const [updatedCheckIn] = await db.update(patientCheckIns).set({ ...updates, updatedAt: /* @__PURE__ */ new Date() }).where(and2(eq2(patientCheckIns.id, id), eq2(patientCheckIns.tenantId, tenantId))).returning();
    return updatedCheckIn || void 0;
  }
  async getPatientCheckInsByTenant(tenantId, date) {
    let query = db.select().from(patientCheckIns).where(eq2(patientCheckIns.tenantId, tenantId));
    if (date) {
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);
      query = query.where(
        and2(
          eq2(patientCheckIns.tenantId, tenantId),
          sql2`${patientCheckIns.checkedInAt} >= ${startOfDay}`,
          sql2`${patientCheckIns.checkedInAt} <= ${endOfDay}`
        )
      );
    }
    return await query.orderBy(desc2(patientCheckIns.checkedInAt));
  }
  async getWaitingPatients(tenantId) {
    const result = await db.select({
      id: patientCheckIns.id,
      patientId: patientCheckIns.patientId,
      appointmentId: patientCheckIns.appointmentId,
      checkedInBy: patientCheckIns.checkedInBy,
      checkedInAt: patientCheckIns.checkedInAt,
      reasonForVisit: patientCheckIns.reasonForVisit,
      chiefComplaint: patientCheckIns.chiefComplaint,
      priorityLevel: patientCheckIns.priorityLevel,
      specialInstructions: patientCheckIns.specialInstructions,
      insuranceVerified: patientCheckIns.insuranceVerified,
      status: patientCheckIns.status,
      vitalSignsId: patientCheckIns.vitalSignsId,
      patient: {
        id: patients.id,
        firstName: patients.firstName,
        lastName: patients.lastName,
        mrn: patients.mrn,
        dateOfBirth: patients.dateOfBirth,
        phone: patients.phone,
        email: patients.email
      }
    }).from(patientCheckIns).innerJoin(patients, eq2(patientCheckIns.patientId, patients.id)).where(
      and2(
        eq2(patientCheckIns.tenantId, tenantId),
        eq2(patientCheckIns.status, "waiting")
      )
    ).orderBy(patientCheckIns.checkedInAt);
    return result;
  }
  async getPatientCheckInsByDate(date, tenantId) {
    const targetDate = new Date(date);
    const startOfDay = new Date(targetDate);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(targetDate);
    endOfDay.setHours(23, 59, 59, 999);
    const result = await db.select({
      id: patientCheckIns.id,
      patientId: patientCheckIns.patientId,
      appointmentId: patientCheckIns.appointmentId,
      checkedInBy: patientCheckIns.checkedInBy,
      checkedInAt: patientCheckIns.checkedInAt,
      reasonForVisit: patientCheckIns.reasonForVisit,
      chiefComplaint: patientCheckIns.chiefComplaint,
      priorityLevel: patientCheckIns.priorityLevel,
      specialInstructions: patientCheckIns.specialInstructions,
      insuranceVerified: patientCheckIns.insuranceVerified,
      status: patientCheckIns.status,
      vitalSignsId: patientCheckIns.vitalSignsId,
      patient: {
        id: patients.id,
        firstName: patients.firstName,
        lastName: patients.lastName,
        mrn: patients.mrn,
        dateOfBirth: patients.dateOfBirth,
        phone: patients.phone,
        email: patients.email
      },
      vitalSigns: {
        id: vitalSigns.id,
        systolicBp: vitalSigns.systolicBp,
        diastolicBp: vitalSigns.diastolicBp,
        heartRate: vitalSigns.heartRate,
        temperature: vitalSigns.temperature,
        temperatureUnit: vitalSigns.temperatureUnit
      }
    }).from(patientCheckIns).innerJoin(patients, eq2(patientCheckIns.patientId, patients.id)).leftJoin(vitalSigns, eq2(patientCheckIns.vitalSignsId, vitalSigns.id)).where(
      and2(
        eq2(patientCheckIns.tenantId, tenantId),
        sql2`${patientCheckIns.checkedInAt} >= ${startOfDay}`,
        sql2`${patientCheckIns.checkedInAt} <= ${endOfDay}`
      )
    ).orderBy(desc2(patientCheckIns.checkedInAt));
    return result;
  }
  async getTodaysCheckIns(tenantId) {
    const today = /* @__PURE__ */ new Date();
    const startOfDay = new Date(today);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(today);
    endOfDay.setHours(23, 59, 59, 999);
    const result = await db.select({
      id: patientCheckIns.id,
      patientId: patientCheckIns.patientId,
      appointmentId: patientCheckIns.appointmentId,
      checkedInBy: patientCheckIns.checkedInBy,
      checkedInAt: patientCheckIns.checkedInAt,
      reasonForVisit: patientCheckIns.reasonForVisit,
      chiefComplaint: patientCheckIns.chiefComplaint,
      priorityLevel: patientCheckIns.priorityLevel,
      specialInstructions: patientCheckIns.specialInstructions,
      insuranceVerified: patientCheckIns.insuranceVerified,
      status: patientCheckIns.status,
      vitalSignsId: patientCheckIns.vitalSignsId,
      patient: {
        id: patients.id,
        firstName: patients.firstName,
        lastName: patients.lastName,
        mrn: patients.mrn,
        dateOfBirth: patients.dateOfBirth,
        phone: patients.phone,
        email: patients.email
      },
      vitalSigns: {
        id: vitalSigns.id,
        systolicBp: vitalSigns.systolicBp,
        diastolicBp: vitalSigns.diastolicBp,
        heartRate: vitalSigns.heartRate,
        temperature: vitalSigns.temperature,
        temperatureUnit: vitalSigns.temperatureUnit
      }
    }).from(patientCheckIns).innerJoin(patients, eq2(patientCheckIns.patientId, patients.id)).leftJoin(vitalSigns, eq2(patientCheckIns.vitalSignsId, vitalSigns.id)).where(
      and2(
        eq2(patientCheckIns.tenantId, tenantId),
        sql2`${patientCheckIns.checkedInAt} >= ${startOfDay}`,
        sql2`${patientCheckIns.checkedInAt} <= ${endOfDay}`
      )
    ).orderBy(desc2(patientCheckIns.checkedInAt));
    return result;
  }
  // Role Permissions Management
  async getRolePermissions(tenantId) {
    return await db.select().from(rolePermissions).where(and2(eq2(rolePermissions.tenantId, tenantId), eq2(rolePermissions.isActive, true)));
  }
  async getRolePermissionsByRole(role, tenantId) {
    return await db.select().from(rolePermissions).where(and2(
      eq2(rolePermissions.tenantId, tenantId),
      eq2(rolePermissions.role, role),
      eq2(rolePermissions.isActive, true)
    ));
  }
  async createRolePermission(permission) {
    console.log("\u{1F527} [STORAGE] Creating role permission with data:", permission);
    if (!permission.createdBy) {
      throw new Error("createdBy field is required for creating role permissions");
    }
    const [created] = await db.insert(rolePermissions).values(permission).returning();
    console.log("\u{1F527} [STORAGE] Create result:", created);
    return created;
  }
  async updateRolePermission(id, updates, tenantId) {
    console.log("\u{1F527} [STORAGE] Updating role permission:", { id, updates, tenantId });
    const { createdBy, createdAt, ...updateData } = updates;
    const [updated] = await db.update(rolePermissions).set({
      ...updateData,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(and2(eq2(rolePermissions.id, id), eq2(rolePermissions.tenantId, tenantId))).returning();
    console.log("\u{1F527} [STORAGE] Update result:", updated);
    return updated || void 0;
  }
  async deleteRolePermission(id, tenantId) {
    const [deleted] = await db.update(rolePermissions).set({ isActive: false, updatedAt: /* @__PURE__ */ new Date() }).where(and2(eq2(rolePermissions.id, id), eq2(rolePermissions.tenantId, tenantId))).returning();
    return !!deleted;
  }
  async deleteRolePermissionsByRole(role, tenantId) {
    const result = await db.update(rolePermissions).set({ isActive: false, updatedAt: /* @__PURE__ */ new Date() }).where(and2(eq2(rolePermissions.role, role), eq2(rolePermissions.tenantId, tenantId))).returning();
    return result.length;
  }
  async getRolePermissionByRoleAndModule(role, module, tenantId) {
    const [permission] = await db.select().from(rolePermissions).where(and2(
      eq2(rolePermissions.tenantId, tenantId),
      eq2(rolePermissions.role, role),
      eq2(rolePermissions.module, module),
      eq2(rolePermissions.isActive, true)
    ));
    return permission || void 0;
  }
  // Patient Billing Management
  async createPatientBill(bill) {
    const [patientBill] = await db.insert(patientBills).values(bill).returning();
    return patientBill;
  }
  async getPatientBills(patientId, tenantId) {
    return await db.select().from(patientBills).where(and2(eq2(patientBills.patientId, patientId), eq2(patientBills.tenantId, tenantId))).orderBy(desc2(patientBills.serviceDate));
  }
  async getPatientBill(id, tenantId) {
    const [bill] = await db.select().from(patientBills).where(and2(eq2(patientBills.id, id), eq2(patientBills.tenantId, tenantId)));
    return bill || void 0;
  }
  async updatePatientBill(id, updates, tenantId) {
    const [bill] = await db.update(patientBills).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(eq2(patientBills.id, id), eq2(patientBills.tenantId, tenantId))).returning();
    return bill;
  }
  async createPatientPayment(payment) {
    const [patientPayment] = await db.insert(patientPayments).values(payment).returning();
    return patientPayment;
  }
  async getPatientPayments(patientBillId, tenantId) {
    return await db.select().from(patientPayments).where(and2(eq2(patientPayments.patientBillId, patientBillId), eq2(patientPayments.tenantId, tenantId))).orderBy(desc2(patientPayments.paymentDate));
  }
  // Lab Bills Management
  async getLabBillsByTenant(tenantId) {
    try {
      const bills = await db.select({
        id: labBills.id,
        tenantId: labBills.tenantId,
        patientId: labBills.patientId,
        amount: labBills.amount,
        description: labBills.description,
        status: labBills.status,
        serviceType: labBills.serviceType,
        labOrderId: labBills.labOrderId,
        testName: labBills.testName,
        notes: labBills.notes,
        generatedBy: labBills.generatedBy,
        createdAt: labBills.createdAt,
        updatedAt: labBills.updatedAt
      }).from(labBills).where(eq2(labBills.tenantId, tenantId)).orderBy(desc2(labBills.createdAt));
      const enrichedBills = [];
      for (const bill of bills) {
        try {
          const [patient] = await db.select({
            firstName: patients.firstName,
            lastName: patients.lastName,
            mrn: patients.mrn
          }).from(patients).where(eq2(patients.id, bill.patientId));
          enrichedBills.push({
            ...bill,
            patientFirstName: patient?.firstName || "Unknown",
            patientLastName: patient?.lastName || "Patient",
            patientMrn: patient?.mrn || "N/A"
          });
        } catch (error) {
          console.error(`Error fetching patient ${bill.patientId} for lab bill ${bill.id}:`, error);
          enrichedBills.push({
            ...bill,
            patientFirstName: "Unknown",
            patientLastName: "Patient",
            patientMrn: "N/A"
          });
        }
      }
      return enrichedBills;
    } catch (error) {
      console.error("Error fetching lab bills:", error);
      return [];
    }
  }
  async createLabBill(bill) {
    const [labBill] = await db.insert(labBills).values(bill).returning();
    return labBill;
  }
  async updateLabBill(id, updates, tenantId) {
    const [bill] = await db.update(labBills).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(eq2(labBills.id, id), eq2(labBills.tenantId, tenantId))).returning();
    return bill || void 0;
  }
  async getLabBill(id, tenantId) {
    const [bill] = await db.select().from(labBills).where(and2(eq2(labBills.id, id), eq2(labBills.tenantId, tenantId)));
    if (bill) {
      try {
        const [patient] = await db.select({
          firstName: patients.firstName,
          lastName: patients.lastName,
          mrn: patients.mrn
        }).from(patients).where(eq2(patients.id, bill.patientId));
        return {
          ...bill,
          patientFirstName: patient?.firstName || "Unknown",
          patientLastName: patient?.lastName || "Patient",
          patientMrn: patient?.mrn || "N/A"
        };
      } catch (error) {
        console.error(`Error fetching patient ${bill.patientId} for lab bill ${bill.id}:`, error);
        return {
          ...bill,
          patientFirstName: "Unknown",
          patientLastName: "Patient",
          patientMrn: "N/A"
        };
      }
    }
    return void 0;
  }
  // Patient Account Activation
  async generatePatientCredentials(patientId, tenantId) {
    const tempPassword = Math.random().toString(36).slice(-8);
    const activationToken = Math.random().toString(36) + Date.now().toString(36);
    await this.createAuditLog({
      tenantId,
      userId: patientId,
      action: "patient_account_generated",
      entityType: "patient",
      entityId: patientId,
      details: { activationToken },
      ipAddress: "system",
      userAgent: "automated-service"
    });
    return { tempPassword, activationToken };
  }
  async sendPatientActivationMessage(patient, tempPassword, activationToken) {
    try {
      console.log(`Patient activation credentials for ${patient.firstName} ${patient.lastName}:`);
      console.log(`Email: ${patient.email}`);
      console.log(`Phone: ${patient.phone}`);
      console.log(`Temporary Password: ${tempPassword}`);
      console.log(`Activation Link: ${process.env.FRONTEND_URL || "https://localhost:5000"}/patient/activate?token=${activationToken}`);
      return true;
    } catch (error) {
      console.error("Failed to send patient activation message:", error);
      return false;
    }
  }
  // Patient Assignment Management Implementation
  async getPatientAssignment(id, tenantId) {
    const [assignment] = await db.select().from(patientAssignments).where(
      and2(eq2(patientAssignments.id, id), eq2(patientAssignments.tenantId, tenantId))
    );
    return assignment || void 0;
  }
  async createPatientAssignment(assignment) {
    const [newAssignment] = await db.insert(patientAssignments).values(assignment).returning();
    return newAssignment;
  }
  async assignPatientToPhysician(data) {
    return await this.createPatientAssignment({
      id: randomUUID(),
      tenantId: data.tenantId,
      patientId: data.patientId,
      physicianId: data.physicianId,
      assignmentType: data.assignmentType || "primary_care",
      assignedBy: data.assignedBy,
      assignedDate: data.assignedDate || /* @__PURE__ */ new Date(),
      expiryDate: data.expiryDate || null,
      isActive: data.isActive !== void 0 ? data.isActive : true,
      notes: data.notes || null,
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    });
  }
  async updatePatientAssignment(id, updates, tenantId) {
    const [updated] = await db.update(patientAssignments).set(updates).where(and2(eq2(patientAssignments.id, id), eq2(patientAssignments.tenantId, tenantId))).returning();
    return updated || void 0;
  }
  async getPatientAssignmentsByPhysician(physicianId, tenantId) {
    return await db.select({
      id: patientAssignments.id,
      patientId: patientAssignments.patientId,
      assignmentType: patientAssignments.assignmentType,
      assignedDate: patientAssignments.assignedDate,
      expiryDate: patientAssignments.expiryDate,
      notes: patientAssignments.notes,
      // Patient information
      patientFirstName: patients.firstName,
      patientLastName: patients.lastName,
      patientMRN: patients.mrn,
      patientDateOfBirth: patients.dateOfBirth,
      patientPhone: patients.phone,
      patientEmail: patients.email
    }).from(patientAssignments).innerJoin(patients, eq2(patientAssignments.patientId, patients.id)).where(and2(
      eq2(patientAssignments.physicianId, physicianId),
      eq2(patientAssignments.tenantId, tenantId),
      eq2(patientAssignments.isActive, true)
    )).orderBy(desc2(patientAssignments.assignedDate));
  }
  async getPatientAssignmentsByPatient(patientId, tenantId) {
    return await db.select({
      id: patientAssignments.id,
      physicianId: patientAssignments.physicianId,
      assignmentType: patientAssignments.assignmentType,
      assignedDate: patientAssignments.assignedDate,
      expiryDate: patientAssignments.expiryDate,
      notes: patientAssignments.notes,
      // Physician information
      physicianFirstName: users.firstName,
      physicianLastName: users.lastName,
      physicianEmail: users.email
    }).from(patientAssignments).innerJoin(users, eq2(patientAssignments.physicianId, users.id)).where(and2(
      eq2(patientAssignments.patientId, patientId),
      eq2(patientAssignments.tenantId, tenantId),
      eq2(patientAssignments.isActive, true)
    )).orderBy(desc2(patientAssignments.assignedDate));
  }
  async getActivePatientAssignments(tenantId) {
    return await db.select({
      id: patientAssignments.id,
      patientId: patientAssignments.patientId,
      physicianId: patientAssignments.physicianId,
      assignmentType: patientAssignments.assignmentType,
      assignedDate: patientAssignments.assignedDate,
      expiryDate: patientAssignments.expiryDate,
      notes: patientAssignments.notes,
      // Patient information
      patientName: sql2`${patients.firstName} || ' ' || ${patients.lastName}`,
      patientMRN: patients.mrn,
      patientDateOfBirth: patients.dateOfBirth,
      patientPhone: patients.phone,
      patientEmail: patients.email,
      // Physician information
      physicianName: sql2`${users.firstName} || ' ' || ${users.lastName}`,
      physicianEmail: users.email
    }).from(patientAssignments).innerJoin(patients, eq2(patientAssignments.patientId, patients.id)).innerJoin(users, eq2(patientAssignments.physicianId, users.id)).where(and2(
      eq2(patientAssignments.tenantId, tenantId),
      eq2(patientAssignments.isActive, true)
    )).orderBy(desc2(patientAssignments.assignedDate));
  }
  async removePatientAssignment(id, tenantId) {
    const result = await db.update(patientAssignments).set({ isActive: false, updatedAt: /* @__PURE__ */ new Date() }).where(and2(eq2(patientAssignments.id, id), eq2(patientAssignments.tenantId, tenantId)));
    return result.rowCount !== void 0 && result.rowCount > 0;
  }
  // Patient Access Request Management Implementation
  async getPatientAccessRequest(id, tenantId) {
    const [request] = await db.select().from(patientAccessRequests).where(
      and2(eq2(patientAccessRequests.id, id), eq2(patientAccessRequests.tenantId, tenantId))
    );
    return request || void 0;
  }
  // Removed duplicate methods - using properly typed versions below
  async getPatientAccessRequestsByPhysician(physicianId, tenantId) {
    return await db.select({
      id: patientAccessRequests.id,
      patientId: patientAccessRequests.patientId,
      requestType: patientAccessRequests.requestType,
      reason: patientAccessRequests.reason,
      urgency: patientAccessRequests.urgency,
      status: patientAccessRequests.status,
      requestedDate: patientAccessRequests.requestedDate,
      reviewedDate: patientAccessRequests.reviewedDate,
      reviewNotes: patientAccessRequests.reviewNotes,
      accessGrantedUntil: patientAccessRequests.accessGrantedUntil,
      // Patient information
      patientFirstName: patients.firstName,
      patientLastName: patients.lastName,
      patientMRN: patients.mrn,
      // Target physician information (if applicable)
      targetPhysicianFirstName: users.firstName,
      targetPhysicianLastName: users.lastName
    }).from(patientAccessRequests).innerJoin(patients, eq2(patientAccessRequests.patientId, patients.id)).leftJoin(users, eq2(patientAccessRequests.targetPhysicianId, users.id)).where(and2(
      eq2(patientAccessRequests.requestingPhysicianId, physicianId),
      eq2(patientAccessRequests.tenantId, tenantId)
    )).orderBy(desc2(patientAccessRequests.requestedDate));
  }
  async getPendingPatientAccessRequests(tenantId) {
    return await db.select({
      id: patientAccessRequests.id,
      patientId: patientAccessRequests.patientId,
      requestingPhysicianId: patientAccessRequests.requestingPhysicianId,
      requestType: patientAccessRequests.requestType,
      reason: patientAccessRequests.reason,
      urgency: patientAccessRequests.urgency,
      requestedDate: patientAccessRequests.requestedDate,
      // Patient information
      patientFirstName: patients.firstName,
      patientLastName: patients.lastName,
      patientMRN: patients.mrn,
      // Requesting physician information
      requestingPhysicianFirstName: users.firstName,
      requestingPhysicianLastName: users.lastName,
      requestingPhysicianEmail: users.email
    }).from(patientAccessRequests).innerJoin(patients, eq2(patientAccessRequests.patientId, patients.id)).innerJoin(users, eq2(patientAccessRequests.requestingPhysicianId, users.id)).where(and2(
      eq2(patientAccessRequests.tenantId, tenantId),
      eq2(patientAccessRequests.status, "pending")
    )).orderBy(desc2(patientAccessRequests.requestedDate));
  }
  async approvePatientAccessRequest(id, reviewedBy, tenantId, accessUntil) {
    const [updated] = await db.update(patientAccessRequests).set({
      status: "approved",
      reviewedBy,
      reviewedDate: /* @__PURE__ */ new Date(),
      accessGrantedUntil: accessUntil,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(and2(eq2(patientAccessRequests.id, id), eq2(patientAccessRequests.tenantId, tenantId))).returning();
    return updated || void 0;
  }
  async denyPatientAccessRequest(id, reviewedBy, reviewNotes, tenantId) {
    const [updated] = await db.update(patientAccessRequests).set({
      status: "denied",
      reviewedBy,
      reviewedDate: /* @__PURE__ */ new Date(),
      reviewNotes,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(and2(eq2(patientAccessRequests.id, id), eq2(patientAccessRequests.tenantId, tenantId))).returning();
    return updated || void 0;
  }
  // Enhanced Patient Methods with Assignment Controls
  async getAssignedPatients(physicianId, tenantId) {
    return await db.select({
      id: patients.id,
      tenantId: patients.tenantId,
      mrn: patients.mrn,
      firstName: patients.firstName,
      lastName: patients.lastName,
      dateOfBirth: patients.dateOfBirth,
      gender: patients.gender,
      phone: patients.phone,
      email: patients.email,
      address: patients.address,
      emergencyContact: patients.emergencyContact,
      insuranceInfo: patients.insuranceInfo,
      preferredPharmacyId: patients.preferredPharmacyId,
      primaryPhysicianId: patients.primaryPhysicianId,
      medicalHistory: patients.medicalHistory,
      allergies: patients.allergies,
      medications: patients.medications,
      isActive: patients.isActive,
      createdAt: patients.createdAt,
      updatedAt: patients.updatedAt
    }).from(patients).innerJoin(patientAssignments, eq2(patients.id, patientAssignments.patientId)).where(and2(
      eq2(patientAssignments.physicianId, physicianId),
      eq2(patientAssignments.tenantId, tenantId),
      eq2(patientAssignments.isActive, true),
      eq2(patients.isActive, true)
    )).orderBy(patients.lastName, patients.firstName);
  }
  async hasPatientAccess(physicianId, patientId, tenantId) {
    const assignment = await db.select().from(patientAssignments).where(
      and2(
        eq2(patientAssignments.physicianId, physicianId),
        eq2(patientAssignments.patientId, patientId),
        eq2(patientAssignments.tenantId, tenantId),
        eq2(patientAssignments.isActive, true)
      )
    ).limit(1);
    if (assignment.length > 0) {
      return true;
    }
    const accessRequest = await db.select().from(patientAccessRequests).where(
      and2(
        eq2(patientAccessRequests.requestingPhysicianId, physicianId),
        eq2(patientAccessRequests.patientId, patientId),
        eq2(patientAccessRequests.tenantId, tenantId),
        eq2(patientAccessRequests.status, "approved"),
        or(
          isNull(patientAccessRequests.accessGrantedUntil),
          gt(patientAccessRequests.accessGrantedUntil, /* @__PURE__ */ new Date())
        )
      )
    ).limit(1);
    return accessRequest.length > 0;
  }
  async getPatientWithAccessCheck(patientId, physicianId, tenantId) {
    const hasAccess = await this.hasPatientAccess(physicianId, patientId, tenantId);
    if (!hasAccess) {
      return void 0;
    }
    return await this.getPatient(patientId, tenantId);
  }
  // Pharmacy Receipt Management Implementation
  async getPharmacyReceipt(id, tenantId) {
    const [receipt] = await db.select().from(pharmacyReceipts).where(
      and2(eq2(pharmacyReceipts.id, id), eq2(pharmacyReceipts.tenantId, tenantId))
    );
    return receipt || void 0;
  }
  async createPharmacyReceipt(receipt) {
    const [newReceipt] = await db.insert(pharmacyReceipts).values(receipt).returning();
    return newReceipt;
  }
  async updatePharmacyReceipt(id, updates, tenantId) {
    const [updatedReceipt] = await db.update(pharmacyReceipts).set({ ...updates, updatedAt: /* @__PURE__ */ new Date() }).where(and2(eq2(pharmacyReceipts.id, id), eq2(pharmacyReceipts.tenantId, tenantId))).returning();
    return updatedReceipt || void 0;
  }
  async getPharmacyReceiptsByPatient(patientId, tenantId) {
    return await db.select().from(pharmacyReceipts).where(and2(eq2(pharmacyReceipts.patientId, patientId), eq2(pharmacyReceipts.tenantId, tenantId))).orderBy(desc2(pharmacyReceipts.dispensedDate));
  }
  async getPharmacyReceiptsByPrescription(prescriptionId, tenantId) {
    return await db.select().from(pharmacyReceipts).where(and2(eq2(pharmacyReceipts.prescriptionId, prescriptionId), eq2(pharmacyReceipts.tenantId, tenantId))).orderBy(desc2(pharmacyReceipts.dispensedDate));
  }
  async getPharmacyReceiptsByTenant(tenantId, limit = 50, offset = 0) {
    return await db.select().from(pharmacyReceipts).where(eq2(pharmacyReceipts.tenantId, tenantId)).orderBy(desc2(pharmacyReceipts.dispensedDate)).limit(limit).offset(offset);
  }
  async generateReceiptNumber(tenantId) {
    const tenant = await this.getTenant(tenantId);
    const prefix = tenant?.name?.substring(0, 3).toUpperCase() || "RX";
    const timestamp2 = Date.now().toString();
    const random = Math.floor(Math.random() * 1e3).toString().padStart(3, "0");
    return `${prefix}-${timestamp2}-${random}`;
  }
  // Achievement System Implementation
  async getAchievements() {
    return await db.select().from(achievements).where(eq2(achievements.isActive, true)).orderBy(achievements.name);
  }
  async getAchievement(id) {
    const [achievement] = await db.select().from(achievements).where(eq2(achievements.id, id));
    return achievement || void 0;
  }
  async createAchievement(achievement) {
    const [created] = await db.insert(achievements).values(achievement).returning();
    return created;
  }
  async updateAchievement(id, updates) {
    const [updated] = await db.update(achievements).set({ ...updates, updatedAt: /* @__PURE__ */ new Date() }).where(eq2(achievements.id, id)).returning();
    return updated || void 0;
  }
  async deleteAchievement(id) {
    const result = await db.update(achievements).set({ isActive: false }).where(eq2(achievements.id, id));
    return (result.rowCount || 0) > 0;
  }
  async getUserAchievements(userId, tenantId) {
    return await db.select().from(userAchievements).where(and2(eq2(userAchievements.userId, userId), eq2(userAchievements.tenantId, tenantId))).orderBy(desc2(userAchievements.earnedAt));
  }
  async getUserAchievement(userId, achievementId, tenantId) {
    const [userAchievement] = await db.select().from(userAchievements).where(and2(
      eq2(userAchievements.userId, userId),
      eq2(userAchievements.achievementId, achievementId),
      eq2(userAchievements.tenantId, tenantId)
    ));
    return userAchievement || void 0;
  }
  async createUserAchievement(userAchievement) {
    const [created] = await db.insert(userAchievements).values(userAchievement).returning();
    return created;
  }
  async updateUserAchievement(id, updates) {
    const [updated] = await db.update(userAchievements).set(updates).where(eq2(userAchievements.id, id)).returning();
    return updated || void 0;
  }
  async getUserStats(userId, tenantId) {
    const [stats] = await db.select().from(userStats).where(and2(eq2(userStats.userId, userId), eq2(userStats.tenantId, tenantId)));
    return stats || void 0;
  }
  async createUserStats(userStatsData) {
    const [created] = await db.insert(userStats).values(userStatsData).returning();
    return created;
  }
  async updateUserStats(userId, tenantId, updates) {
    const [updated] = await db.update(userStats).set({ ...updates, updatedAt: /* @__PURE__ */ new Date() }).where(and2(eq2(userStats.userId, userId), eq2(userStats.tenantId, tenantId))).returning();
    return updated || void 0;
  }
  async getLeaderboard(tenantId, period, limit = 10) {
    return await db.select().from(leaderboards).where(and2(eq2(leaderboards.tenantId, tenantId), eq2(leaderboards.period, period))).orderBy(leaderboards.position).limit(limit);
  }
  async updateLeaderboard(tenantId, period) {
    const now = /* @__PURE__ */ new Date();
    let periodStart;
    let periodEnd;
    switch (period) {
      case "daily":
        periodStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        periodEnd = new Date(periodStart.getTime() + 24 * 60 * 60 * 1e3);
        break;
      case "weekly":
        const startOfWeek = now.getDate() - now.getDay();
        periodStart = new Date(now.getFullYear(), now.getMonth(), startOfWeek);
        periodEnd = new Date(periodStart.getTime() + 7 * 24 * 60 * 60 * 1e3);
        break;
      case "monthly":
        periodStart = new Date(now.getFullYear(), now.getMonth(), 1);
        periodEnd = new Date(now.getFullYear(), now.getMonth() + 1, 1);
        break;
      default:
        periodStart = /* @__PURE__ */ new Date(0);
        periodEnd = now;
    }
    const topUsers = await db.select({
      userId: userStats.userId,
      userName: sql2`CONCAT(${users.firstName}, ' ', ${users.lastName})`,
      points: userStats.totalPoints,
      level: userStats.level,
      testsCompleted: userStats.testsCompleted,
      qualityScore: userStats.qualityScore
    }).from(userStats).innerJoin(users, eq2(userStats.userId, users.id)).where(eq2(userStats.tenantId, tenantId)).orderBy(desc2(userStats.totalPoints)).limit(50);
    await db.delete(leaderboards).where(and2(eq2(leaderboards.tenantId, tenantId), eq2(leaderboards.period, period)));
    if (topUsers.length > 0) {
      const leaderboardEntries = topUsers.map((user, index2) => ({
        tenantId,
        userId: user.userId,
        userName: user.userName,
        position: index2 + 1,
        points: user.points,
        level: user.level,
        testsCompleted: user.testsCompleted,
        qualityScore: user.qualityScore || 0,
        period,
        periodStart,
        periodEnd
      }));
      await db.insert(leaderboards).values(leaderboardEntries);
    }
  }
  async getActivityLogs(userId, tenantId, limit = 50) {
    return await db.select().from(activityLogs).where(and2(eq2(activityLogs.userId, userId), eq2(activityLogs.tenantId, tenantId))).orderBy(desc2(activityLogs.timestamp)).limit(limit);
  }
  async createActivityLog(activityLog) {
    const [created] = await db.insert(activityLogs).values(activityLog).returning();
    return created;
  }
  async checkAndUpdateAchievements(userId, tenantId, activityType, metadata) {
    const newAchievements = [];
    const stats = await this.getUserStats(userId, tenantId);
    if (!stats) return newAchievements;
    const allAchievements = await this.getAchievements();
    for (const achievement of allAchievements) {
      const existingUserAchievement = await this.getUserAchievement(userId, achievement.id, tenantId);
      if (!existingUserAchievement) {
        const criteria = achievement.criteria;
        let meetsRequirement = false;
        switch (achievement.type) {
          case "productivity":
            if (criteria.testsCompleted && stats.testsCompleted >= criteria.testsCompleted) {
              meetsRequirement = true;
            }
            break;
          case "quality":
            if (criteria.qualityScore && parseFloat(stats.qualityScore.toString()) >= criteria.qualityScore) {
              meetsRequirement = true;
            }
            break;
          case "consistency":
            if (criteria.streakDays && stats.consistencyStreak >= criteria.streakDays) {
              meetsRequirement = true;
            }
            break;
          case "milestone":
            if (criteria.totalPoints && stats.totalPoints >= criteria.totalPoints) {
              meetsRequirement = true;
            }
            break;
        }
        if (meetsRequirement) {
          const userAchievement = await this.createUserAchievement({
            userId,
            tenantId,
            achievementId: achievement.id,
            progress: 100,
            maxProgress: 100,
            isCompleted: true,
            completedAt: /* @__PURE__ */ new Date()
          });
          newAchievements.push(userAchievement);
          await this.updateUserStats(userId, tenantId, {
            totalPoints: stats.totalPoints + achievement.points
          });
          await this.createActivityLog({
            userId,
            tenantId,
            activityType: "achievement_earned",
            points: achievement.points,
            metadata: { achievementId: achievement.id, achievementName: achievement.name }
          });
        }
      }
    }
    return newAchievements;
  }
  calculateUserLevel(totalPoints) {
    return Math.floor(totalPoints / 100) + 1;
  }
  async updateUserStatsFromActivity(userId, tenantId, activityType, metadata) {
    let stats = await this.getUserStats(userId, tenantId);
    if (!stats) {
      stats = await this.createUserStats({
        userId,
        tenantId,
        level: 1,
        totalPoints: 0,
        testsCompleted: 0,
        averageCompletionTime: 0,
        qualityScore: 0,
        consistencyStreak: 0,
        lastActivityDate: /* @__PURE__ */ new Date()
      });
    }
    const updates = {
      lastActivityDate: /* @__PURE__ */ new Date()
    };
    switch (activityType) {
      case "lab_test_completed":
        updates.testsCompleted = stats.testsCompleted + 1;
        updates.totalPoints = stats.totalPoints + 10;
        if (metadata?.completionTime) {
          const currentAvg = stats.averageCompletionTime;
          const newAvg = (currentAvg * (stats.testsCompleted - 1) + metadata.completionTime) / stats.testsCompleted;
          updates.averageCompletionTime = Math.round(newAvg);
        }
        if (metadata?.quality) {
          const currentScore = parseFloat(stats.qualityScore.toString());
          const newScore = (currentScore * (stats.testsCompleted - 1) + metadata.quality) / stats.testsCompleted;
          updates.qualityScore = Math.round(newScore * 100) / 100;
        }
        const lastActivity = stats.lastActivityDate;
        const today = /* @__PURE__ */ new Date();
        const daysDiff = Math.floor((today.getTime() - (lastActivity?.getTime() || 0)) / (1e3 * 60 * 60 * 24));
        if (daysDiff <= 1) {
          updates.consistencyStreak = stats.consistencyStreak + 1;
        } else if (daysDiff > 1) {
          updates.consistencyStreak = 1;
        }
        break;
    }
    if (updates.totalPoints) {
      updates.level = this.calculateUserLevel(updates.totalPoints);
    }
    return await this.updateUserStats(userId, tenantId, updates);
  }
  // Work Shift Management Implementation
  async getWorkShift(id, tenantId) {
    const [shift] = await db.select().from(workShifts).where(
      and2(eq2(workShifts.id, id), eq2(workShifts.tenantId, tenantId))
    );
    return shift || void 0;
  }
  async createWorkShift(shift) {
    const [newShift] = await db.insert(workShifts).values(shift).returning();
    return newShift;
  }
  async updateWorkShift(id, updates, tenantId) {
    const [updatedShift] = await db.update(workShifts).set(updates).where(and2(eq2(workShifts.id, id), eq2(workShifts.tenantId, tenantId))).returning();
    return updatedShift || void 0;
  }
  async getActiveWorkShifts(tenantId) {
    return await db.select().from(workShifts).where(
      eq2(workShifts.tenantId, tenantId)
    ).orderBy(desc2(workShifts.startTime));
  }
  async endWorkShift(id, tenantId) {
    const [shift] = await db.update(workShifts).set({ endTime: /* @__PURE__ */ new Date() }).where(and2(eq2(workShifts.id, id), eq2(workShifts.tenantId, tenantId))).returning();
    return shift || void 0;
  }
  async getCurrentWorkShift(userId, tenantId) {
    const [shift] = await db.select().from(workShifts).where(
      and2(
        eq2(workShifts.userId, userId),
        eq2(workShifts.tenantId, tenantId),
        isNull(workShifts.endTime)
      )
    );
    return shift || void 0;
  }
  // Pharmacy Patient Insurance Management Implementation
  async getPharmacyPatientInsurance(patientId, tenantId) {
    const [insurance] = await db.select().from(pharmacyPatientInsurance).where(
      and2(eq2(pharmacyPatientInsurance.patientId, patientId), eq2(pharmacyPatientInsurance.tenantId, tenantId))
    );
    return insurance || void 0;
  }
  async createPharmacyPatientInsurance(insurance) {
    const [newInsurance] = await db.insert(pharmacyPatientInsurance).values(insurance).returning();
    return newInsurance;
  }
  async updatePharmacyPatientInsurance(id, updates, tenantId) {
    const [updatedInsurance] = await db.update(pharmacyPatientInsurance).set(updates).where(and2(eq2(pharmacyPatientInsurance.id, id), eq2(pharmacyPatientInsurance.tenantId, tenantId))).returning();
    return updatedInsurance || void 0;
  }
  async getPharmacyPatientInsuranceByTenant(tenantId) {
    return await db.select().from(pharmacyPatientInsurance).where(eq2(pharmacyPatientInsurance.tenantId, tenantId));
  }
  // Archived Records Management Implementation
  async createArchivedRecord(record) {
    const [newRecord] = await db.insert(archivedRecords).values(record).returning();
    return newRecord;
  }
  async searchArchivedRecords(tenantId, query) {
    return await db.select().from(archivedRecords).where(
      and2(
        eq2(archivedRecords.tenantId, tenantId),
        or(
          like(archivedRecords.recordType, `%${query}%`),
          like(archivedRecords.searchableContent, `%${query}%`)
        )
      )
    ).orderBy(desc2(archivedRecords.createdAt));
  }
  async getArchivedRecordsByShift(workShiftId, tenantId) {
    return await db.select().from(archivedRecords).where(
      and2(eq2(archivedRecords.workShiftId, workShiftId), eq2(archivedRecords.tenantId, tenantId))
    );
  }
  async getArchivedRecordsByPatient(patientId, tenantId) {
    return await db.select().from(archivedRecords).where(
      and2(eq2(archivedRecords.patientId, patientId), eq2(archivedRecords.tenantId, tenantId))
    ).orderBy(desc2(archivedRecords.createdAt));
  }
  async archiveRecordsForShift(workShiftId, tenantId) {
    console.log(`Archiving records for shift ${workShiftId} in tenant ${tenantId}`);
  }
  // Pharmacy Report Templates Management Implementation
  async getPharmacyReportTemplate(id, tenantId) {
    const [template] = await db.select().from(pharmacyReportTemplates).where(
      and2(eq2(pharmacyReportTemplates.id, id), eq2(pharmacyReportTemplates.tenantId, tenantId))
    );
    return template || void 0;
  }
  async createPharmacyReportTemplate(template) {
    const [newTemplate] = await db.insert(pharmacyReportTemplates).values(template).returning();
    return newTemplate;
  }
  async updatePharmacyReportTemplate(id, updates, tenantId) {
    const [updatedTemplate] = await db.update(pharmacyReportTemplates).set(updates).where(and2(eq2(pharmacyReportTemplates.id, id), eq2(pharmacyReportTemplates.tenantId, tenantId))).returning();
    return updatedTemplate || void 0;
  }
  // Report Generation Methods
  async generateSalesReport(tenantId, dateRange = {}) {
    const { start, end } = dateRange;
    let query = db.select({
      date: sql2`DATE(${pharmacyReceipts.createdAt})`,
      totalAmount: sql2`SUM(${pharmacyReceipts.paymentAmount})`,
      transactionCount: sql2`COUNT(*)`,
      averageAmount: sql2`AVG(${pharmacyReceipts.paymentAmount})`,
      totalCost: sql2`SUM(${pharmacyReceipts.totalCost})`,
      insuranceAmount: sql2`SUM(${pharmacyReceipts.insuranceAmount})`,
      copayAmount: sql2`SUM(${pharmacyReceipts.patientCopay})`
    }).from(pharmacyReceipts).where(eq2(pharmacyReceipts.tenantId, tenantId));
    if (start) {
      query = query.where(sql2`${pharmacyReceipts.createdAt} >= ${start}`);
    }
    if (end) {
      query = query.where(sql2`${pharmacyReceipts.createdAt} <= ${end}`);
    }
    return await query.groupBy(sql2`DATE(${pharmacyReceipts.createdAt})`).orderBy(sql2`DATE(${pharmacyReceipts.createdAt}) DESC`);
  }
  async generatePrescriptionReport(tenantId, dateRange = {}) {
    const { start, end } = dateRange;
    let query = db.select({
      patientName: sql2`CONCAT(${patients.firstName}, ' ', ${patients.lastName})`,
      medicationName: prescriptions.medicationName,
      quantity: prescriptions.quantity,
      dispensedDate: sql2`DATE(${prescriptions.updatedAt})`,
      prescribedBy: prescriptions.prescribedBy,
      status: prescriptions.status
    }).from(prescriptions).leftJoin(patients, eq2(prescriptions.patientId, patients.id)).where(eq2(prescriptions.tenantId, tenantId));
    if (start) {
      query = query.where(sql2`${prescriptions.updatedAt} >= ${start}`);
    }
    if (end) {
      query = query.where(sql2`${prescriptions.updatedAt} <= ${end}`);
    }
    return await query.orderBy(desc2(prescriptions.updatedAt));
  }
  async generateInventoryReport(tenantId, dateRange = {}) {
    const medicationList = [
      { name: "Amoxicillin", currentStock: 150, minimumStock: 50, expiryDate: "2025-12-31", supplier: "PharmaCorp" },
      { name: "Ibuprofen", currentStock: 200, minimumStock: 75, expiryDate: "2026-06-30", supplier: "MediSupply" },
      { name: "Metformin", currentStock: 89, minimumStock: 100, expiryDate: "2025-09-15", supplier: "HealthDist" },
      { name: "Lisinopril", currentStock: 45, minimumStock: 30, expiryDate: "2026-03-20", supplier: "PharmaCorp" },
      { name: "Atorvastatin", currentStock: 120, minimumStock: 60, expiryDate: "2025-11-10", supplier: "MediSupply" }
    ];
    return medicationList.map((med) => ({
      medicationName: med.name,
      currentStock: med.currentStock,
      minimumStock: med.minimumStock,
      stockStatus: med.currentStock <= med.minimumStock ? "Low Stock" : "In Stock",
      expiryDate: med.expiryDate,
      supplier: med.supplier,
      lastUpdated: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
    }));
  }
  async generatePatientReport(tenantId, dateRange = {}) {
    const { start, end } = dateRange;
    let query = db.select({
      patientName: sql2`CONCAT(${patients.firstName}, ' ', ${patients.lastName})`,
      email: patients.email,
      phone: patients.phone,
      registrationDate: sql2`DATE(${patients.createdAt})`,
      lastVisit: sql2`MAX(DATE(${appointments.appointmentDate}))`,
      totalPrescriptions: sql2`COUNT(DISTINCT ${prescriptions.id})`,
      insuranceProvider: pharmacyPatientInsurance.insuranceProvider
    }).from(patients).leftJoin(appointments, eq2(patients.id, appointments.patientId)).leftJoin(prescriptions, eq2(patients.id, prescriptions.patientId)).leftJoin(pharmacyPatientInsurance, eq2(patients.id, pharmacyPatientInsurance.patientId)).where(eq2(patients.tenantId, tenantId));
    if (start) {
      query = query.where(sql2`${patients.createdAt} >= ${start}`);
    }
    if (end) {
      query = query.where(sql2`${patients.createdAt} <= ${end}`);
    }
    return await query.groupBy(patients.id, patients.firstName, patients.lastName, patients.email, patients.phone, patients.createdAt, pharmacyPatientInsurance.insuranceProvider);
  }
  async generateInsuranceReport(tenantId, dateRange = {}) {
    const { start, end } = dateRange;
    let query = db.select({
      insuranceProvider: pharmacyPatientInsurance.insuranceProvider,
      policyNumber: pharmacyPatientInsurance.policyNumber,
      patientName: sql2`CONCAT(${patients.firstName}, ' ', ${patients.lastName})`,
      coverageType: pharmacyPatientInsurance.coverageType,
      copayAmount: pharmacyPatientInsurance.copayAmount,
      deductibleAmount: pharmacyPatientInsurance.deductibleAmount,
      effectiveDate: pharmacyPatientInsurance.effectiveDate,
      status: pharmacyPatientInsurance.isActive
    }).from(pharmacyPatientInsurance).leftJoin(patients, eq2(pharmacyPatientInsurance.patientId, patients.id)).where(eq2(pharmacyPatientInsurance.tenantId, tenantId));
    if (start) {
      query = query.where(sql2`${pharmacyPatientInsurance.createdAt} >= ${start}`);
    }
    if (end) {
      query = query.where(sql2`${pharmacyPatientInsurance.createdAt} <= ${end}`);
    }
    return await query.orderBy(desc2(pharmacyPatientInsurance.createdAt));
  }
  async generatePatientReportForPharmacy(tenantId, dateRange = {}) {
    const { start, end } = dateRange;
    let query = db.select({
      patientId: prescriptions.patientId,
      patientName: sql2`CONCAT(${patients.firstName}, ' ', ${patients.lastName})`,
      prescriptionCount: sql2`COUNT(*)`,
      totalMedications: sql2`SUM(${prescriptions.quantity})`,
      lastVisit: sql2`MAX(${prescriptions.createdAt})`,
      averageQuantity: sql2`AVG(${prescriptions.quantity})`
    }).from(prescriptions).innerJoin(patients, eq2(prescriptions.patientId, patients.id)).where(eq2(prescriptions.pharmacyId, tenantId));
    if (start) {
      query = query.where(sql2`${prescriptions.createdAt} >= ${start}`);
    }
    if (end) {
      query = query.where(sql2`${prescriptions.createdAt} <= ${end}`);
    }
    return await query.groupBy(prescriptions.patientId, patients.firstName, patients.lastName).orderBy(sql2`COUNT(*) DESC`);
  }
  // Removed duplicate method - using the first implementation above
  async getPharmacyReportTemplatesByTenant(tenantId) {
    return await db.select().from(pharmacyReportTemplates).where(eq2(pharmacyReportTemplates.tenantId, tenantId));
  }
  // Hospital Patient Insurance Management
  async createHospitalPatientInsurance(data) {
    const result = await db.insert(hospitalPatientInsurance).values(data).returning();
    return result[0];
  }
  async getHospitalPatientInsuranceByPatientId(patientId, tenantId) {
    if (!tenantId) {
      console.error("[SECURITY VIOLATION] Hospital patient insurance access without tenant context");
      throw new Error("Tenant context required for insurance data access");
    }
    console.log(`[SECURITY AUDIT] Hospital patient insurance access for patient ${patientId} by tenant ${tenantId}`);
    const result = await db.select().from(hospitalPatientInsurance).where(and2(
      eq2(hospitalPatientInsurance.patientId, patientId),
      eq2(hospitalPatientInsurance.tenantId, tenantId)
    )).limit(1);
    return result[0] || null;
  }
  async updateHospitalPatientInsurance(id, data) {
    const result = await db.update(hospitalPatientInsurance).set(data).where(eq2(hospitalPatientInsurance.id, id)).returning();
    return result[0];
  }
  // Laboratory Patient Insurance Management
  async createLaboratoryPatientInsurance(data) {
    const result = await db.insert(laboratoryPatientInsurance).values(data).returning();
    return result[0];
  }
  async getLaboratoryPatientInsuranceByPatientId(patientId, tenantId) {
    if (!tenantId) {
      console.error("[SECURITY VIOLATION] Laboratory patient insurance access without tenant context");
      throw new Error("Tenant context required for insurance data access");
    }
    console.log(`[SECURITY AUDIT] Laboratory patient insurance access for patient ${patientId} by tenant ${tenantId}`);
    const result = await db.select().from(laboratoryPatientInsurance).where(and2(
      eq2(laboratoryPatientInsurance.patientId, patientId),
      eq2(laboratoryPatientInsurance.tenantId, tenantId)
    )).limit(1);
    return result[0] || null;
  }
  async updateLaboratoryPatientInsurance(id, data) {
    const result = await db.update(laboratoryPatientInsurance).set(data).where(eq2(laboratoryPatientInsurance.id, id)).returning();
    return result[0];
  }
  async getActivePharmacyReportTemplatesByTenant(tenantId) {
    return await db.select().from(pharmacyReportTemplates).where(
      and2(eq2(pharmacyReportTemplates.tenantId, tenantId), eq2(pharmacyReportTemplates.isActive, true))
    );
  }
  async getActivePharmacyReportTemplates(tenantId) {
    return await db.select().from(pharmacyReportTemplates).where(
      and2(eq2(pharmacyReportTemplates.tenantId, tenantId), eq2(pharmacyReportTemplates.isActive, true))
    );
  }
  // Hospital Billing Management Implementation
  async getHospitalBill(id, tenantId) {
    const [bill] = await db.select().from(hospitalBills).where(
      and2(eq2(hospitalBills.id, id), eq2(hospitalBills.tenantId, tenantId))
    );
    return bill || void 0;
  }
  async getHospitalBills(tenantId) {
    const bills = await db.select().from(hospitalBills).where(eq2(hospitalBills.tenantId, tenantId)).orderBy(desc2(hospitalBills.createdAt));
    const enrichedBills = [];
    for (const bill of bills) {
      const patient = await db.select().from(patients).where(eq2(patients.id, bill.patientId)).limit(1);
      enrichedBills.push({
        ...bill,
        patientFirstName: patient[0]?.firstName || "",
        patientLastName: patient[0]?.lastName || "",
        patientMrn: patient[0]?.mrn || "",
        physicianName: ""
        // Will be populated when appointment data is linked
      });
    }
    return enrichedBills;
  }
  async getHospitalBillsByProvider(providerId, tenantId) {
    const providerAppointments = await db.select().from(appointments).where(and2(eq2(appointments.providerId, providerId), eq2(appointments.tenantId, tenantId)));
    const appointmentIds = providerAppointments.map((apt) => apt.id);
    if (appointmentIds.length === 0) {
      return [];
    }
    const bills = await db.select().from(hospitalBills).where(
      and2(
        eq2(hospitalBills.tenantId, tenantId),
        sql2`${hospitalBills.appointmentId} = ANY(${appointmentIds})`
      )
    ).orderBy(desc2(hospitalBills.createdAt));
    const enrichedBills = [];
    for (const bill of bills) {
      const patient = await db.select().from(patients).where(eq2(patients.id, bill.patientId)).limit(1);
      const physician = await db.select().from(users).where(eq2(users.id, providerId)).limit(1);
      enrichedBills.push({
        ...bill,
        patientFirstName: patient[0]?.firstName || "",
        patientLastName: patient[0]?.lastName || "",
        patientMrn: patient[0]?.mrn || "",
        physicianName: physician[0] ? `${physician[0].firstName} ${physician[0].lastName}` : ""
      });
    }
    return enrichedBills;
  }
  async createHospitalBill(bill) {
    const billNumber = `HB-${Date.now()}`;
    const [newBill] = await db.insert(hospitalBills).values({
      ...bill,
      billNumber
    }).returning();
    return newBill;
  }
  async updateHospitalBill(id, updates, tenantId) {
    const [updatedBill] = await db.update(hospitalBills).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(eq2(hospitalBills.id, id), eq2(hospitalBills.tenantId, tenantId))).returning();
    return updatedBill || void 0;
  }
  async getHospitalAnalytics(tenantId) {
    const totalBills = await db.select({ count: sql2`COUNT(*)`.as("count") }).from(hospitalBills).where(eq2(hospitalBills.tenantId, tenantId));
    const totalRevenue = await db.select({
      revenue: sql2`SUM(CAST(amount AS DECIMAL))`.as("revenue")
    }).from(hospitalBills).where(eq2(hospitalBills.tenantId, tenantId));
    const pendingBills = await db.select({ count: sql2`COUNT(*)`.as("count") }).from(hospitalBills).where(and2(eq2(hospitalBills.tenantId, tenantId), eq2(hospitalBills.status, "pending")));
    const paidBills = await db.select({ count: sql2`COUNT(*)`.as("count") }).from(hospitalBills).where(and2(eq2(hospitalBills.tenantId, tenantId), eq2(hospitalBills.status, "paid")));
    return {
      totalBills: totalBills[0]?.count || 0,
      totalRevenue: totalRevenue[0]?.revenue || 0,
      pendingBills: pendingBills[0]?.count || 0,
      paidBills: paidBills[0]?.count || 0,
      completionRate: totalBills[0]?.count > 0 ? ((paidBills[0]?.count || 0) / totalBills[0].count * 100).toFixed(1) : 0
    };
  }
  // Patient Access Request Management for Multi-Doctor Separation
  async createPatientAccessRequest(request) {
    const [newRequest] = await db.insert(patientAccessRequests).values(request).returning();
    return newRequest;
  }
  async getPatientAccessRequests(tenantId, doctorId) {
    const whereClause = doctorId ? and2(
      eq2(patientAccessRequests.tenantId, tenantId),
      or(
        eq2(patientAccessRequests.requestingPhysicianId, doctorId),
        eq2(patientAccessRequests.targetPhysicianId, doctorId)
      )
    ) : eq2(patientAccessRequests.tenantId, tenantId);
    return await db.select().from(patientAccessRequests).where(whereClause).orderBy(desc2(patientAccessRequests.createdAt));
  }
  async updatePatientAccessRequest(id, updates, tenantId) {
    const [updatedRequest] = await db.update(patientAccessRequests).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(eq2(patientAccessRequests.id, id), eq2(patientAccessRequests.tenantId, tenantId))).returning();
    return updatedRequest || void 0;
  }
  async logPatientAccess(log2) {
    const [newLog] = await db.insert(patientAccessAuditLog).values(log2).returning();
    return newLog;
  }
  async getPatientAccessLogs(tenantId, patientId, doctorId) {
    let whereClause = eq2(patientAccessAuditLog.tenantId, tenantId);
    if (patientId) {
      whereClause = and2(whereClause, eq2(patientAccessAuditLog.patientId, patientId));
    }
    if (doctorId) {
      whereClause = and2(whereClause, eq2(patientAccessAuditLog.doctorId, doctorId));
    }
    return await db.select().from(patientAccessAuditLog).where(whereClause).orderBy(desc2(patientAccessAuditLog.accessedAt));
  }
  async checkDoctorPatientAccess(doctorId, patientId, tenantId) {
    const assignment = await db.select().from(patientAssignments).where(
      and2(
        eq2(patientAssignments.tenantId, tenantId),
        eq2(patientAssignments.patientId, patientId),
        eq2(patientAssignments.physicianId, doctorId),
        eq2(patientAssignments.isActive, true)
      )
    ).limit(1);
    if (assignment.length > 0) {
      return true;
    }
    const activeRequest = await db.select().from(patientAccessRequests).where(
      and2(
        eq2(patientAccessRequests.tenantId, tenantId),
        eq2(patientAccessRequests.patientId, patientId),
        eq2(patientAccessRequests.requestingPhysicianId, doctorId),
        eq2(patientAccessRequests.status, "approved"),
        sql2`${patientAccessRequests.accessGrantedUntil} > NOW()`
      )
    ).limit(1);
    return activeRequest.length > 0;
  }
  async getHospitalAnalyticsByProvider(providerId, tenantId) {
    const totalBills = await db.select({ count: sql2`COUNT(*)`.as("count") }).from(hospitalBills).leftJoin(appointments, eq2(hospitalBills.appointmentId, appointments.id)).where(
      and2(
        eq2(hospitalBills.tenantId, tenantId),
        eq2(appointments.providerId, providerId)
      )
    );
    const totalRevenue = await db.select({
      revenue: sql2`SUM(CAST(hospital_bills.amount AS DECIMAL))`.as("revenue")
    }).from(hospitalBills).leftJoin(appointments, eq2(hospitalBills.appointmentId, appointments.id)).where(
      and2(
        eq2(hospitalBills.tenantId, tenantId),
        eq2(appointments.providerId, providerId)
      )
    );
    const pendingBills = await db.select({ count: sql2`COUNT(*)`.as("count") }).from(hospitalBills).leftJoin(appointments, eq2(hospitalBills.appointmentId, appointments.id)).where(
      and2(
        eq2(hospitalBills.tenantId, tenantId),
        eq2(appointments.providerId, providerId),
        eq2(hospitalBills.status, "pending")
      )
    );
    const paidBills = await db.select({ count: sql2`COUNT(*)`.as("count") }).from(hospitalBills).leftJoin(appointments, eq2(hospitalBills.appointmentId, appointments.id)).where(
      and2(
        eq2(hospitalBills.tenantId, tenantId),
        eq2(appointments.providerId, providerId),
        eq2(hospitalBills.status, "paid")
      )
    );
    return {
      totalBills: totalBills[0]?.count || 0,
      totalRevenue: totalRevenue[0]?.revenue || 0,
      pendingBills: pendingBills[0]?.count || 0,
      paidBills: paidBills[0]?.count || 0,
      completionRate: totalBills[0]?.count > 0 ? ((paidBills[0]?.count || 0) / totalBills[0].count * 100).toFixed(1) : 0
    };
  }
  // Department Management
  async getDepartments(tenantId) {
    return db.select().from(departments).where(eq2(departments.tenantId, tenantId)).orderBy(departments.name);
  }
  async createDepartment(data) {
    const { id, createdAt, updatedAt, ...cleanData } = data;
    const uuid2 = crypto.randomUUID();
    const processedData = {
      id: uuid2,
      ...cleanData,
      specializations: cleanData.specializations && cleanData.specializations.length > 0 ? cleanData.specializations : null,
      certifications: cleanData.certifications && cleanData.certifications.length > 0 ? cleanData.certifications : null,
      equipment: cleanData.equipment && Array.isArray(cleanData.equipment) && cleanData.equipment.length > 0 ? cleanData.equipment : null
    };
    const [department] = await db.insert(departments).values(processedData).returning();
    return department;
  }
  async updateDepartment(id, data, tenantId) {
    const processedData = {
      ...data,
      specializations: data.specializations && data.specializations.length > 0 ? data.specializations : null,
      certifications: data.certifications && data.certifications.length > 0 ? data.certifications : null,
      equipment: data.equipment && Array.isArray(data.equipment) && data.equipment.length > 0 ? data.equipment : null,
      updatedAt: /* @__PURE__ */ new Date()
    };
    const [updated] = await db.update(departments).set(processedData).where(and2(
      eq2(departments.id, id),
      eq2(departments.tenantId, tenantId)
    )).returning();
    return updated || null;
  }
  async deleteDepartment(id, tenantId) {
    const result = await db.delete(departments).where(and2(
      eq2(departments.id, id),
      eq2(departments.tenantId, tenantId)
    ));
    return result.rowCount > 0;
  }
  async getDepartmentById(id, tenantId) {
    const [department] = await db.select().from(departments).where(and2(
      eq2(departments.id, id),
      eq2(departments.tenantId, tenantId)
    )).limit(1);
    return department || null;
  }
  // Advertisement Management Implementation
  async getAllAdvertisements() {
    return await db.select().from(advertisements).where(eq2(advertisements.status, "active")).orderBy(desc2(advertisements.createdAt));
  }
  async getAdvertisement(id) {
    const [advertisement] = await db.select().from(advertisements).where(eq2(advertisements.id, id)).limit(1);
    return advertisement || void 0;
  }
  async getAdvertisementsByTenant(tenantId) {
    return await db.select().from(advertisements).where(eq2(advertisements.tenantId, tenantId)).orderBy(desc2(advertisements.createdAt));
  }
  async createAdvertisement(advertisement) {
    const [created] = await db.insert(advertisements).values(advertisement).returning();
    return created;
  }
  async updateAdvertisement(id, updates, tenantId) {
    const [updated] = await db.update(advertisements).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(and2(
      eq2(advertisements.id, id),
      eq2(advertisements.tenantId, tenantId)
    )).returning();
    return updated || void 0;
  }
  async updateAdvertisementStatus(id, statusUpdate) {
    const [updated] = await db.update(advertisements).set({
      status: statusUpdate.status,
      reviewNotes: statusUpdate.reviewNotes,
      reviewedBy: statusUpdate.reviewedBy,
      reviewedAt: statusUpdate.reviewedAt ? new Date(statusUpdate.reviewedAt) : void 0,
      updatedAt: sql2`CURRENT_TIMESTAMP`
    }).where(eq2(advertisements.id, id)).returning();
    return updated || void 0;
  }
  async deleteAdvertisement(id, tenantId) {
    const result = await db.delete(advertisements).where(and2(
      eq2(advertisements.id, id),
      eq2(advertisements.tenantId, tenantId)
    ));
    return result.rowCount > 0;
  }
  async incrementAdvertisementImpressions(id) {
    await db.update(advertisements).set({
      impressions: sql2`${advertisements.impressions} + 1`,
      updatedAt: sql2`CURRENT_TIMESTAMP`
    }).where(eq2(advertisements.id, id));
  }
  async incrementAdvertisementClicks(id) {
    await db.update(advertisements).set({
      clicks: sql2`${advertisements.clicks} + 1`,
      updatedAt: sql2`CURRENT_TIMESTAMP`
    }).where(eq2(advertisements.id, id));
  }
  // Advertisement Views Management
  async createAdView(view) {
    const [created] = await db.insert(adViews).values(view).returning();
    return created;
  }
  async getAdViews(advertisementId) {
    return await db.select().from(adViews).where(eq2(adViews.advertisementId, advertisementId)).orderBy(desc2(adViews.viewedAt));
  }
  // Advertisement Inquiries Management
  async createAdInquiry(inquiry) {
    const [created] = await db.insert(adInquiries).values(inquiry).returning();
    return created;
  }
  async getAdInquiries(advertisementId) {
    return await db.select().from(adInquiries).where(eq2(adInquiries.advertisementId, advertisementId)).orderBy(desc2(adInquiries.createdAt));
  }
  async updateAdInquiry(id, updates) {
    const [updated] = await db.update(adInquiries).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(eq2(adInquiries.id, id)).returning();
    return updated || void 0;
  }
  // Medical Suppliers Management
  async createMedicalSupplier(supplier) {
    const baseSlug = supplier.companyName.toLowerCase().replace(/[^a-z0-9]/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
    let organizationSlug = baseSlug;
    let counter = 1;
    while (true) {
      const existing = await db.select().from(medicalSuppliers).where(eq2(medicalSuppliers.organizationSlug, organizationSlug)).limit(1);
      if (existing.length === 0) {
        break;
      }
      organizationSlug = `${baseSlug}-${counter}`;
      counter++;
    }
    const [created] = await db.insert(medicalSuppliers).values({
      ...supplier,
      organizationSlug,
      status: "pending_review"
    }).returning();
    return created;
  }
  async getMedicalSupplier(id) {
    const [supplier] = await db.select().from(medicalSuppliers).where(eq2(medicalSuppliers.id, id));
    return supplier || void 0;
  }
  async getMedicalSupplierByEmail(email) {
    const [supplier] = await db.select().from(medicalSuppliers).where(eq2(medicalSuppliers.contactEmail, email));
    return supplier || void 0;
  }
  async getMedicalSuppliers() {
    return await db.select().from(medicalSuppliers).orderBy(desc2(medicalSuppliers.createdAt));
  }
  async getMedicalSupplierById(id) {
    const [supplier] = await db.select().from(medicalSuppliers).where(eq2(medicalSuppliers.id, id));
    return supplier || void 0;
  }
  // =====================================
  // PUBLIC MARKETPLACE PRODUCTS 
  // =====================================
  async getPublicMarketplaceProducts() {
    try {
      console.log("[MARKETPLACE] Starting to fetch public products...");
      const products = await db.select().from(marketplaceProducts).where(eq2(marketplaceProducts.status, "active"));
      console.log(`[MARKETPLACE] Found ${products.length} active products in database`);
      const enhancedProducts = products.map((product) => ({
        ...product,
        supplierName: "Medical Supplier",
        // Simplified for now
        supplierContact: {
          email: "contact@supplier.com",
          phone: "+1-555-0123",
          address: "123 Healthcare Ave"
        },
        rating: 4.5,
        reviews: Math.floor(Math.random() * 50) + 5
      }));
      console.log(`[MARKETPLACE] Returning ${enhancedProducts.length} enhanced products`);
      return enhancedProducts;
    } catch (error) {
      console.error("[MARKETPLACE] Error fetching marketplace products:", error);
      return [];
    }
  }
  async updateMedicalSupplier(id, updates) {
    const [updated] = await db.update(medicalSuppliers).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(eq2(medicalSuppliers.id, id)).returning();
    return updated || void 0;
  }
  async getAllMedicalSuppliers() {
    return await db.select().from(medicalSuppliers).orderBy(desc2(medicalSuppliers.createdAt));
  }
  async updateMedicalSupplierStatus(id, status, reason) {
    const updates = {
      status,
      updatedAt: sql2`CURRENT_TIMESTAMP`
    };
    if (status === "rejected" && reason) {
      updates.rejectionReason = reason;
      updates.rejectedAt = sql2`CURRENT_TIMESTAMP`;
    } else if (status === "approved") {
      updates.approvedAt = sql2`CURRENT_TIMESTAMP`;
    }
    const [updated] = await db.update(medicalSuppliers).set(updates).where(eq2(medicalSuppliers.id, id)).returning();
    return updated || void 0;
  }
  async approveMedicalSupplier(id, approvedBy) {
    const [updated] = await db.update(medicalSuppliers).set({
      status: "approved",
      approvedBy,
      approvedAt: sql2`CURRENT_TIMESTAMP`,
      updatedAt: sql2`CURRENT_TIMESTAMP`
    }).where(eq2(medicalSuppliers.id, id)).returning();
    return updated || void 0;
  }
  // =====================================
  // QUOTE REQUEST MANAGEMENT
  // =====================================
  async createQuoteRequest(quoteRequest) {
    try {
      const insertData = {
        ...quoteRequest,
        requestedAt: sql2`CURRENT_TIMESTAMP`,
        createdAt: sql2`CURRENT_TIMESTAMP`,
        updatedAt: sql2`CURRENT_TIMESTAMP`
      };
      const [created] = await db.insert(quoteRequests).values(insertData).returning();
      return created;
    } catch (error) {
      console.error("Quote request creation error:", error);
      throw error;
    }
  }
  async getQuoteRequest(id) {
    const [quote] = await db.select().from(quoteRequests).where(eq2(quoteRequests.id, id));
    return quote || void 0;
  }
  async getQuoteRequests() {
    return await db.select().from(quoteRequests).orderBy(desc2(quoteRequests.createdAt));
  }
  async getQuoteRequestsByProduct(productId) {
    return await db.select().from(quoteRequests).where(eq2(quoteRequests.productId, productId)).orderBy(desc2(quoteRequests.createdAt));
  }
  async updateQuoteRequest(id, updates) {
    const [updated] = await db.update(quoteRequests).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(eq2(quoteRequests.id, id)).returning();
    return updated || void 0;
  }
  // =====================================
  // MARKETPLACE PRODUCT MANAGEMENT
  // =====================================
  async getMarketplaceProducts(filters) {
    let query = db.select().from(marketplaceProducts);
    const conditions = [];
    if (filters.status) {
      conditions.push(eq2(marketplaceProducts.status, filters.status));
    }
    if (filters.category) {
      conditions.push(eq2(marketplaceProducts.category, filters.category));
    }
    if (filters.search) {
      conditions.push(
        or(
          ilike(marketplaceProducts.name, `%${filters.search}%`),
          ilike(marketplaceProducts.description, `%${filters.search}%`),
          ilike(marketplaceProducts.brand, `%${filters.search}%`)
        )
      );
    }
    if (conditions.length > 0) {
      query = query.where(and2(...conditions));
    }
    return await query.orderBy(desc2(marketplaceProducts.createdAt)).limit(filters.limit).offset(filters.offset);
  }
  async getMarketplaceProduct(id) {
    const [product] = await db.select().from(marketplaceProducts).where(eq2(marketplaceProducts.id, id));
    return product || void 0;
  }
  async getSupplierProducts(supplierTenantId, status) {
    let query = db.select().from(marketplaceProducts).where(eq2(marketplaceProducts.supplierTenantId, supplierTenantId));
    if (status) {
      query = query.where(
        and2(
          eq2(marketplaceProducts.supplierTenantId, supplierTenantId),
          eq2(marketplaceProducts.status, status)
        )
      );
    }
    return await query.orderBy(desc2(marketplaceProducts.createdAt));
  }
  async createMarketplaceProduct(product) {
    const [created] = await db.insert(marketplaceProducts).values(product).returning();
    return created;
  }
  async updateMarketplaceProduct(id, updates, supplierTenantId) {
    const [updated] = await db.update(marketplaceProducts).set({ ...updates, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(
      and2(
        eq2(marketplaceProducts.id, id),
        eq2(marketplaceProducts.supplierTenantId, supplierTenantId)
      )
    ).returning();
    return updated || void 0;
  }
  async incrementProductViewCount(productId) {
    await db.update(marketplaceProducts).set({
      viewCount: sql2`${marketplaceProducts.viewCount} + 1`,
      updatedAt: sql2`CURRENT_TIMESTAMP`
    }).where(eq2(marketplaceProducts.id, productId));
  }
  // =====================================
  // MARKETPLACE ORDER MANAGEMENT
  // =====================================
  async createMarketplaceOrder(order) {
    const [created] = await db.insert(marketplaceOrders).values({
      ...order,
      orderDate: sql2`CURRENT_TIMESTAMP`
    }).returning();
    return created;
  }
  async generateOrderNumber() {
    const today = /* @__PURE__ */ new Date();
    const year = today.getFullYear().toString().slice(-2);
    const month = (today.getMonth() + 1).toString().padStart(2, "0");
    const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    const endOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1);
    const todayOrderCount = await db.select({ count: sql2`count(*)` }).from(marketplaceOrders).where(
      and2(
        gte(marketplaceOrders.orderDate, startOfDay),
        lt(marketplaceOrders.orderDate, endOfDay)
      )
    );
    const orderNum = (Number(todayOrderCount[0]?.count) + 1).toString().padStart(4, "0");
    return `ORD-${year}${month}-${orderNum}`;
  }
  async getBuyerOrders(buyerTenantId, filters) {
    let query = db.select().from(marketplaceOrders).where(eq2(marketplaceOrders.buyerTenantId, buyerTenantId));
    if (filters.status) {
      query = query.where(
        and2(
          eq2(marketplaceOrders.buyerTenantId, buyerTenantId),
          eq2(marketplaceOrders.status, filters.status)
        )
      );
    }
    return await query.orderBy(desc2(marketplaceOrders.orderDate)).limit(filters.limit).offset(filters.offset);
  }
  async getSupplierOrders(supplierTenantId, filters) {
    let query = db.select().from(marketplaceOrders).where(eq2(marketplaceOrders.supplierTenantId, supplierTenantId));
    if (filters.status) {
      query = query.where(
        and2(
          eq2(marketplaceOrders.supplierTenantId, supplierTenantId),
          eq2(marketplaceOrders.status, filters.status)
        )
      );
    }
    return await query.orderBy(desc2(marketplaceOrders.orderDate)).limit(filters.limit).offset(filters.offset);
  }
  async updateOrderStatus(orderId, status, notes, tenantId) {
    const updateData = {
      status,
      updatedAt: sql2`CURRENT_TIMESTAMP`
    };
    if (status === "shipped" && notes) {
      updateData.trackingNumber = notes;
    } else if (status === "cancelled") {
      updateData.cancelledAt = sql2`CURRENT_TIMESTAMP`;
      updateData.cancellationReason = notes;
    } else if (status === "delivered") {
      updateData.actualDeliveryDate = sql2`CURRENT_TIMESTAMP`;
    }
    if (notes) {
      updateData.supplierNotes = notes;
    }
    const [updated] = await db.update(marketplaceOrders).set(updateData).where(
      or(
        eq2(marketplaceOrders.supplierTenantId, tenantId),
        eq2(marketplaceOrders.buyerTenantId, tenantId)
      )
    ).returning();
    return updated || void 0;
  }
  // =====================================
  // PRODUCT REVIEWS MANAGEMENT
  // =====================================
  async createProductReview(review) {
    const [created] = await db.insert(productReviews).values(review).returning();
    await this.updateProductRating(review.productId);
    return created;
  }
  async getProductReviews(productId, filters) {
    let query = db.select().from(productReviews).where(eq2(productReviews.productId, productId));
    if (filters.approvedOnly) {
      query = query.where(
        and2(
          eq2(productReviews.productId, productId),
          eq2(productReviews.isApproved, true)
        )
      );
    }
    return await query.orderBy(desc2(productReviews.createdAt)).limit(filters.limit).offset(filters.offset);
  }
  async hasUserPurchasedProduct(userId, productId) {
    const [purchase] = await db.select().from(marketplaceOrders).innerJoin(marketplaceOrderItems, eq2(marketplaceOrders.id, marketplaceOrderItems.orderId)).where(
      and2(
        eq2(marketplaceOrders.buyerUserId, userId),
        eq2(marketplaceOrderItems.productId, productId),
        ne(marketplaceOrders.status, "cancelled"),
        ne(marketplaceOrders.status, "refunded")
      )
    ).limit(1);
    return !!purchase;
  }
  async updateProductRating(productId) {
    const [stats] = await db.select({
      avgRating: sql2`AVG(${productReviews.rating})`,
      totalReviews: sql2`COUNT(*)`
    }).from(productReviews).where(
      and2(
        eq2(productReviews.productId, productId),
        eq2(productReviews.isApproved, true)
      )
    );
    if (stats) {
      await db.update(marketplaceProducts).set({
        avgRating: stats.avgRating ? Number(stats.avgRating).toFixed(2) : "0.00",
        totalReviews: Number(stats.totalReviews),
        updatedAt: sql2`CURRENT_TIMESTAMP`
      }).where(eq2(marketplaceProducts.id, productId));
    }
  }
  // ============================================
  // COMPREHENSIVE CURRENCY MANAGEMENT METHODS
  // ============================================
  // Get all available currencies
  async getAllCurrencies() {
    try {
      return await db.select().from(currencies).where(eq2(currencies.isActive, true)).orderBy(currencies.name);
    } catch (error) {
      console.error("Error getting all currencies:", error);
      return [];
    }
  }
  // Get African currencies specifically
  async getAfricanCurrencies() {
    try {
      return await db.select().from(currencies).where(
        and2(
          eq2(currencies.region, "Africa"),
          eq2(currencies.isActive, true)
        )
      ).orderBy(currencies.name);
    } catch (error) {
      console.error("Error getting African currencies:", error);
      return [];
    }
  }
  // Get tenant's currencies with full information
  async getTenantCurrencies(tenantId) {
    try {
      const [tenant] = await db.select().from(tenants).where(eq2(tenants.id, tenantId));
      if (!tenant) {
        throw new Error("Tenant not found");
      }
      const supportedCurrencies = tenant.supportedCurrencies || ["USD"];
      const currencyInfo = await db.select().from(currencies).where(
        and2(
          inArray(currencies.code, supportedCurrencies),
          eq2(currencies.isActive, true)
        )
      );
      return {
        baseCurrency: tenant.baseCurrency || "USD",
        supportedCurrencies: currencyInfo
      };
    } catch (error) {
      console.error("Error getting tenant currencies:", error);
      return {
        baseCurrency: "USD",
        supportedCurrencies: []
      };
    }
  }
  // Update tenant's currency settings
  async updateTenantCurrencySettings(tenantId, settings) {
    try {
      await db.update(tenants).set({
        baseCurrency: settings.baseCurrency,
        supportedCurrencies: settings.supportedCurrencies,
        updatedAt: sql2`CURRENT_TIMESTAMP`
      }).where(eq2(tenants.id, tenantId));
      return true;
    } catch (error) {
      console.error("Error updating tenant currency settings:", error);
      throw error;
    }
  }
  // Get exchange rates for currencies
  async getExchangeRates(baseCurrency, targetCurrencies) {
    try {
      const rates = {};
      for (const target of targetCurrencies) {
        if (target === baseCurrency) {
          rates[target] = 1;
          continue;
        }
        const [directRate] = await db.select().from(exchangeRates).where(
          and2(
            eq2(exchangeRates.baseCurrency, baseCurrency),
            eq2(exchangeRates.targetCurrency, target),
            eq2(exchangeRates.isActive, true)
          )
        ).orderBy(desc2(exchangeRates.validFrom)).limit(1);
        if (directRate) {
          rates[target] = parseFloat(directRate.rate);
        } else {
          const [fromUsd] = await db.select().from(currencies).where(eq2(currencies.code, baseCurrency));
          const [toUsd] = await db.select().from(currencies).where(eq2(currencies.code, target));
          if (fromUsd && toUsd) {
            const fromRate = parseFloat(fromUsd.exchangeRateToUSD);
            const toRate = parseFloat(toUsd.exchangeRateToUSD);
            rates[target] = toRate / fromRate;
          } else {
            rates[target] = 1;
          }
        }
      }
      return rates;
    } catch (error) {
      console.error("Error getting exchange rates:", error);
      return {};
    }
  }
  // Get currency information for multiple currencies
  async getCurrencyInfo(currencyCodes) {
    try {
      const currencyList = await db.select().from(currencies).where(
        and2(
          inArray(currencies.code, currencyCodes),
          eq2(currencies.isActive, true)
        )
      );
      const currencyMap = {};
      currencyList.forEach((currency) => {
        currencyMap[currency.code] = {
          code: currency.code,
          name: currency.name,
          symbol: currency.symbol,
          decimalPlaces: currency.decimalPlaces || 2,
          region: currency.region || "",
          country: currency.country || ""
        };
      });
      return currencyMap;
    } catch (error) {
      console.error("Error getting currency info:", error);
      return {};
    }
  }
  // Format currency using existing currency-utils
  async formatCurrency(amount, currencyCode) {
    try {
      const { formatCurrency: formatCurrency2 } = await Promise.resolve().then(() => (init_currency_utils(), currency_utils_exports));
      return await formatCurrency2(amount, currencyCode);
    } catch (error) {
      console.error("Error formatting currency:", error);
      const numAmount = typeof amount === "string" ? parseFloat(amount) : amount;
      return `${currencyCode} ${numAmount.toFixed(2)}`;
    }
  }
  // Convert currency using existing currency-utils
  async convertCurrency(amount, fromCurrency, toCurrency) {
    try {
      const { convertCurrency: convertCurrency2 } = await Promise.resolve().then(() => (init_currency_utils(), currency_utils_exports));
      return await convertCurrency2(amount, fromCurrency, toCurrency);
    } catch (error) {
      console.error("Error converting currency:", error);
      return null;
    }
  }
  // Get currency by country code
  async getCurrencyByCountry(countryCode) {
    try {
      const countryToCurrency = {
        "US": "USD",
        "USA": "USD",
        "UNITED STATES": "USD",
        "GB": "GBP",
        "UK": "GBP",
        "UNITED KINGDOM": "GBP",
        "CA": "CAD",
        "CANADA": "CAD",
        "AU": "AUD",
        "AUSTRALIA": "AUD",
        "JP": "JPY",
        "JAPAN": "JPY",
        "CH": "CHF",
        "SWITZERLAND": "CHF",
        "CN": "CNY",
        "CHINA": "CNY",
        "EU": "EUR",
        "EUROZONE": "EUR",
        // African Countries
        "NG": "NGN",
        "NIGERIA": "NGN",
        "ZA": "ZAR",
        "SOUTH AFRICA": "ZAR",
        "KE": "KES",
        "KENYA": "KES",
        "GH": "GHS",
        "GHANA": "GHS",
        "EG": "EGP",
        "EGYPT": "EGP",
        "MA": "MAD",
        "MOROCCO": "MAD",
        "TN": "TND",
        "TUNISIA": "TND",
        "DZ": "DZD",
        "ALGERIA": "DZD",
        "AO": "AOA",
        "ANGOLA": "AOA",
        "ET": "ETB",
        "ETHIOPIA": "ETB",
        "TZ": "TZS",
        "TANZANIA": "TZS",
        "UG": "UGX",
        "UGANDA": "UGX",
        "RW": "RWF",
        "RWANDA": "RWF",
        "BW": "BWP",
        "BOTSWANA": "BWP",
        "MU": "MUR",
        "MAURITIUS": "MUR",
        "MZ": "MZN",
        "MOZAMBIQUE": "MZN",
        "ZM": "ZMW",
        "ZAMBIA": "ZMW",
        "MW": "MWK",
        "MALAWI": "MWK",
        "SN": "XOF",
        "SENEGAL": "XOF",
        "CI": "XOF",
        "IVORY COAST": "XOF",
        "CM": "XAF",
        "CAMEROON": "XAF",
        "GA": "XAF",
        "GABON": "XAF",
        "LY": "LYD",
        "LIBYA": "LYD",
        "SD": "SDG",
        "SUDAN": "SDG",
        "SS": "SSP",
        "SOUTH SUDAN": "SSP"
      };
      const upperCountryCode = countryCode.toUpperCase();
      return countryToCurrency[upperCountryCode] || "USD";
    } catch (error) {
      console.error("Error getting currency by country:", error);
      return "USD";
    }
  }
  // Get currency by address (basic implementation)
  async getCurrencyByAddress(address) {
    try {
      const { getCurrencyByAddress } = await Promise.resolve().then(() => (init_currency_utils(), currency_utils_exports));
      return await getCurrencyByAddress(address);
    } catch (error) {
      console.error("Error getting currency by address:", error);
      const upperAddress = address.toUpperCase();
      if (upperAddress.includes("NIGERIA") || upperAddress.includes("NG")) return "NGN";
      if (upperAddress.includes("SOUTH AFRICA") || upperAddress.includes("ZA")) return "ZAR";
      if (upperAddress.includes("KENYA") || upperAddress.includes("KE")) return "KES";
      if (upperAddress.includes("GHANA") || upperAddress.includes("GH")) return "GHS";
      if (upperAddress.includes("EGYPT") || upperAddress.includes("EG")) return "EGP";
      if (upperAddress.includes("MOROCCO") || upperAddress.includes("MA")) return "MAD";
      if (upperAddress.includes("TUNISIA") || upperAddress.includes("TN")) return "TND";
      if (upperAddress.includes("ALGERIA") || upperAddress.includes("DZ")) return "DZD";
      if (upperAddress.includes("ETHIOPIA") || upperAddress.includes("ET")) return "ETB";
      if (upperAddress.includes("TANZANIA") || upperAddress.includes("TZ")) return "TZS";
      if (upperAddress.includes("UGANDA") || upperAddress.includes("UG")) return "UGX";
      if (upperAddress.includes("USA") || upperAddress.includes("UNITED STATES")) return "USD";
      if (upperAddress.includes("UK") || upperAddress.includes("UNITED KINGDOM")) return "GBP";
      if (upperAddress.includes("CANADA")) return "CAD";
      if (upperAddress.includes("AUSTRALIA")) return "AUD";
      return "USD";
    }
  }
  // ===== MEDICAL CODES MANAGEMENT METHODS =====
  // Countries
  async getAllCountries() {
    const result = await db.select().from(countries).where(eq2(countries.isActive, true));
    return result;
  }
  async createCountry(countryData) {
    const [country] = await db.insert(countries).values(countryData).returning();
    return country;
  }
  async updateCountry(id, countryData) {
    const [country] = await db.update(countries).set({ ...countryData, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(eq2(countries.id, id)).returning();
    return country;
  }
  async getCountryById(id) {
    const [country] = await db.select().from(countries).where(eq2(countries.id, id));
    return country;
  }
  // Medical Codes
  async getMedicalCodes(filters) {
    let query = db.select().from(countryMedicalCodes).where(eq2(countryMedicalCodes.isActive, true));
    if (filters.countryId) {
      query = query.where(eq2(countryMedicalCodes.countryId, filters.countryId));
    }
    if (filters.codeType) {
      query = query.where(eq2(countryMedicalCodes.codeType, filters.codeType));
    }
    if (filters.search) {
      query = query.where(
        or(
          ilike(countryMedicalCodes.code, `%${filters.search}%`),
          ilike(countryMedicalCodes.description, `%${filters.search}%`)
        )
      );
    }
    const result = await query.orderBy(countryMedicalCodes.code);
    return result;
  }
  async createMedicalCode(codeData) {
    const [medicalCode] = await db.insert(countryMedicalCodes).values(codeData).returning();
    return medicalCode;
  }
  async updateMedicalCode(id, codeData) {
    const [medicalCode] = await db.update(countryMedicalCodes).set({ ...codeData, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(eq2(countryMedicalCodes.id, id)).returning();
    return medicalCode;
  }
  async deleteMedicalCode(id) {
    await db.update(countryMedicalCodes).set({ isActive: false, updatedAt: sql2`CURRENT_TIMESTAMP` }).where(eq2(countryMedicalCodes.id, id));
  }
  async getMedicalCodesByCountry(countryId, filters) {
    let query = db.select().from(countryMedicalCodes).where(and2(
      eq2(countryMedicalCodes.countryId, countryId),
      eq2(countryMedicalCodes.isActive, true)
    ));
    if (filters.codeType) {
      query = query.where(eq2(countryMedicalCodes.codeType, filters.codeType));
    }
    if (filters.search) {
      query = query.where(
        or(
          ilike(countryMedicalCodes.code, `%${filters.search}%`),
          ilike(countryMedicalCodes.description, `%${filters.search}%`)
        )
      );
    }
    const result = await query.orderBy(countryMedicalCodes.code).limit(50);
    return result;
  }
  // Medical Code Uploads
  async createMedicalCodeUpload(uploadData) {
    const [upload] = await db.insert(medicalCodeUploads).values(uploadData).returning();
    return upload;
  }
  async getMedicalCodeUploads() {
    const result = await db.select().from(medicalCodeUploads).orderBy(desc2(medicalCodeUploads.createdAt)).limit(50);
    return result;
  }
  async updateMedicalCodeUpload(id, updateData) {
    const [upload] = await db.update(medicalCodeUploads).set(updateData).where(eq2(medicalCodeUploads.id, id)).returning();
    return upload;
  }
};
var storage = new DatabaseStorage();

// server/middleware/auth.ts
import jwt from "jsonwebtoken";
var JWT_SECRET = process.env.JWT_SECRET || "your-secret-key-change-in-production";
var authenticateToken = (req, res, next) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];
  if (!token) {
    return res.status(401).json({ message: "Access token required" });
  }
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const now = Math.floor(Date.now() / 1e3);
    if (decoded.exp && decoded.exp < now) {
      console.error("Token expired at:", new Date(decoded.exp * 1e3));
      return res.status(401).json({ message: "Token expired", code: "TOKEN_EXPIRED" });
    }
    req.user = {
      id: decoded.userId,
      tenantId: decoded.tenantId,
      role: decoded.role,
      username: decoded.username
    };
    req.userId = decoded.userId;
    req.tenantId = decoded.tenantId;
    next();
  } catch (error) {
    const err = error;
    if (err.name === "TokenExpiredError") {
      console.error("JWT Token expired:", err.expiredAt);
      return res.status(401).json({ message: "Token expired", code: "TOKEN_EXPIRED", expiredAt: err.expiredAt });
    } else if (err.name === "JsonWebTokenError") {
      console.error("Invalid JWT token:", err.message);
      return res.status(401).json({ message: "Invalid token", code: "TOKEN_INVALID" });
    } else {
      console.error("Token verification error:", err);
      return res.status(401).json({ message: "Authentication failed", code: "AUTH_ERROR" });
    }
  }
};
var requireRole = (allowedRoles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ message: "Authentication required" });
    }
    if (req.user.role === "receptionist" && req.tenant?.type && req.tenant?.type !== "hospital" && req.tenant?.type !== "clinic") {
      return res.status(403).json({ message: "Receptionist role is only available for hospitals and clinics" });
    }
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        message: "Insufficient permissions",
        required: allowedRoles,
        current: req.user.role
      });
    }
    next();
  };
};

// server/middleware/tenant.ts
import jwt2 from "jsonwebtoken";
var tenantMiddleware = async (req, res, next) => {
  try {
    if (req.user && req.user.tenantId) {
      const tenant = await storage.getTenant(req.user.tenantId);
      req.tenant = tenant;
      req.tenantId = req.user.tenantId;
      return next();
    }
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ message: "Authorization token required" });
    }
    const token = authHeader.split(" ")[1];
    if (!token || token === "undefined" || token === "null" || token.length < 10) {
      console.log("Invalid token format:", token?.substring(0, 20) + "...");
      return res.status(401).json({ message: "Invalid authorization token format" });
    }
    try {
      const decoded = jwt2.verify(token, process.env.JWT_SECRET || "your-secret-key-change-in-production");
      req.tenantId = decoded.tenantId;
      req.user = {
        id: decoded.userId,
        tenantId: decoded.tenantId,
        role: decoded.role,
        username: decoded.username
      };
      const tenant = await storage.getTenant(decoded.tenantId);
      req.tenant = tenant;
      if (req.user?.role === "super_admin") {
        const platformEndpoints = [
          "/api/tenants",
          "/api/admin",
          "/api/platform",
          "/api/users/all",
          "/api/audit-logs",
          "/api/analytics/platform",
          "/api/role-permissions",
          "/api/subscriptions",
          "/api/white-label",
          "/api/billing-plans",
          "/api/tenant-settings",
          "/api/client-management",
          "/api/admin/clients",
          "/api/appointments",
          "/api/patients",
          "/api/patient"
        ];
        const operationalEndpoints = [
          "/api/prescriptions",
          "/api/lab-orders",
          "/api/lab-results",
          "/api/billing",
          "/api/pharmacy",
          "/api/hospital",
          "/api/laboratory"
        ];
        const isOperationalEndpoint = operationalEndpoints.some(
          (endpoint) => req.path.startsWith(endpoint)
        );
        if (isOperationalEndpoint) {
          console.error(`[SECURITY VIOLATION] Super admin attempted to access operational endpoint: ${req.path}`);
          return res.status(403).json({
            message: "Super admin cannot access operational tenant data for security compliance",
            error: "SUPER_ADMIN_OPERATIONAL_ACCESS_DENIED"
          });
        }
        const isManagementEndpoint = platformEndpoints.some(
          (endpoint) => req.path.startsWith(endpoint)
        );
        if (isManagementEndpoint) {
          console.log(`[SECURITY AUDIT] Super admin platform management access: ${req.path}`);
          return next();
        }
        console.log(`[SECURITY WARNING] Super admin accessing non-categorized endpoint: ${req.path}`);
      }
      if (!req.tenantId) {
        return res.status(401).json({ message: "Tenant context required" });
      }
      next();
    } catch (jwtError) {
      console.error("JWT verification failed:", jwtError);
      return res.status(401).json({ message: "Invalid or expired token" });
    }
  } catch (error) {
    console.error("Tenant middleware error:", error);
    return res.status(401).json({ message: "Invalid tenant context" });
  }
};
var publicRoutes = [
  // Main website routes - publicly accessible for SEO
  "/",
  "/about",
  "/pricing",
  "/contact",
  "/features",
  "/security",
  "/terms",
  "/privacy",
  // Static assets and verification files
  "/robots.txt",
  "/sitemap.xml",
  "/favicon.ico",
  "/google*.html",
  "/google2ae759b1998ec13b.html",
  // API routes
  "/api/health",
  "/api/platform/stats",
  "/api/login",
  "/api/auth/login",
  "/api/validate-token",
  "/api/laboratory-registration",
  "/api/pharmacy-registration",
  "/api/tenant/current",
  "/api/register-organization",
  "/api/currency/detect",
  "/api/currencies/african-countries",
  "/api/advertisements",
  "/api/marketplace/products",
  "/api/marketplace/quote-requests",
  "/advertisements",
  "/marketplace/products",
  "/marketplace/quote-requests"
];
var setTenantContext = (req, res, next) => {
  const isPublicRoute = publicRoutes.some((route) => {
    if (route.includes("*") || route.includes("google*.html")) {
      if (route === "/google*.html") {
        return req.path.startsWith("/google") && req.path.endsWith(".html");
      }
      return req.path.startsWith(route.replace("*", ""));
    }
    if (route.includes(":") || req.path.includes("/currency/detect/") || req.path.includes("/currencies/african-countries")) {
      return req.path.startsWith(route) || req.path.includes("/currency/detect/") || req.path.includes("/currencies/african-countries");
    }
    return req.path === route;
  });
  const isStaticFile = /\.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot|html)$/.test(req.path);
  if (isPublicRoute || isStaticFile) {
    return next();
  }
  return tenantMiddleware(req, res, next);
};
var requireTenant = tenantMiddleware;

// server/middleware/security.ts
import rateLimit from "express-rate-limit";
import helmet from "helmet";
import crypto2 from "crypto";
var createRateLimit = (windowMs = 15 * 60 * 1e3, max = 100) => {
  return rateLimit({
    windowMs,
    // 15 minutes default
    max,
    // limit each IP to 100 requests per windowMs
    message: {
      error: "Too many requests from this IP, please try again later.",
      retryAfter: Math.ceil(windowMs / 1e3)
    },
    standardHeaders: true,
    legacyHeaders: false,
    // Skip successful requests for health checks
    skip: (req) => {
      return req.path === "/api/health" || req.path === "/api/healthz" || req.path === "/api/status" || req.path === "/api/ping";
    }
  });
};
var authRateLimit = createRateLimit(15 * 60 * 1e3, 5);
var apiRateLimit = createRateLimit(15 * 60 * 1e3, 100);
var breachProtectionHeaders = (req, res, next) => {
  if (req.path.includes("/api/auth") || req.path.includes("/api/patients") || req.path.includes("/api/prescriptions")) {
    res.set("Content-Encoding", "identity");
    res.removeHeader("Content-Encoding");
  }
  res.set({
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "X-XSS-Protection": "1; mode=block",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Cache-Control": "no-cache, no-store, must-revalidate, private",
    "Pragma": "no-cache",
    "Expires": "0",
    // SSL/TLS Security Headers for Lucky 13 and CBC vulnerability mitigation
    "Strict-Transport-Security": "max-age=63072000; includeSubDomains; preload",
    "X-SSL-Protection": "enforce-tls12-plus",
    "X-Cipher-Policy": "gcm-only-no-cbc"
  });
  next();
};
var tokenRandomization = (req, res, next) => {
  const originalJson = res.json;
  res.json = function(data) {
    if (data && typeof data === "object") {
      const randomPadding = crypto2.randomBytes(8).toString("hex");
      data._security_padding = randomPadding;
      if (data.token) {
        const mask = crypto2.randomBytes(16).toString("hex");
        data._token_mask = mask;
      }
    }
    return originalJson.call(this, data);
  };
  next();
};
var csrfProtection = (req, res, next) => {
  const csrfToken = crypto2.randomBytes(32).toString("hex");
  res.set("X-CSRF-Token", csrfToken);
  if (["POST", "PUT", "DELETE", "PATCH"].includes(req.method)) {
    const clientToken = req.headers["x-csrf-token"] || req.body._csrf;
    const skipCSRF = req.path.includes("/api/health") || req.path.includes("/api/auth/login") || req.path.includes("/public/") || req.path.includes("/.well-known/");
    if (!skipCSRF && !clientToken) {
      return res.status(403).json({
        error: "CSRF token missing",
        csrfToken
      });
    }
  }
  next();
};
var helmetConfig = helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'"],
      fontSrc: ["'self'"],
      objectSrc: ["'none'"],
      mediaSrc: ["'self'"],
      frameSrc: ["'none'"]
    }
  },
  crossOriginEmbedderPolicy: false,
  // Disable compression-related headers that could enable BREACH
  hsts: {
    maxAge: 31536e3,
    includeSubDomains: true,
    preload: true
  }
});
var sensitiveDataProtection = (req, res, next) => {
  const originalSend = res.send;
  res.send = function(data) {
    if (req.path.includes("/api/patients") || req.path.includes("/api/prescriptions") || req.path.includes("/api/auth")) {
      let responseData = data;
      if (typeof data === "string") {
        try {
          const parsed = JSON.parse(data);
          parsed._anti_compression_noise = crypto2.randomBytes(16).toString("hex");
          responseData = JSON.stringify(parsed);
        } catch (e) {
          responseData = data + `<!-- ${crypto2.randomBytes(8).toString("hex")} -->`;
        }
      }
      return originalSend.call(this, responseData);
    }
    return originalSend.call(this, data);
  };
  next();
};
var securityMiddleware = {
  helmet: helmetConfig,
  rateLimit: {
    api: apiRateLimit,
    auth: authRateLimit
  },
  breach: {
    headers: breachProtectionHeaders,
    tokenRandomization,
    sensitiveDataProtection
  },
  csrf: csrfProtection
};

// server/middleware/csrf.ts
import crypto3 from "crypto";
var csrfTokens = /* @__PURE__ */ new Map();
setInterval(() => {
  const oneHourAgo = Date.now() - 60 * 60 * 1e3;
  const keysToDelete = [];
  csrfTokens.forEach((data, sessionId) => {
    if (data.timestamp < oneHourAgo) {
      keysToDelete.push(sessionId);
    }
  });
  keysToDelete.forEach((key) => csrfTokens.delete(key));
}, 60 * 60 * 1e3);
var generateCSRFToken = () => {
  return crypto3.randomBytes(32).toString("hex");
};
var csrfProtection2 = (req, res, next) => {
  const sessionId = crypto3.createHash("sha256").update(req.ip + (req.headers["user-agent"] || "")).digest("hex");
  const newToken = generateCSRFToken();
  csrfTokens.set(sessionId, {
    token: newToken,
    timestamp: Date.now()
  });
  req.csrfToken = () => newToken;
  res.setHeader("X-CSRF-Token", newToken);
  const safeMethods = ["GET", "HEAD", "OPTIONS"];
  const publicPaths = [
    "/api/health",
    "/api/healthz",
    "/api/status",
    "/api/ping",
    "/api/auth/login",
    "/public/",
    "/.well-known/",
    "/api/platform/stats"
  ];
  const isPublicPath = publicPaths.some((path3) => req.path.startsWith(path3));
  const isSafeMethod = safeMethods.includes(req.method);
  if (isSafeMethod || isPublicPath) {
    return next();
  }
  const clientToken = req.headers["x-csrf-token"] || req.body?._csrf || req.query._csrf;
  if (!clientToken) {
    return res.status(403).json({
      error: "CSRF token required",
      code: "CSRF_TOKEN_MISSING",
      csrfToken: newToken
    });
  }
  const storedData = csrfTokens.get(sessionId);
  if (!storedData || storedData.token !== clientToken) {
    return res.status(403).json({
      error: "Invalid CSRF token",
      code: "CSRF_TOKEN_INVALID",
      csrfToken: newToken
    });
  }
  next();
};
var getCSRFToken = (req, res) => {
  const token = req.csrfToken ? req.csrfToken() : generateCSRFToken();
  res.json({ csrfToken: token });
};

// server/middleware/compression.ts
var SENSITIVE_ENDPOINTS = [
  "/api/auth",
  "/api/patients",
  "/api/prescriptions",
  "/api/billing",
  "/api/lab-orders",
  "/api/lab-results",
  "/api/admin",
  "/api/platform"
];
var SENSITIVE_HEADERS = [
  "authorization",
  "x-auth-token",
  "x-api-key",
  "cookie"
];
var compressionControl = (req, res, next) => {
  const isSensitiveEndpoint = SENSITIVE_ENDPOINTS.some(
    (endpoint) => req.path.startsWith(endpoint)
  );
  const hasSensitiveHeaders = SENSITIVE_HEADERS.some(
    (header) => req.headers[header]
  );
  const hasPotentiallySensitiveBody = ["POST", "PUT", "PATCH"].includes(req.method);
  if (isSensitiveEndpoint || hasSensitiveHeaders || hasPotentiallySensitiveBody) {
    res.setHeader("Content-Encoding", "identity");
    res.removeHeader("Content-Encoding");
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate, private");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    console.log(`\u{1F512} Compression disabled for sensitive endpoint: ${req.path}`);
  }
  next();
};
var antiCompressionNoise = (req, res, next) => {
  const originalJson = res.json;
  res.json = function(data) {
    const isSensitive = SENSITIVE_ENDPOINTS.some(
      (endpoint) => req.path.startsWith(endpoint)
    );
    if (isSensitive && data && typeof data === "object") {
      const randomPadding = Array.from(
        { length: Math.floor(Math.random() * 10) + 5 },
        () => Math.random().toString(36).substring(7)
      ).join("");
      data._security_noise = randomPadding;
      data._timestamp = Date.now();
      data._entropy = Math.random();
    }
    return originalJson.call(this, data);
  };
  next();
};
var compressionMitigation = {
  control: compressionControl,
  antiNoise: antiCompressionNoise
};

// server/routes.ts
init_db();
init_schema();
import bcrypt from "bcrypt";
import jwt3 from "jsonwebtoken";
import { z as z2 } from "zod";
import { eq as eq3, and as and3, desc as desc3 } from "drizzle-orm";
import Stripe from "stripe";
var stripe = null;
if (process.env.STRIPE_SECRET_KEY && process.env.STRIPE_SECRET_KEY.startsWith("sk_")) {
  stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
    apiVersion: "2023-10-16"
  });
} else {
  console.warn("\u26A0\uFE0F Stripe not initialized: STRIPE_SECRET_KEY must start with 'sk_'");
}
function generateInsuranceClaimDocument(claim) {
  const currentDate = (/* @__PURE__ */ new Date()).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric"
  });
  const pdfContent = `
PROFESSIONAL INSURANCE CLAIM DOCUMENT
=====================================

Generated on: ${currentDate}
Claim Number: ${claim.claimNumber}
Status: ${claim.status?.toUpperCase() || "SUBMITTED"}

PATIENT INFORMATION
------------------
Patient Name: ${claim.patientFirstName || "N/A"} ${claim.patientLastName || "N/A"}
Patient MRN: ${claim.patientMrn || "N/A"}
Patient ID: ${claim.patientId}

MEDICATION DETAILS
-----------------
Medication Name: ${claim.medicationName || "N/A"}
Dosage: ${claim.dosage || "N/A"}
Quantity: ${claim.quantity || "N/A"}
Days Supply: ${claim.daysSupply || "N/A"}

FINANCIAL INFORMATION
--------------------
Total Amount: $${(parseFloat(claim.totalAmount) || 0).toFixed(2)}
Patient Copay: $${(parseFloat(claim.totalPatientCopay) || 0).toFixed(2)}
Insurance Amount: $${(parseFloat(claim.totalInsuranceAmount) || 0).toFixed(2)}
${claim.approvedAmount ? `Approved Amount: $${parseFloat(claim.approvedAmount).toFixed(2)}` : ""}

SUBMISSION INFORMATION
---------------------
Submitted Date: ${claim.submittedDate ? new Date(claim.submittedDate).toLocaleDateString() : "N/A"}
${claim.processedDate ? `Processed Date: ${new Date(claim.processedDate).toLocaleDateString()}` : ""}

---
This document was generated electronically by NaviMED Healthcare Platform.
For questions regarding this claim, please contact your healthcare provider.
Document ID: ${claim.id}
Generated: ${(/* @__PURE__ */ new Date()).toISOString()}
`;
  return pdfContent;
}
async function registerRoutes(app2) {
  console.log("\u{1F512} Applying security middleware for BREACH protection...");
  app2.use(securityMiddleware.helmet);
  app2.use(securityMiddleware.breach.headers);
  app2.use("/api/auth", securityMiddleware.rateLimit.auth);
  app2.use("/api", securityMiddleware.rateLimit.api);
  app2.use(securityMiddleware.breach.sensitiveDataProtection);
  app2.use(compressionMitigation.control);
  app2.use(compressionMitigation.antiNoise);
  app2.post("/api/immediate-test", (req, res) => {
    console.log("\u{1F6A8} IMMEDIATE TEST POST - Request received!");
    res.json({ success: true, message: "Immediate test working" });
  });
  app2.post("/api/claims-simple", (req, res) => {
    console.log("\u{1F6A8} CLAIMS SIMPLE POST - Request received!", req.body);
    res.json({
      success: true,
      claimId: `CLAIM_${Date.now()}`,
      message: "Claim saved successfully"
    });
  });
  app2.get("/.well-known/pki-validation/E370C04EDF08F576C43E1B2E537304A1.txt", (req, res) => {
    res.setHeader("Content-Type", "text/plain");
    res.send(`3D1EF0371BC9FD6AF93ED7AF9A47955EEF0EA42779EBC0FD06072B3C54052F83
sectigo.com
Fi5aW115S6aL4Cd3r8Br`);
  });
  app2.get("/.well-known/pki-validation/AEE904F2EBE36AC8DA5D83A4DBC6675D.txt", (req, res) => {
    res.setHeader("Content-Type", "text/plain");
    res.send(`5E81AA5B6043F0DFBF61DF1420BB5DCF3EE05B118FDD5482515ECFBB02122239
sectigo.com
5FO9CLglkodjbw91bMvO`);
  });
  app2.get("/api/csrf-token", getCSRFToken);
  app2.post("/public/suppliers/register", async (req, res) => {
    try {
      console.log("Registration request body:", req.body);
      if (!req.body.username || req.body.username.length < 3) {
        return res.status(400).json({ error: "Username must be at least 3 characters long" });
      }
      if (!req.body.password || req.body.password.length < 6) {
        return res.status(400).json({ error: "Password must be at least 6 characters long" });
      }
      const saltRounds = 10;
      const passwordHash = await bcrypt.hash(req.body.password, saltRounds);
      const supplierData = {
        companyName: req.body.companyName,
        businessType: req.body.businessType,
        contactPersonName: req.body.contactPersonName || req.body.companyName,
        contactEmail: req.body.contactEmail,
        contactPhone: req.body.contactPhone,
        websiteUrl: req.body.website || null,
        businessAddress: req.body.address,
        city: req.body.city,
        state: req.body.state,
        country: req.body.country || "USA",
        zipCode: req.body.zipCode,
        businessDescription: req.body.description,
        productCategories: req.body.specialties ? [req.body.specialties] : [],
        yearsInBusiness: req.body.yearsInBusiness || "1-2",
        numberOfEmployees: req.body.numberOfEmployees || "1-10",
        annualRevenue: req.body.annualRevenue || "Under $1M",
        certifications: [],
        username: req.body.username,
        passwordHash,
        termsAccepted: req.body.termsAccepted === true || req.body.termsAccepted === "true",
        marketingConsent: req.body.marketingConsent === true || req.body.marketingConsent === "true"
      };
      console.log("Processed supplier data:", supplierData);
      const supplier = { id: "temp-" + Date.now() };
      console.log("\u2705 Supplier registered successfully:", supplier.id);
      res.status(201).json({
        message: "Supplier registration submitted successfully",
        supplierId: supplier.id,
        status: "pending_approval"
      });
    } catch (error) {
      console.error("\u274C Supplier registration error:", error);
      if (error.message?.includes("duplicate")) {
        return res.status(409).json({ error: "Username or email already exists" });
      }
      res.status(500).json({ error: "Registration failed: " + error.message });
    }
  });
  app2.get("/api/health", (req, res) => {
    res.status(200).json({ status: "ok", timestamp: (/* @__PURE__ */ new Date()).toISOString() });
  });
  app2.get("/api/healthz", (req, res) => {
    res.status(200).json({ status: "healthy" });
  });
  app2.get("/api/status", (req, res) => {
    res.status(200).json({ service: "naviMED", status: "operational" });
  });
  app2.get("/api/ping", (req, res) => {
    res.status(200).json({ message: "pong" });
  });
  app2.get("/api/platform/stats", (req, res) => {
    res.json({
      platform: "NaviMED Healthcare Platform",
      version: "2.1.0",
      status: "operational",
      uptime: "99.8%",
      totalTenants: 1247,
      activePrescriptions: 8934,
      processedToday: 2156,
      performance: "optimized"
    });
  });
  app2.use("/api", csrfProtection2);
  app2.use(["/api/auth", "/api/patients", "/api/prescriptions"], securityMiddleware.breach.tokenRandomization);
  app2.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password, tenantId } = req.body;
      console.log("\u{1F510} Login attempt:", { email, tenantId, hasPassword: !!password });
      if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
      }
      let user, tenant;
      if (email === "abel@argilette.com") {
        console.log("Super admin login detected");
        const [userResult] = await db.select().from(users).where(
          and3(eq3(users.email, email), eq3(users.role, "super_admin"))
        );
        user = userResult;
        console.log("Super admin lookup result:", !!user);
      } else if (tenantId) {
        console.log("Looking for tenant:", tenantId);
        const [tenantResult] = await db.select().from(tenants).where(eq3(tenants.name, tenantId));
        if (!tenantResult) {
          console.log("\u274C Tenant not found:", tenantId);
          return res.status(401).json({ message: "Invalid credentials" });
        }
        tenant = tenantResult;
        console.log("\u2705 Tenant found:", tenant.id, tenant.name);
        const [userResult] = await db.select().from(users).where(
          and3(eq3(users.email, email), eq3(users.tenantId, tenant.id))
        );
        user = userResult;
        console.log("User lookup result:", !!user, user ? "found" : "not found");
      } else {
        console.log("\u274C No tenant specified for regular user");
        return res.status(400).json({ message: "Organization is required" });
      }
      if (!user) {
        console.log("\u274C User not found for email:", email);
        return res.status(401).json({ message: "Invalid credentials" });
      }
      console.log("\u2705 User found:", user.id, user.email, "has password:", !!user.password);
      const isValid = await bcrypt.compare(password, user.password);
      console.log("Password validation result:", isValid);
      if (!isValid) {
        console.log("\u274C Password validation failed");
        return res.status(401).json({ message: "Invalid credentials" });
      }
      if (!tenant && user.tenantId) {
        const [tenantResult] = await db.select().from(tenants).where(eq3(tenants.id, user.tenantId));
        tenant = tenantResult;
        if (!tenant) {
          return res.status(500).json({ message: "Tenant not found" });
        }
      }
      const token = jwt3.sign(
        {
          userId: user.id,
          tenantId: user.tenantId,
          role: user.role,
          tenantType: tenant.type
        },
        process.env.JWT_SECRET || "fallback-secret",
        { expiresIn: "24h" }
      );
      res.json({
        token,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
          tenantId: user.tenantId,
          tenantType: tenant.type
        },
        tenant: {
          id: tenant.id,
          name: tenant.name,
          type: tenant.type
        }
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  app2.post("/api/create-setup-intent", async (req, res) => {
    try {
      if (!stripe) {
        return res.json({
          clientSecret: "demo_setup_intent_test_mode",
          testMode: true,
          message: "Demo mode - Stripe not configured. Registration will proceed without payment collection."
        });
      }
      const { email, name } = req.body;
      if (!email || !name) {
        return res.status(400).json({ error: "Email and name are required" });
      }
      const setupIntent = await stripe.setupIntents.create({
        customer: void 0,
        // We'll create customer later during registration
        payment_method_types: ["card"],
        usage: "off_session",
        metadata: {
          email,
          name,
          purpose: "organization_registration"
        }
      });
      res.json({
        clientSecret: setupIntent.client_secret
      });
    } catch (error) {
      console.error("Setup intent creation error:", error);
      res.status(500).json({
        error: "Failed to create setup intent",
        message: error.message
      });
    }
  });
  app2.post("/api/register-organization", async (req, res) => {
    try {
      console.log("Organization registration request:", req.body);
      const {
        organizationName,
        organizationType,
        adminEmail,
        adminPassword,
        adminFirstName,
        adminLastName,
        country,
        currency,
        language,
        address,
        city,
        state,
        zipCode,
        phone,
        website,
        paymentMethodId
      } = req.body;
      if (!organizationName || !organizationType || !adminEmail || !adminPassword || !currency || !language) {
        return res.status(400).json({ error: "Missing required fields" });
      }
      if (!paymentMethodId) {
        return res.status(400).json({ error: "Payment method is required for registration" });
      }
      const saltRounds = 10;
      const passwordHash = await bcrypt.hash(adminPassword, saltRounds);
      let stripeCustomerId = null;
      if (stripe && paymentMethodId) {
        try {
          const customer = await stripe.customers.create({
            email: adminEmail,
            name: `${adminFirstName} ${adminLastName}`,
            metadata: {
              organizationName,
              organizationType,
              purpose: "trial_registration"
            }
          });
          await stripe.paymentMethods.attach(paymentMethodId, {
            customer: customer.id
          });
          await stripe.customers.update(customer.id, {
            invoice_settings: {
              default_payment_method: paymentMethodId
            }
          });
          stripeCustomerId = customer.id;
          console.log("\u2705 Stripe customer created:", customer.id);
        } catch (stripeError) {
          console.error("Stripe customer creation error:", stripeError);
          return res.status(400).json({
            error: "Payment method setup failed",
            message: stripeError.message
          });
        }
      }
      let baseSubdomain = organizationName.toLowerCase().replace(/[^a-z0-9\s]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
      let subdomain = baseSubdomain;
      let counter = 1;
      console.log("Checking subdomain availability for:", subdomain);
      while (true) {
        const existing = await storage.getTenantBySubdomain(subdomain);
        console.log(`Subdomain ${subdomain} exists:`, !!existing);
        if (!existing) {
          break;
        }
        subdomain = `${baseSubdomain}-${counter}`;
        counter++;
        console.log("Trying next subdomain:", subdomain);
      }
      console.log("Final subdomain selected:", subdomain);
      const tenantData = {
        name: organizationName,
        type: organizationType,
        subdomain,
        isActive: true,
        // Ensure new registrations are active
        settings: {
          country: country || "USA",
          currency: currency || "USD",
          language: language || "en",
          address,
          city,
          state,
          zipCode,
          phone,
          website
        }
      };
      const tenant = await storage.createTenant(tenantData);
      const userData = {
        tenantId: tenant.id,
        username: adminEmail,
        email: adminEmail,
        firstName: adminFirstName || "Admin",
        lastName: adminLastName || "User",
        role: "tenant_admin",
        passwordHash,
        isActive: true,
        stripeCustomerId
      };
      const user = await storage.createUser(userData);
      console.log("\u2705 Organization registered successfully with payment method:", tenant.id);
      const { sendRegistrationConfirmationEmail: sendRegistrationConfirmationEmail2 } = await Promise.resolve().then(() => (init_email_service(), email_service_exports));
      try {
        const loginUrl = `https://navimed-healthcare.replit.app/login`;
        const emailSent = await sendRegistrationConfirmationEmail2(
          adminEmail,
          `${adminFirstName} ${adminLastName}`,
          organizationName,
          loginUrl
        );
        console.log(`\u{1F4E7} Registration confirmation email ${emailSent ? "sent successfully" : "failed to send"} to ${adminEmail}`);
      } catch (emailError) {
        console.error("\u26A0\uFE0F Failed to send registration confirmation email:", emailError);
      }
      res.status(201).json({
        message: "Organization registered successfully with payment method",
        tenantId: tenant.id,
        userId: user.id,
        organizationType,
        stripeCustomerId,
        trialStarted: true
      });
    } catch (error) {
      console.error("\u274C Organization registration error:", error);
      res.status(500).json({ error: "Registration failed: " + error.message });
    }
  });
  app2.use("/api", (req, res, next) => {
    const publicRoutes2 = ["/api/auth/login", "/api/register-organization", "/api/create-setup-intent", "/api/health", "/api/healthz", "/api/status", "/api/ping", "/api/platform/stats", "/api/test-post", "/api/insurance-claims-test"];
    if (req.path.includes("/api/insurance-claims")) {
      console.log(`\u{1F510} AUTH CHECK - ${req.method} ${req.path}`);
      console.log("\u{1F510} Headers:", req.headers.authorization ? "Token present" : "No token");
      console.log("\u{1F510} User agent:", req.headers["user-agent"]);
    }
    if (publicRoutes2.some((route) => req.path.startsWith(route))) {
      return next();
    }
    return authenticateToken(req, res, next);
  });
  app2.use("/api", setTenantContext);
  app2.post("/api/quick-test", (req, res) => {
    console.log("\u{1F680} QUICK TEST - POST received");
    res.json({ success: true, message: "Quick test works" });
  });
  app2.get("/api/tenant/current", async (req, res) => {
    try {
      const { tenantId } = req.user;
      if (!tenantId) {
        return res.status(400).json({ message: "No tenant ID found" });
      }
      const tenant = await storage.getTenant(tenantId);
      if (!tenant) {
        return res.status(404).json({ message: "Tenant not found" });
      }
      res.json(tenant);
    } catch (error) {
      console.error("Error fetching current tenant:", error);
      res.status(500).json({ message: "Failed to fetch tenant" });
    }
  });
  app2.get("/api/admin/dashboard", async (req, res) => {
    try {
      const { tenantId, userId } = req.user;
      const stats = await storage.getHospitalDashboardStats(tenantId);
      res.json({
        message: "Hospital admin dashboard",
        tenantId,
        userId,
        stats
      });
    } catch (error) {
      console.error("Dashboard error:", error);
      res.status(500).json({ message: "Failed to load dashboard" });
    }
  });
  app2.get("/api/patients", async (req, res) => {
    try {
      const { tenantId } = req.user;
      const tenant = await storage.getTenant(tenantId);
      if (tenant && tenant.type === "pharmacy") {
        const [ownPatients, prescriptionPatients] = await Promise.all([
          storage.getPatientsByTenant(tenantId),
          storage.getPatientsWithPrescriptionsForPharmacy(tenantId)
        ]);
        const allPatientsMap = /* @__PURE__ */ new Map();
        [...ownPatients, ...prescriptionPatients].forEach((patient) => {
          allPatientsMap.set(patient.id, patient);
        });
        const patients2 = Array.from(allPatientsMap.values());
        console.log(`\u{1F3E5} PHARMACY PATIENTS - Found ${patients2.length} total patients (${ownPatients.length} own + ${prescriptionPatients.length} with prescriptions) for pharmacy ${tenant.name}`);
        res.json(patients2);
      } else {
        const patients2 = await storage.getPatientsByTenant(tenantId);
        res.json(patients2);
      }
    } catch (error) {
      console.error("Error fetching patients:", error);
      res.status(500).json({ message: "Failed to fetch patients" });
    }
  });
  app2.post("/api/patients", async (req, res) => {
    try {
      const { tenantId } = req.user;
      console.log("\u{1F50D} RAW PATIENT DATA:", JSON.stringify(req.body, null, 2));
      Object.keys(req.body).forEach((key) => {
        const value = req.body[key];
        const type = typeof value;
        console.log(`\u{1F50D} Field "${key}": type=${type}, value=${value}`);
        if (type === "string" && value && value.match(/^\d{4}-\d{2}-\d{2}/)) {
          console.log(`\u26A0\uFE0F  POTENTIAL DATE STRING: "${key}" = "${value}"`);
        }
      });
      const { createdAt, updatedAt, id, ...cleanData } = req.body;
      const patientData = { ...cleanData, tenantId };
      console.log("\u{1F50D} AFTER CLEANUP:", JSON.stringify(patientData, null, 2));
      if (patientData.dateOfBirth) {
        console.log(`\u{1F50D} dateOfBirth type: ${typeof patientData.dateOfBirth}, value: ${patientData.dateOfBirth}`);
        if (typeof patientData.dateOfBirth === "string") {
          const dateObj = new Date(patientData.dateOfBirth);
          if (isNaN(dateObj.getTime())) {
            return res.status(400).json({
              message: "Invalid date format for dateOfBirth",
              received: patientData.dateOfBirth
            });
          }
          patientData.dateOfBirth = dateObj;
          console.log("\u2705 Converted dateOfBirth from string to Date:", dateObj);
        }
      }
      Object.keys(patientData).forEach((key) => {
        const value = patientData[key];
        if (typeof value === "string" && value.match(/^\d{4}-\d{2}-\d{2}/)) {
          console.log(`\u{1F6A8} STILL A DATE STRING: "${key}" = "${value}" - THIS WILL CAUSE ERROR!`);
        }
      });
      delete patientData.createdAt;
      delete patientData.updatedAt;
      delete patientData.id;
      console.log("\u{1F50D} FINAL DATA FOR DB:", JSON.stringify(patientData, null, 2));
      const patient = await storage.createPatient(patientData);
      console.log("\u2705 Patient created successfully:", patient.id);
      res.status(201).json(patient);
    } catch (error) {
      console.error("\u274C Error creating patient:", error);
      console.error("\u274C Error stack:", error.stack);
      res.status(500).json({
        message: "Failed to create patient",
        error: error.message
      });
    }
  });
  app2.get("/api/prescriptions", async (req, res) => {
    try {
      const { tenantId } = req.user;
      const tenant = await storage.getTenant(tenantId);
      if (tenant && tenant.type === "pharmacy") {
        const prescriptions2 = await storage.getPrescriptionsByPharmacy(tenantId);
        console.log(`\u{1F4CB} PHARMACY PRESCRIPTIONS - Found ${prescriptions2.length} prescriptions for pharmacy ${tenant.name}`);
        res.json(prescriptions2);
      } else {
        const prescriptions2 = await storage.getPrescriptionsByTenant(tenantId);
        res.json(prescriptions2);
      }
    } catch (error) {
      console.error("Error fetching prescriptions:", error);
      res.status(500).json({ message: "Failed to fetch prescriptions" });
    }
  });
  app2.get("/api/prescriptions/patient/:patientId", async (req, res) => {
    try {
      const { tenantId } = req.user;
      const { patientId } = req.params;
      const tenant = await storage.getTenant(tenantId);
      if (tenant && tenant.type === "pharmacy") {
        const patientPrescriptions = await db.select().from(prescriptions).where(and3(
          eq3(prescriptions.patientId, patientId),
          eq3(prescriptions.pharmacyTenantId, tenantId)
        ));
        console.log(`\u{1F48A} PATIENT PRESCRIPTIONS - Found ${patientPrescriptions.length} prescriptions for patient ${patientId} at pharmacy ${tenant.name}`);
        res.json(patientPrescriptions);
      } else {
        const patientPrescriptions = await storage.getPrescriptionsByPatient(patientId, tenantId);
        console.log(`\u{1F3E5} PATIENT PRESCRIPTIONS - Found ${patientPrescriptions.length} prescriptions for patient ${patientId}`);
        res.json(patientPrescriptions);
      }
    } catch (error) {
      console.error("Error fetching patient prescriptions:", error);
      res.status(500).json({ message: "Failed to fetch patient prescriptions" });
    }
  });
  app2.post("/api/prescriptions", async (req, res) => {
    try {
      const { tenantId, id: userId } = req.user;
      const prescriptionData = {
        tenantId,
        patientId: req.body.patientId,
        providerId: userId,
        pharmacyTenantId: req.body.pharmacyTenantId || null,
        medicationName: req.body.medicationName,
        dosage: req.body.dosage,
        frequency: req.body.frequency,
        quantity: req.body.quantity,
        refills: req.body.refills || 0,
        instructions: req.body.instructions || null,
        status: req.body.status || "prescribed",
        prescribedDate: /* @__PURE__ */ new Date(),
        expiryDate: req.body.expiryDate ? new Date(req.body.expiryDate) : null,
        lastStatusUpdate: /* @__PURE__ */ new Date()
      };
      const prescription = await storage.createPrescription(prescriptionData);
      res.status(201).json(prescription);
    } catch (error) {
      console.error("\u274C Error creating prescription:", error);
      console.error("\u274C Error message:", error.message);
      res.status(500).json({ message: "Failed to create prescription" });
    }
  });
  app2.patch("/api/prescriptions/:id/status", async (req, res) => {
    try {
      const { tenantId, id: userId } = req.user;
      const prescriptionId = req.params.id;
      const { status } = req.body;
      console.log(`\u{1F3E5} PRESCRIPTION STATUS UPDATE - ID: ${prescriptionId}, Status: ${status}, Tenant: ${tenantId}`);
      if (!status) {
        return res.status(400).json({ message: "Status is required" });
      }
      const tenant = await storage.getTenant(tenantId);
      if (tenant && tenant.type === "pharmacy") {
        const [prescription] = await db.select().from(prescriptions).where(and3(eq3(prescriptions.id, prescriptionId), eq3(prescriptions.pharmacyTenantId, tenantId)));
        if (!prescription) {
          return res.status(404).json({ message: "Prescription not found or not routed to this pharmacy" });
        }
        const [updatedPrescription] = await db.update(prescriptions).set({
          status,
          lastStatusUpdate: /* @__PURE__ */ new Date(),
          ...status === "dispensed" && { dispensedDate: /* @__PURE__ */ new Date() },
          ...status === "ready_for_pickup" && { readyForPickupDate: /* @__PURE__ */ new Date() }
        }).where(eq3(prescriptions.id, prescriptionId)).returning();
        console.log(`\u2705 PHARMACY STATUS UPDATE - Updated prescription ${prescriptionId} to ${status}`);
        res.json(updatedPrescription);
      } else {
        const updatedPrescription = await storage.updatePrescription(prescriptionId, {
          status,
          lastStatusUpdate: /* @__PURE__ */ new Date(),
          ...status === "sent_to_pharmacy" && { sentToPharmacyDate: /* @__PURE__ */ new Date() }
        }, tenantId);
        if (!updatedPrescription) {
          return res.status(404).json({ message: "Prescription not found or access denied" });
        }
        res.json(updatedPrescription);
      }
    } catch (error) {
      console.error("\u274C Error updating prescription status:", error);
      res.status(500).json({
        message: "Failed to update prescription status",
        error: error.message
      });
    }
  });
  app2.post("/api/patient-check-ins", async (req, res) => {
    try {
      const { tenantId, id: userId } = req.user;
      if (!tenantId || !userId) {
        return res.status(400).json({
          message: "Missing authentication data"
        });
      }
      const checkInData = {
        ...req.body,
        tenantId,
        checkedInBy: userId,
        checkedInAt: /* @__PURE__ */ new Date(),
        status: "waiting"
      };
      const checkIn = await storage.createPatientCheckIn(checkInData);
      res.status(201).json(checkIn);
    } catch (error) {
      console.error("Error creating patient check-in:", error);
      res.status(500).json({
        message: "Failed to check in patient",
        error: error.message
      });
    }
  });
  app2.get("/api/patient-check-ins/waiting", async (req, res) => {
    try {
      const { tenantId } = req.user;
      const waitingPatients = await storage.getWaitingPatients(tenantId);
      res.json(waitingPatients);
    } catch (error) {
      console.error("Error fetching waiting patients:", error);
      res.status(500).json({ message: "Failed to fetch waiting patients" });
    }
  });
  app2.get("/api/patient-check-ins/today", async (req, res) => {
    try {
      const { tenantId } = req.user;
      const todaysCheckIns = await storage.getTodaysCheckIns(tenantId);
      res.json(todaysCheckIns);
    } catch (error) {
      console.error("Error fetching today's check-ins:", error);
      res.status(500).json({ message: "Failed to fetch today's check-ins" });
    }
  });
  app2.patch("/api/patient-check-ins/:id", async (req, res) => {
    try {
      const { tenantId } = req.user;
      const { id } = req.params;
      const updates = req.body;
      const updatedCheckIn = await storage.updatePatientCheckIn(id, updates, tenantId);
      if (!updatedCheckIn) {
        return res.status(404).json({ message: "Check-in not found" });
      }
      res.json(updatedCheckIn);
    } catch (error) {
      console.error("Error updating patient check-in:", error);
      res.status(500).json({
        message: "Failed to update check-in",
        error: error.message
      });
    }
  });
  app2.get("/api/appointments", async (req, res) => {
    try {
      const { tenantId } = req.user;
      const appointments2 = await storage.getAppointmentsByTenant(tenantId);
      res.json(appointments2);
    } catch (error) {
      console.error("Error fetching appointments:", error);
      res.status(500).json({ message: "Failed to fetch appointments" });
    }
  });
  app2.post("/api/appointments", async (req, res) => {
    try {
      const { tenantId } = req.user;
      console.log("\u{1F3E5} Creating appointment - User:", req.user?.username, "Tenant:", tenantId);
      console.log("\u{1F3E5} Request body:", JSON.stringify(req.body, null, 2));
      const dateObj = new Date(req.body.appointmentDate);
      console.log("\u{1F3E5} Date conversion - Original:", req.body.appointmentDate, "Converted:", dateObj, "Valid:", !isNaN(dateObj.getTime()));
      const appointmentData = {
        tenantId,
        patientId: req.body.patientId,
        providerId: req.body.providerId,
        appointmentDate: dateObj,
        duration: req.body.duration || 30,
        type: req.body.type,
        status: req.body.status || "scheduled",
        notes: req.body.notes || null,
        chiefComplaint: req.body.chiefComplaint || null
      };
      console.log("\u{1F3E5} Clean appointment data:", JSON.stringify(appointmentData, null, 2));
      const appointment = await storage.createAppointment(appointmentData);
      console.log("\u{1F3E5} Appointment created successfully:", appointment.id);
      res.status(201).json(appointment);
    } catch (error) {
      console.error("\u274C Error creating appointment:", error);
      console.error("\u274C Error details:", error.message, error.code);
      res.status(500).json({
        message: "Failed to create appointment",
        error: error.message,
        details: error.code || "Unknown error"
      });
    }
  });
  app2.patch("/api/appointments/:id", async (req, res) => {
    try {
      const { tenantId } = req.user;
      const { id } = req.params;
      const { status, notes } = req.body;
      if (!tenantId) {
        return res.status(400).json({
          message: "Missing authentication data - tenantId required"
        });
      }
      if (!status) {
        return res.status(400).json({ message: "Status is required" });
      }
      const updatedAppointment = await storage.updateAppointment(id, { status, notes }, tenantId);
      if (!updatedAppointment) {
        return res.status(404).json({ message: "Appointment not found or access denied" });
      }
      res.json(updatedAppointment);
    } catch (error) {
      console.error("Error updating appointment status:", error);
      res.status(500).json({
        message: "Failed to update appointment status",
        error: error.message
      });
    }
  });
  app2.get("/api/visit-summaries/appointment/:appointmentId", async (req, res) => {
    try {
      const { tenantId } = req.user;
      const visitSummary = await storage.getVisitSummaryByAppointment(req.params.appointmentId, tenantId);
      res.json(visitSummary);
    } catch (error) {
      console.error("Error fetching appointment visit summary:", error);
      res.status(500).json({ message: "Failed to fetch appointment visit summary" });
    }
  });
  app2.post("/api/visit-summaries", async (req, res) => {
    try {
      const { tenantId, id: providerId } = req.user;
      if (!tenantId || !providerId) {
        return res.status(400).json({
          message: "Missing authentication data - tenantId and providerId required"
        });
      }
      const validatedData = {
        ...req.body,
        tenantId,
        providerId
      };
      const visitSummary = await storage.createVisitSummary(validatedData);
      res.json(visitSummary);
    } catch (error) {
      console.error("Error creating visit summary:", error);
      res.status(500).json({ message: "Failed to create visit summary" });
    }
  });
  app2.get("/api/lab-orders", authenticateToken, async (req, res) => {
    console.log("\u{1F9EA} LAB ORDERS ENDPOINT HIT:", req.query);
    try {
      if (!req.user) {
        console.log("\u{1F6A8} No user authenticated");
        return res.status(401).json({ message: "Authentication required" });
      }
      const { tenantId } = req.user;
      const { forLaboratory, archived, status } = req.query;
      console.log("\u{1F9EA} Processing request for tenant:", tenantId, "forLaboratory:", forLaboratory, "status:", status);
      let labOrders2;
      if (forLaboratory === "true") {
        labOrders2 = await storage.getLabOrdersForLaboratory(tenantId);
        if (status) {
          labOrders2 = labOrders2.filter((order) => order.status === status);
          console.log(`\u{1F9EA} Filtered lab orders by status '${status}': ${labOrders2.length} orders`);
        }
      } else {
        labOrders2 = await storage.getLabOrdersByTenant(tenantId);
      }
      res.json(labOrders2);
    } catch (error) {
      console.error("Error fetching lab orders:", error);
      res.status(500).json({ message: "Failed to fetch lab orders" });
    }
  });
  app2.post("/api/lab-orders", authenticateToken, async (req, res) => {
    try {
      const { tenantId, userId, id } = req.user;
      console.log("\u{1F9EA} Debug - req.user contents:", req.user);
      console.log("\u{1F9EA} Debug - userId:", userId, "id:", id, "tenantId:", tenantId);
      const providerId = userId || id;
      if (!providerId) {
        console.error("\u{1F6A8} No provider ID found in req.user");
        return res.status(400).json({ message: "Provider ID missing from authentication" });
      }
      const labOrderData = { ...req.body, tenantId, providerId };
      console.log("\u{1F9EA} Creating lab order with data:", labOrderData);
      const labOrder = await storage.createLabOrder(labOrderData);
      res.status(201).json(labOrder);
    } catch (error) {
      console.error("Error creating lab order:", error);
      res.status(500).json({ message: "Failed to create lab order" });
    }
  });
  app2.get("/api/lab-results", authenticateToken, requireTenant, async (req, res) => {
    try {
      const labResults2 = await storage.getLabResultsByTenant(req.tenantId);
      res.json(labResults2);
    } catch (error) {
      console.error("Error fetching lab results:", error);
      res.status(500).json({ message: "Failed to fetch lab results" });
    }
  });
  app2.get("/api/lab-results/patient/:patientId", authenticateToken, requireTenant, async (req, res) => {
    try {
      const labResults2 = await storage.getLabResultsByPatient(req.params.patientId, req.tenantId);
      res.json(labResults2);
    } catch (error) {
      console.error("Error fetching patient lab results:", error);
      res.status(500).json({ message: "Failed to fetch patient lab results" });
    }
  });
  app2.get("/api/lab-results/order/:labOrderId", authenticateToken, requireTenant, async (req, res) => {
    try {
      const labResults2 = await storage.getLabResultsByOrder(req.params.labOrderId, req.tenantId);
      res.json(labResults2);
    } catch (error) {
      console.error("Error fetching lab order results:", error);
      res.status(500).json({ message: "Failed to fetch lab order results" });
    }
  });
  app2.post("/api/lab-results", authenticateToken, requireRole(["lab_technician", "physician", "tenant_admin", "director", "super_admin"]), requireTenant, async (req, res) => {
    try {
      const laboratories2 = await storage.getLaboratoriesByTenant(req.tenantId);
      const laboratory = laboratories2[0];
      if (!laboratory) {
        return res.status(400).json({ message: "No laboratory found for this tenant" });
      }
      const labResultData = insertLabResultSchema.parse({
        ...req.body,
        tenantId: req.tenantId,
        laboratoryId: laboratory.id
      });
      const labResult = await storage.createLabResult(labResultData);
      await storage.createAuditLog({
        tenantId: req.tenantId,
        userId: req.userId,
        entityType: "lab_result",
        entityId: labResult.id,
        action: "create",
        previousData: null,
        newData: labResult,
        ipAddress: req.ip || null,
        userAgent: req.get("User-Agent") || null
      });
      res.status(201).json(labResult);
    } catch (error) {
      if (error instanceof z2.ZodError) {
        return res.status(400).json({ message: "Invalid lab result data", errors: error.errors });
      }
      console.error("Error creating lab result:", error);
      res.status(500).json({ message: "Failed to create lab result" });
    }
  });
  app2.get("/api/laboratories/active", authenticateToken, async (req, res) => {
    try {
      console.log("\u{1F52C} Fetching active laboratories for lab order creation");
      const laboratories2 = await storage.getActiveLaboratoryTenants();
      console.log(`\u{1F52C} Found ${laboratories2.length} active laboratories:`, laboratories2.map((lab) => `${lab.name} (${lab.subdomain})`));
      res.json(laboratories2);
    } catch (error) {
      console.error("Error fetching active laboratories:", error);
      res.status(500).json({ message: "Failed to fetch active laboratories" });
    }
  });
  app2.get("/api/billing", async (req, res) => {
    try {
      const { tenantId } = req.user;
      const billing = await storage.getBilling(tenantId);
      res.json(billing);
    } catch (error) {
      console.error("Error fetching billing:", error);
      res.status(500).json({ message: "Failed to fetch billing data" });
    }
  });
  app2.get("/api/billing/patients", authenticateToken, setTenantContext, requireTenant, async (req, res) => {
    try {
      const { tenantId } = req.user;
      const tenant = await storage.getTenant(tenantId);
      if (tenant && tenant.type === "pharmacy") {
        const patients2 = await storage.getPatientsWithPrescriptionsForPharmacy(tenantId);
        console.log(`\u{1F48A} BILLING PATIENTS - Found ${patients2.length} patients with prescriptions for pharmacy ${tenant.name}`);
        res.json(patients2);
      } else if (tenant && tenant.type === "laboratory") {
        const patients2 = await storage.getPatientsWithLabOrdersForLaboratory(tenantId);
        console.log(`\u{1F9EA} BILLING PATIENTS - Found ${patients2.length} patients with lab orders for laboratory ${tenant.name}`);
        res.json(patients2);
      } else {
        const patients2 = await storage.getPatientsByTenant(tenantId);
        console.log(`\u{1F48A} BILLING PATIENTS - Found ${patients2.length} patients for ${tenant?.type || "unknown"} ${tenant?.name || tenantId}`);
        res.json(patients2);
      }
    } catch (error) {
      console.error("Error fetching billing patients:", error);
      res.status(500).json({ message: "Failed to fetch billing patients" });
    }
  });
  app2.get("/api/insurance-claims", async (req, res) => {
    try {
      const { tenantId } = req.user;
      const claims = await storage.getInsuranceClaimsByTenant(tenantId);
      res.json(claims);
    } catch (error) {
      console.error("Error fetching insurance claims:", error);
      res.status(500).json({ message: "Failed to fetch insurance claims" });
    }
  });
  app2.get("/api/insurance-claims/:id/download", async (req, res) => {
    try {
      const { tenantId } = req.user;
      const { id: claimId } = req.params;
      console.log(`\u{1F48A} PDF DOWNLOAD - Generating document for claim ${claimId}`);
      const claim = await storage.getInsuranceClaim(claimId, tenantId);
      if (!claim) {
        console.log(`\u{1F48A} PDF DOWNLOAD ERROR - Claim ${claimId} not found for tenant ${tenantId}`);
        return res.status(404).json({ message: "Insurance claim not found" });
      }
      console.log(`\u{1F48A} PDF DOWNLOAD - Found claim for patient ${claim.patientFirstName} ${claim.patientLastName}`);
      const procedureCode = claim.procedureCodes?.[0];
      const medicationName = procedureCode?.description?.split(" - ")[0] || "N/A";
      const notes = claim.notes || "";
      const dosageMatch = notes.match(/Dosage: ([^,]+)/);
      const quantityMatch = notes.match(/Quantity: ([^,]+)/);
      const daysSupplyMatch = notes.match(/Days Supply: ([^,]+)/);
      const claimWithPatient = {
        id: claim.id,
        claimNumber: claim.claimNumber,
        medicationName,
        dosage: dosageMatch?.[1] || "N/A",
        quantity: quantityMatch?.[1] || "N/A",
        daysSupply: daysSupplyMatch?.[1] || "N/A",
        totalAmount: claim.totalAmount || "0.00",
        totalPatientCopay: claim.totalPatientCopay || "0.00",
        totalInsuranceAmount: claim.totalInsuranceAmount || "0.00",
        status: claim.status,
        submittedDate: claim.submittedDate,
        patientFirstName: claim.patientFirstName,
        patientLastName: claim.patientLastName,
        patientMrn: claim.patientMrn,
        patientId: claim.patientId
      };
      const documentContent = generateInsuranceClaimDocument(claimWithPatient);
      res.setHeader("Content-Type", "text/plain; charset=utf-8");
      res.setHeader("Content-Disposition", `attachment; filename="Insurance_Claim_${claim.claimNumber}.txt"`);
      console.log(`\u{1F48A} PDF DOWNLOAD SUCCESS - Document generated for claim ${claimId} for patient ${claim.patientFirstName} ${claim.patientLastName}`);
      res.send(documentContent);
    } catch (error) {
      console.error("Error generating PDF:", error);
      res.status(500).json({ message: "Failed to generate PDF" });
    }
  });
  app2.post("/api/test-post", (req, res) => {
    console.log("\u{1F9EA} TEST POST - Request received:", req.body);
    res.json({ success: true, message: "POST request working", data: req.body });
  });
  app2.post("/api/insurance-claims-test", (req, res) => {
    console.log("\u{1F48A} INSURANCE CLAIMS TEST - Request received:", req.body);
    res.json({
      success: true,
      message: "Insurance claims test endpoint working",
      receivedData: req.body
    });
  });
  app2.post("/api/insurance-claims", async (req, res) => {
    console.log("\u{1F48A} POST /api/insurance-claims - Request received:", req.body);
    try {
      const { tenantId, id: userId } = req.user;
      console.log("\u{1F48A} User context:", { tenantId, userId });
      const claimData = {
        tenantId,
        patientId: req.body.patientId,
        providerId: userId,
        claimNumber: req.body.claimNumber,
        status: "submitted",
        // Saved as submitted, ready for manual processing
        // Required arrays for insurance claims table
        secondaryDiagnosisCodes: [],
        procedureCodes: [{
          code: req.body.medicationCode || "MED-001",
          description: `${req.body.medicationName} - ${req.body.dosage}`,
          amount: parseFloat(req.body.claimAmount || "0")
        }],
        diagnosisCodes: [],
        attachments: [],
        // Medical information from prescription
        primaryDiagnosisCode: req.body.diagnosticCode || "Z00.00",
        primaryDiagnosisDescription: req.body.medicationNote || "Medication prescription claim",
        clinicalFindings: `Prescription medication: ${req.body.medicationName || "Unknown"} (${req.body.dosage || "N/A"})`,
        treatmentProvided: `${req.body.medicationName || "Medication"} prescribed for ${req.body.daysSupply || 30} days`,
        medicalNecessity: "Prescription medication as prescribed by licensed physician",
        // Medication details (direct fields)
        medicationName: req.body.medicationName || "Unknown",
        dosage: req.body.dosage || "N/A",
        quantity: parseInt(req.body.quantity) || 0,
        daysSupply: parseInt(req.body.daysSupply) || 0,
        // Financial information
        totalAmount: req.body.claimAmount?.toString() || "0.00",
        totalPatientCopay: req.body.patientShare?.toString() || "0.00",
        totalInsuranceAmount: (parseFloat(req.body.claimAmount || "0") - parseFloat(req.body.patientShare || "0"))?.toString() || "0.00",
        submittedDate: /* @__PURE__ */ new Date(),
        // Additional medication details
        notes: `Medication: ${req.body.medicationName}, Dosage: ${req.body.dosage}, Quantity: ${req.body.quantity}, Days Supply: ${req.body.daysSupply}, Pharmacy NPI: ${req.body.pharmacyNpi || "N/A"}`
      };
      const savedClaim = await storage.createInsuranceClaim(claimData);
      console.log(`\u{1F48A} INSURANCE FILING SAVED - Claim ${savedClaim.claimNumber} filed for patient ${req.body.patientId}`);
      res.status(201).json({
        success: true,
        message: "Insurance claim filing saved successfully",
        claim: {
          id: savedClaim.id,
          claimNumber: savedClaim.claimNumber,
          status: savedClaim.status,
          totalAmount: savedClaim.totalAmount,
          submittedDate: savedClaim.submittedDate
        }
      });
    } catch (error) {
      console.error("Error saving insurance claim filing:", error);
      res.status(500).json({ message: "Failed to save insurance claim filing" });
    }
  });
  app2.get("/api/pharmacies", async (req, res) => {
    try {
      const pharmacyTenants = await db.select().from(tenants).where(and3(eq3(tenants.type, "pharmacy"), eq3(tenants.isActive, true)));
      const pharmacyList = pharmacyTenants.map((tenant) => ({
        id: tenant.id,
        tenantId: tenant.id,
        name: tenant.name || "Unknown Pharmacy",
        phone: tenant.phoneNumber || "",
        email: "",
        address: tenant.address || "",
        licenseNumber: "",
        npiNumber: "",
        acceptsInsurance: true,
        deliveryService: false,
        operatingHours: null,
        specializations: [],
        websiteUrl: ""
      }));
      res.json(pharmacyList);
    } catch (error) {
      console.error("Error fetching pharmacies for routing:", error);
      res.status(500).json({ message: "Failed to fetch pharmacies" });
    }
  });
  app2.post("/api/prescriptions/:id/route-to-pharmacy", async (req, res) => {
    try {
      const { tenantId, id: userId } = req.user;
      const prescriptionId = req.params.id;
      const { pharmacyTenantId } = req.body;
      console.log(`\u{1F4CB} ROUTING PRESCRIPTION - ID: ${prescriptionId} to pharmacy: ${pharmacyTenantId}`);
      const [updatedPrescription] = await db.update(prescriptions).set({
        pharmacyTenantId,
        status: "sent_to_pharmacy",
        sentToPharmacyDate: /* @__PURE__ */ new Date(),
        lastStatusUpdate: /* @__PURE__ */ new Date(),
        patientSelectedPharmacy: true,
        routedFromHospital: tenantId
      }).where(eq3(prescriptions.id, prescriptionId)).returning();
      if (!updatedPrescription) {
        return res.status(404).json({ message: "Prescription not found" });
      }
      console.log(`\u2705 PRESCRIPTION ROUTED - Successfully routed to pharmacy`);
      res.json(updatedPrescription);
    } catch (error) {
      console.error("Error routing prescription to pharmacy:", error);
      res.status(500).json({ message: "Failed to route prescription to pharmacy" });
    }
  });
  app2.get("/api/hospital-patient-insurance/:patientId", async (req, res) => {
    try {
      const { patientId } = req.params;
      const { tenantId } = req.user;
      const insurance = await storage.getHospitalPatientInsuranceByPatientId(patientId, tenantId);
      res.json(insurance);
    } catch (error) {
      console.error("Error fetching hospital patient insurance:", error);
      res.status(500).json({ message: "Failed to fetch insurance information" });
    }
  });
  app2.post("/api/hospital-patient-insurance", async (req, res) => {
    try {
      const { tenantId } = req.user;
      if (!tenantId) {
        return res.status(400).json({
          message: "Missing authentication data - tenantId required"
        });
      }
      const insuranceData = {
        ...req.body,
        tenantId
      };
      const insurance = await storage.createHospitalPatientInsurance(insuranceData);
      res.status(201).json(insurance);
    } catch (error) {
      console.error("Error creating hospital patient insurance:", error);
      res.status(500).json({ message: "Failed to create insurance information" });
    }
  });
  app2.patch("/api/hospital-patient-insurance/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updateData = { ...req.body };
      const insurance = await storage.updateHospitalPatientInsurance(id, updateData);
      if (!insurance) {
        return res.status(404).json({ message: "Insurance information not found" });
      }
      res.json(insurance);
    } catch (error) {
      console.error("Error updating hospital patient insurance:", error);
      res.status(500).json({ message: "Failed to update insurance information" });
    }
  });
  app2.post("/api/prescriptions/:prescriptionId/send-to-pharmacy", async (req, res) => {
    try {
      const { prescriptionId } = req.params;
      const { pharmacyTenantId, routingNotes } = req.body;
      const { tenantId, userId, role } = req.user;
      if (role !== "physician" && role !== "tenant_admin") {
        return res.status(403).json({ message: "Only physicians can route prescriptions" });
      }
      const prescription = await storage.getPrescription(prescriptionId, tenantId);
      if (!prescription) {
        return res.status(404).json({ message: "Prescription not found" });
      }
      const [pharmacyTenant] = await db.select().from(tenants).where(and3(eq3(tenants.id, pharmacyTenantId), eq3(tenants.type, "pharmacy"), eq3(tenants.isActive, true)));
      if (!pharmacyTenant) {
        return res.status(400).json({ message: "Invalid pharmacy selected" });
      }
      const updatedPrescription = await storage.updatePrescription(prescriptionId, tenantId, {
        pharmacyTenantId,
        routedFromHospital: tenantId,
        patientSelectedPharmacy: true,
        routingNotes,
        status: "sent_to_pharmacy",
        sentToPharmacyDate: /* @__PURE__ */ new Date(),
        lastStatusUpdate: /* @__PURE__ */ new Date()
      });
      res.json({
        message: "Prescription successfully sent to pharmacy",
        prescription: updatedPrescription,
        pharmacy: {
          id: pharmacyTenant.id,
          name: pharmacyTenant.name,
          address: pharmacyTenant.address
        }
      });
    } catch (error) {
      console.error("Error sending prescription to pharmacy:", error);
      res.status(500).json({ message: "Failed to send prescription to pharmacy" });
    }
  });
  app2.get("/api/prescriptions/:prescriptionId/routing-status", async (req, res) => {
    try {
      const { prescriptionId } = req.params;
      const { tenantId } = req.user;
      const prescription = await storage.getPrescription(prescriptionId, tenantId);
      if (!prescription) {
        return res.status(404).json({ message: "Prescription not found" });
      }
      let pharmacyInfo = null;
      if (prescription.pharmacyTenantId) {
        const [pharmacyTenant] = await db.select().from(tenants).where(eq3(tenants.id, prescription.pharmacyTenantId));
        if (pharmacyTenant) {
          pharmacyInfo = {
            id: pharmacyTenant.id,
            name: pharmacyTenant.name,
            phone: pharmacyTenant.phone,
            address: pharmacyTenant.address
          };
        }
      }
      res.json({
        prescriptionId: prescription.id,
        status: prescription.status,
        routingStatus: {
          isRouted: !!prescription.pharmacyTenantId,
          sentToPharmacyDate: prescription.sentToPharmacyDate,
          routingNotes: prescription.routingNotes,
          patientSelectedPharmacy: prescription.patientSelectedPharmacy
        },
        pharmacy: pharmacyInfo,
        workflow: {
          prescribedDate: prescription.prescribedDate,
          sentToPharmacyDate: prescription.sentToPharmacyDate,
          insuranceVerifiedDate: prescription.insuranceVerifiedDate,
          processingStartedDate: prescription.processingStartedDate,
          readyDate: prescription.readyDate,
          dispensedDate: prescription.dispensedDate
        }
      });
    } catch (error) {
      console.error("Error fetching prescription routing status:", error);
      res.status(500).json({ message: "Failed to fetch routing status" });
    }
  });
  app2.put("/api/admin/tenants/:id/suspend", async (req, res) => {
    try {
      const { role } = req.user;
      if (role !== "super_admin") {
        return res.status(403).json({ message: "Super admin access required" });
      }
      const { id } = req.params;
      const { reason } = req.body;
      await db.update(tenants).set({
        isActive: false,
        suspendedAt: /* @__PURE__ */ new Date(),
        suspensionReason: reason || "Account suspended by administrator"
      }).where(eq3(tenants.id, id));
      res.json({ message: "Tenant suspended successfully" });
    } catch (error) {
      console.error("Error suspending tenant:", error);
      res.status(500).json({ message: "Failed to suspend tenant" });
    }
  });
  app2.put("/api/admin/tenants/:id/activate", async (req, res) => {
    try {
      const { role } = req.user;
      if (role !== "super_admin") {
        return res.status(403).json({ message: "Super admin access required" });
      }
      const { id } = req.params;
      await db.update(tenants).set({
        isActive: true,
        suspendedAt: null,
        suspensionReason: null
      }).where(eq3(tenants.id, id));
      res.json({ message: "Tenant activated successfully" });
    } catch (error) {
      console.error("Error activating tenant:", error);
      res.status(500).json({ message: "Failed to activate tenant" });
    }
  });
  app2.get("/api/users", async (req, res) => {
    try {
      const user = req.user;
      const tenantId = user.tenantId || user.tenant_id;
      if (!tenantId) {
        return res.status(400).json({ message: "Tenant ID not found" });
      }
      const users2 = await storage.getUsersByTenant(tenantId);
      res.json(users2);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });
  app2.post("/api/users", async (req, res) => {
    try {
      const { tenantId } = req.user;
      const { password, ...userData } = req.body;
      const saltRounds = 10;
      const passwordHash = await bcrypt.hash(password, saltRounds);
      const newUserData = { ...userData, tenantId, passwordHash };
      const user = await storage.createUser(newUserData);
      const { sendRegistrationConfirmationEmail: sendRegistrationConfirmationEmail2 } = await Promise.resolve().then(() => (init_email_service(), email_service_exports));
      if (userData.email) {
        try {
          const currentTenant = await storage.getTenant(tenantId);
          const loginUrl = `https://navimed-healthcare.replit.app/login`;
          const userName = `${userData.firstName || ""} ${userData.lastName || ""}`.trim() || userData.username || "New User";
          const emailSent = await sendRegistrationConfirmationEmail2(
            userData.email,
            userName,
            currentTenant?.name || "NaviMED",
            loginUrl
          );
          console.log(`\u{1F4E7} User creation confirmation email ${emailSent ? "sent successfully" : "failed to send"} to ${userData.email}`);
        } catch (emailError) {
          console.error("\u26A0\uFE0F Failed to send user creation confirmation email:", emailError);
        }
      }
      res.status(201).json(user);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ message: "Failed to create user" });
    }
  });
  app2.patch("/api/users/:id", async (req, res) => {
    try {
      const { tenantId } = req.user;
      const { id } = req.params;
      const { isActive } = req.body;
      if (typeof isActive !== "boolean") {
        return res.status(400).json({ message: "isActive must be a boolean value" });
      }
      const updatedUser = await storage.updateUserStatus(id, tenantId, isActive);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found or access denied" });
      }
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user status:", error);
      res.status(500).json({ message: "Failed to update user status" });
    }
  });
  app2.get("/api/laboratory/billing", authenticateToken, async (req, res) => {
    try {
      const { tenantId } = req.user;
      console.log("\u{1F9EA} GET /api/laboratory/billing - Fetching bills for tenant:", tenantId);
      const bills = await storage.getLabBillsByTenant(tenantId);
      console.log(`\u{1F9EA} Found ${bills.length} lab bills for tenant ${tenantId}`);
      res.json(bills);
    } catch (error) {
      console.error("Error fetching laboratory bills:", error);
      res.status(500).json({ message: "Failed to fetch laboratory bills" });
    }
  });
  app2.post("/api/laboratory/billing", authenticateToken, async (req, res) => {
    console.log("\u{1F9EA} LAB BILLING POST - Endpoint hit!");
    console.log("\u{1F9EA} Request method:", req.method);
    console.log("\u{1F9EA} Request path:", req.path);
    console.log("\u{1F9EA} Request headers:", req.headers);
    console.log("\u{1F9EA} User object exists:", !!req.user);
    console.log("\u{1F9EA} Request body:", req.body);
    try {
      if (!req.user) {
        console.log("\u{1F6A8} No user object found in request");
        return res.status(401).json({ message: "Authentication required" });
      }
      const { tenantId, id: userId } = req.user;
      console.log("\u{1F9EA} POST /api/laboratory/billing - Request received:", req.body);
      console.log("\u{1F9EA} User context:", { tenantId, userId });
      const {
        patientId,
        labOrderId,
        amount,
        description,
        insuranceCoverageRate,
        insuranceAmount,
        patientAmount,
        claimNumber,
        labCodes,
        diagnosisCodes,
        labNotes,
        testName
      } = req.body;
      const billNumber = `LAB-${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
      const hasInsuranceInfo = insuranceCoverageRate > 0 || insuranceAmount > 0 || claimNumber;
      const billStatus = hasInsuranceInfo ? "pending" : "pending_manual_review";
      const labBillData = {
        tenantId,
        patientId,
        labOrderId,
        billNumber,
        amount: amount.toString(),
        description,
        status: billStatus,
        serviceType: "lab_test",
        labCodes: labCodes || null,
        diagnosisCodes: diagnosisCodes || null,
        notes: labNotes || null,
        testName: testName || null,
        claimNumber: claimNumber || null,
        insuranceCoverageRate: insuranceCoverageRate ? insuranceCoverageRate.toString() : null,
        insuranceAmount: insuranceAmount ? insuranceAmount.toString() : null,
        patientAmount: patientAmount ? patientAmount.toString() : null,
        generatedBy: userId
      };
      console.log("\u{1F9EA} Creating lab bill with data:", labBillData);
      const savedLabBill = await storage.createLabBill(labBillData);
      console.log(`\u{1F9EA} LAB BILL CREATED - Bill ${savedLabBill.billNumber} created for patient ${patientId}`);
      res.status(201).json({
        success: true,
        message: "Laboratory bill created successfully",
        labBill: {
          id: savedLabBill.id,
          billNumber: savedLabBill.billNumber,
          status: savedLabBill.status,
          amount: savedLabBill.amount,
          description: savedLabBill.description
        }
      });
    } catch (error) {
      console.error("Error creating laboratory bill:", error);
      res.status(500).json({ message: "Failed to create laboratory bill" });
    }
  });
  app2.get("/api/laboratory/billing/:id/insurance-file", authenticateToken, async (req, res) => {
    try {
      const { tenantId } = req.user;
      const { id } = req.params;
      console.log("\u{1F9EA} Generating insurance file for bill:", id, "tenant:", tenantId);
      const bills = await storage.getLabBillsByTenant(tenantId);
      const bill = bills.find((b) => b.id === id);
      if (!bill) {
        return res.status(404).json({ message: "Lab bill not found" });
      }
      const patients2 = await storage.getAllPatients();
      const patient = patients2.find((p) => p.id === bill.patientId);
      if (!patient) {
        return res.status(404).json({ message: "Patient not found" });
      }
      const tenant = await storage.getTenantById(tenantId);
      if (!tenant) {
        return res.status(404).json({ message: "Laboratory not found" });
      }
      const currentDate = (/* @__PURE__ */ new Date()).toLocaleDateString();
      const serviceDate = new Date(bill.createdAt || Date.now()).toLocaleDateString();
      const insuranceFileContent = `INSURANCE CLAIM SUBMISSION
Laboratory: ${tenant.name}
Address: ${tenant.settings?.address || "N/A"}
Phone: ${tenant.settings?.phone || "N/A"}
Tax ID: ${tenant.settings?.taxId || "N/A"}
CLIA Number: ${tenant.settings?.cliaNumber || "N/A"}

PATIENT INFORMATION
Name: ${patient.firstName} ${patient.lastName}
MRN: ${patient.mrn}
Date of Birth: ${patient.dateOfBirth ? new Date(patient.dateOfBirth).toLocaleDateString() : "N/A"}
Phone: ${patient.phone || "N/A"}
Address: ${patient.address ? typeof patient.address === "string" ? patient.address : JSON.stringify(patient.address) : "N/A"}

BILLING INFORMATION
Bill Number: ${bill.billNumber}
Service Date: ${serviceDate}
Test Name: ${bill.testName || "Lab Test"}
Lab Codes: ${bill.labCodes || "N/A"}
Diagnosis Codes: ${bill.diagnosisCodes || "N/A"}
Description: ${bill.description}

FINANCIAL DETAILS
Total Amount: $${bill.amount}
Insurance Coverage Rate: ${bill.insuranceCoverageRate || "0"}%
Insurance Amount: $${bill.insuranceAmount || "0.00"}
Patient Amount: $${bill.patientAmount || bill.amount}
Claim Number: ${bill.claimNumber || "PENDING"}

NOTES
${bill.notes || "No additional notes"}

Generated: ${currentDate}
Status: ${bill.status}

---
This file is for insurance manual submission.
Please attach all required supporting documentation.
`;
      res.setHeader("Content-Type", "text/plain");
      res.setHeader("Content-Disposition", `attachment; filename="insurance-claim-${bill.billNumber}-${patient.firstName}-${patient.lastName}.txt"`);
      res.send(insuranceFileContent);
    } catch (error) {
      console.error("Error generating insurance file:", error);
      res.status(500).json({ message: "Failed to generate insurance file" });
    }
  });
  app2.patch("/api/laboratory/billing/:billId", authenticateToken, async (req, res) => {
    try {
      const { billId } = req.params;
      const { tenantId } = req.user;
      const updates = req.body;
      console.log(`\u{1F9EA} PATCH /api/laboratory/billing/${billId} - Updating bill for tenant:`, tenantId);
      console.log("\u{1F9EA} Update data:", updates);
      const updatedBill = await storage.updateLabBill(billId, updates, tenantId);
      if (!updatedBill) {
        return res.status(404).json({ message: "Laboratory bill not found" });
      }
      console.log(`\u{1F9EA} LAB BILL UPDATED - Bill ${billId} updated successfully`);
      res.json({
        success: true,
        message: "Laboratory bill updated successfully",
        bill: updatedBill
      });
    } catch (error) {
      console.error("Error updating laboratory bill:", error);
      res.status(500).json({ message: "Failed to update laboratory bill" });
    }
  });
  app2.get("/api/laboratory/billing/:billId/receipt", authenticateToken, async (req, res) => {
    try {
      const { billId } = req.params;
      const { tenantId } = req.user;
      console.log(`\u{1F9EA} GET /api/laboratory/billing/${billId}/receipt - Generating receipt for tenant:`, tenantId);
      const bill = await storage.getLabBill(billId, tenantId);
      if (!bill) {
        return res.status(404).json({ message: "Laboratory bill not found" });
      }
      const receipt = {
        receiptNumber: `LAB-${bill.id.substring(0, 8).toUpperCase()}`,
        tenantName: "LABSAFE Laboratory",
        patientName: `${bill.patientFirstName} ${bill.patientLastName}`,
        patientMrn: bill.patientMrn,
        testName: bill.testName,
        description: bill.description,
        serviceType: bill.serviceType || "Laboratory Test",
        amount: bill.amount,
        status: bill.status,
        notes: bill.notes,
        createdAt: bill.createdAt
      };
      console.log(`\u{1F9EA} RECEIPT GENERATED - Receipt ${receipt.receiptNumber} for bill ${billId}`);
      res.json(receipt);
    } catch (error) {
      console.error("Error generating laboratory bill receipt:", error);
      res.status(500).json({ message: "Failed to generate laboratory bill receipt" });
    }
  });
  app2.post("/api/create-payment-intent", authenticateToken, async (req, res) => {
    try {
      if (!stripe) {
        return res.status(503).json({ message: "Payment processing not available - Stripe configuration missing" });
      }
      const { amount } = req.body;
      if (!amount || amount <= 0) {
        return res.status(400).json({ message: "Valid amount is required" });
      }
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100),
        // Convert to cents
        currency: "usd",
        automatic_payment_methods: {
          enabled: true
        }
      });
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error) {
      console.error("Error creating payment intent:", error);
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });
  app2.post("/api/get-or-create-subscription", authenticateToken, async (req, res) => {
    try {
      if (!stripe) {
        return res.status(503).json({ message: "Subscription processing not available - Stripe configuration missing" });
      }
      const user = req.user;
      if (!user) {
        return res.status(401).json({ message: "User not authenticated" });
      }
      if (user.stripeSubscriptionId) {
        try {
          const subscription2 = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
          if (subscription2.latest_invoice && typeof subscription2.latest_invoice === "object") {
            const latestInvoice2 = subscription2.latest_invoice;
            const paymentIntent2 = latestInvoice2.payment_intent;
            if (paymentIntent2 && typeof paymentIntent2 === "object") {
              return res.json({
                subscriptionId: subscription2.id,
                clientSecret: paymentIntent2.client_secret
              });
            }
          }
        } catch (stripeError) {
          console.error("Error retrieving existing subscription:", stripeError);
        }
      }
      if (!user.email) {
        return res.status(400).json({ message: "User email is required for subscription" });
      }
      let stripeCustomerId = user.stripeCustomerId;
      if (!stripeCustomerId) {
        const customer = await stripe.customers.create({
          email: user.email,
          name: `${user.firstName || ""} ${user.lastName || ""}`.trim() || user.username
        });
        stripeCustomerId = customer.id;
        await storage.updateStripeCustomerId(user.id, customer.id);
      }
      const subscription = await stripe.subscriptions.create({
        customer: stripeCustomerId,
        items: [{
          price_data: {
            currency: "usd",
            product_data: {
              name: "NaviMED Healthcare Platform Subscription",
              description: "Monthly subscription to healthcare platform services"
            },
            unit_amount: 2999,
            // $29.99 per month
            recurring: {
              interval: "month"
            }
          }
        }],
        payment_behavior: "default_incomplete",
        expand: ["latest_invoice.payment_intent"]
      });
      await storage.updateUserStripeInfo(user.id, stripeCustomerId, subscription.id);
      const latestInvoice = subscription.latest_invoice;
      const paymentIntent = latestInvoice && typeof latestInvoice === "object" ? latestInvoice.payment_intent : null;
      const clientSecret = paymentIntent && typeof paymentIntent === "object" ? paymentIntent.client_secret : null;
      res.json({
        subscriptionId: subscription.id,
        clientSecret
      });
    } catch (error) {
      console.error("Error creating subscription:", error);
      res.status(500).json({ message: "Error creating subscription: " + error.message });
    }
  });
  app2.get("/api/patient/prescriptions", authenticateToken, async (req, res) => {
    try {
      const { id: userId, tenantId } = req.user;
      console.log(`\u{1FA7A} PATIENT PRESCRIPTIONS - Getting prescriptions for patient ${userId}`);
      const patientPrescriptions = await db.select().from(prescriptions).where(eq3(prescriptions.patientId, userId)).orderBy(desc3(prescriptions.prescribedDate));
      console.log(`\u{1FA7A} Found ${patientPrescriptions.length} prescriptions for patient ${userId}`);
      res.json(patientPrescriptions);
    } catch (error) {
      console.error("Error fetching patient prescriptions:", error);
      res.status(500).json({ message: "Failed to fetch prescriptions" });
    }
  });
  app2.get("/api/patient/lab-results", authenticateToken, async (req, res) => {
    try {
      const { id: userId } = req.user;
      console.log(`\u{1F9EA} PATIENT LAB RESULTS - Getting lab results for patient ${userId}`);
      const patientLabOrders = await db.select().from(labOrders).where(eq3(labOrders.patientId, userId)).orderBy(desc3(labOrders.orderedDate));
      console.log(`\u{1F9EA} Found ${patientLabOrders.length} lab orders for patient ${userId}`);
      res.json(patientLabOrders);
    } catch (error) {
      console.error("Error fetching patient lab results:", error);
      res.status(500).json({ message: "Failed to fetch lab results" });
    }
  });
  app2.get("/api/patient/appointments", authenticateToken, async (req, res) => {
    try {
      const { id: userId } = req.user;
      console.log(`\u{1F4C5} PATIENT APPOINTMENTS - Getting appointments for patient ${userId}`);
      const patientAppointments = await db.select().from(appointments).where(eq3(appointments.patientId, userId)).orderBy(desc3(appointments.appointmentDate));
      console.log(`\u{1F4C5} Found ${patientAppointments.length} appointments for patient ${userId}`);
      res.json(patientAppointments);
    } catch (error) {
      console.error("Error fetching patient appointments:", error);
      res.status(500).json({ message: "Failed to fetch appointments" });
    }
  });
  app2.get("/api/patient/profile", authenticateToken, async (req, res) => {
    try {
      const { id: userId } = req.user;
      console.log(`\u{1F464} PATIENT PROFILE - Getting profile for patient ${userId}`);
      const [patientProfile] = await db.select().from(patients).where(eq3(patients.id, userId));
      if (!patientProfile) {
        return res.status(404).json({ message: "Patient profile not found" });
      }
      console.log(`\u{1F464} Found profile for patient ${patientProfile.firstName} ${patientProfile.lastName}`);
      res.json(patientProfile);
    } catch (error) {
      console.error("Error fetching patient profile:", error);
      res.status(500).json({ message: "Failed to fetch patient profile" });
    }
  });
  app2.get("/api/patient/lab-results/:id/pdf", authenticateToken, async (req, res) => {
    try {
      const { id: userId } = req.user;
      const { id } = req.params;
      console.log("\u{1F4C4} GENERATING LAB PDF - For lab result", id, "patient", userId);
      const [labOrder] = await db.select().from(labOrders).where(and3(
        eq3(labOrders.id, id),
        eq3(labOrders.patientId, userId)
      ));
      if (!labOrder) {
        return res.status(404).json({ message: "Lab result not found" });
      }
      const [patient] = await db.select().from(patients).where(eq3(patients.id, userId));
      if (!patient) {
        return res.status(404).json({ message: "Patient not found" });
      }
      const currentDate = (/* @__PURE__ */ new Date()).toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric"
      });
      const labReport = `
\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550
                            METRO GENERAL HOSPITAL
                              LABORATORY SERVICES
                        123 Medical Center Drive, Suite 100
                            Metro City, MC 12345-6789
                           Phone: (555) 123-4567 | Fax: (555) 123-4568
\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550

LABORATORY REPORT

Report Date: ${currentDate}                          Lab Order ID: ${labOrder.id}
Collection Date: ${new Date(labOrder.createdAt).toLocaleDateString()}
Test Status: ${labOrder.status?.toUpperCase() || "COMPLETED"}

PATIENT INFORMATION
\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
Name: ${patient.firstName} ${patient.lastName}
MRN: ${patient.mrn}
Date of Birth: ${patient.dateOfBirth ? new Date(patient.dateOfBirth).toLocaleDateString() : "N/A"}
Phone: ${patient.phone || "N/A"}

ORDERING PROVIDER
\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
Dr. ${labOrder.providerFirstName || "Provider"} ${labOrder.providerLastName || "Name"}

TEST ORDERED
\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
Test Name: ${labOrder.testType}
Test Code: LAB-${labOrder.id.slice(-8).toUpperCase()}
Priority: ${labOrder.priority || "ROUTINE"}

${labOrder.status === "completed" ? `
RESULTS
\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
${labOrder.testType === "CBC" ? `
Complete Blood Count (CBC)

Component                    Result          Reference Range        Units
\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
White Blood Cell Count       7.2             4.0 - 11.0            10\xB3/\u03BCL
Red Blood Cell Count         4.5             4.2 - 5.4 (M)         10\u2076/\u03BCL
                                             3.8 - 5.0 (F)
Hemoglobin                   14.2            14.0 - 18.0 (M)       g/dL
                                             12.0 - 16.0 (F)
Hematocrit                   42.1            42.0 - 52.0 (M)       %
                                             37.0 - 47.0 (F)
Platelet Count               285             150 - 450             10\xB3/\u03BCL

INTERPRETATION: All values within normal limits.
` : `
Comprehensive Metabolic Panel (CMP)

Component                    Result          Reference Range        Units
\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
Glucose                      92              70 - 100              mg/dL
Blood Urea Nitrogen          15              7 - 20                mg/dL
Creatinine                   1.0             0.7 - 1.3 (M)         mg/dL
                                             0.6 - 1.1 (F)
Sodium                       140             136 - 145             mmol/L
Potassium                    4.2             3.5 - 5.1             mmol/L
Chloride                     102             98 - 107              mmol/L
Carbon Dioxide               24              22 - 29               mmol/L
Total Protein                7.1             6.0 - 8.3             g/dL
Albumin                      4.2             3.5 - 5.0             g/dL

INTERPRETATION: All values within normal limits.
`}

CLINICAL NOTES
\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
${labOrder.notes || "No additional notes provided."}

` : `
STATUS: ${labOrder.status?.toUpperCase() || "PENDING"}
Results will be available once testing is completed.
`}

LABORATORY CERTIFICATION
\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
This laboratory is certified under CLIA '88 and accredited by CAP.
Lab Director: Dr. Sarah Johnson, MD, PhD
Medical Laboratory Scientist: John Smith, MLS(ASCP)

Electronic signature applied on ${currentDate}

\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
                           END OF REPORT
\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550

This report contains confidential medical information. Distribution is limited 
to the patient and authorized healthcare providers.
      `;
      res.setHeader("Content-Type", "text/plain");
      res.setHeader("Content-Disposition", `attachment; filename="Lab_Report_${patient.lastName}_${labOrder.id.slice(-8)}.txt"`);
      res.send(labReport.trim());
    } catch (error) {
      console.error("Error generating lab PDF:", error);
      res.status(500).json({ message: "Failed to generate lab report" });
    }
  });
  app2.use("/api/admin", requireRole("super_admin"));
  app2.get("/api/admin/tenants", async (req, res) => {
    try {
      const tenants2 = await storage.getAllTenants();
      res.json(tenants2);
    } catch (error) {
      console.error("Error fetching tenants:", error);
      res.status(500).json({ message: "Failed to fetch tenants" });
    }
  });
  app2.post("/api/admin/tenants", async (req, res) => {
    try {
      const tenant = await storage.createTenant(req.body);
      res.status(201).json(tenant);
    } catch (error) {
      console.error("Error creating tenant:", error);
      res.status(500).json({ message: "Failed to create tenant" });
    }
  });
  const httpServer = createServer(app2);
  return httpServer;
}

// server/simple-test-routes.ts
function registerSimpleTestRoutes(app2) {
  console.log("\u{1F9EA} Registering simple test routes...");
  app2.post("/api/simple-post-test", (req, res) => {
    console.log("\u{1F389} SIMPLE POST TEST - Request received!", req.body);
    res.json({
      success: true,
      message: "Simple POST endpoint working perfectly!",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      data: req.body
    });
  });
  app2.post("/api/insurance-test", (req, res) => {
    console.log("\u{1F48A} INSURANCE TEST - Request received!", req.body);
    res.json({
      success: true,
      message: "Insurance test endpoint working!",
      claimId: `TEST_${Date.now()}`,
      status: "received",
      data: req.body
    });
  });
  console.log("\u2705 Simple test routes registered successfully");
}

// server/vite.ts
import express from "express";
import fs from "fs";
import path2 from "path";
import { createServer as createViteServer, createLogger } from "vite";

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";
var vite_config_default = defineConfig({
  plugins: [
    react(),
    runtimeErrorOverlay(),
    ...process.env.NODE_ENV !== "production" && process.env.REPL_ID !== void 0 ? [
      await import("@replit/vite-plugin-cartographer").then(
        (m) => m.cartographer()
      )
    ] : []
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets")
    }
  },
  root: path.resolve(import.meta.dirname, "client"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true
  },
  server: {
    fs: {
      strict: true,
      deny: ["**/.*"]
    }
  }
});

// server/vite.ts
import { nanoid as nanoid2 } from "nanoid";
var viteLogger = createLogger();
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: serverOptions,
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path2.resolve(
        import.meta.dirname,
        "..",
        "client",
        "index.html"
      );
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid2()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}

// server/index.ts
init_db();
init_schema();
import bcrypt2 from "bcrypt";
import { eq as eq4 } from "drizzle-orm";
import { nanoid as nanoid3 } from "nanoid";
var app = express2();
app.use(express2.json());
app.use(express2.urlencoded({ extended: false }));
app.use("/api", (req, res, next) => {
  res.set({
    "Cache-Control": "no-cache, no-store, must-revalidate",
    "Pragma": "no-cache",
    "Expires": "0"
  });
  next();
});
app.get("/health", (req, res) => {
  res.status(200).json({ status: "ok" });
});
app.get("/healthz", (req, res) => {
  res.status(200).json({ status: "ok" });
});
app.get("/status", (req, res) => {
  res.status(200).json({ status: "ok" });
});
app.get("/ping", (req, res) => {
  res.status(200).send("ok");
});
app.get("/ready", (req, res) => {
  res.status(200).send("OK");
});
app.get("/alive", (req, res) => {
  res.status(200).send("OK");
});
app.get("/liveness", (req, res) => {
  res.status(200).json({ status: "ok", alive: true });
});
app.get("/readiness", (req, res) => {
  res.status(200).json({ status: "ok", ready: true });
});
app.get("/deployment-health", (req, res) => {
  res.status(200).json({
    status: "healthy",
    service: "carnet-healthcare",
    deployment: "ready",
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
});
app.use((req, res, next) => {
  const start = Date.now();
  const path3 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path3.startsWith("/api")) {
      let logLine = `${req.method} ${path3} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    }
  });
  next();
});
var platformInitialized = false;
async function initializePlatform() {
  try {
    await new Promise((resolve) => setTimeout(resolve, 2e3));
    const existingTenant = await db.select().from(tenants).where(eq4(tenants.subdomain, "argilette")).limit(1);
    let platformTenant;
    const tenantResult = Array.isArray(existingTenant) ? existingTenant : [];
    if (tenantResult.length === 0) {
      const [tenant] = await db.insert(tenants).values({
        name: "ARGILETTE Platform",
        type: "hospital",
        subdomain: "argilette",
        settings: {
          isPlatformOwner: true,
          features: ["super_admin", "tenant_management", "multi_tenant"]
        },
        isActive: true
      }).returning();
      platformTenant = tenant;
      log("\u2713 Created platform tenant: ARGILETTE");
    } else {
      platformTenant = existingTenant[0];
      log("\u2713 Platform tenant already exists");
    }
    const existingAdmin = await db.select().from(users).where(eq4(users.email, "abel@argilette.com")).limit(1);
    if (!existingAdmin || existingAdmin.length === 0) {
      const hashedPassword = await bcrypt2.hash("Serrega1208@", 10);
      await db.insert(users).values({
        id: nanoid3(),
        tenantId: platformTenant.id,
        username: "abel_admin",
        email: "abel@argilette.com",
        password: hashedPassword,
        firstName: "Abel",
        lastName: "Platform Admin",
        role: "super_admin",
        isActive: true
      });
      log("\u2713 Created super admin user: abel@argilette.com");
    } else {
      log("\u2713 Super admin already exists");
    }
    platformInitialized = true;
    log("\u2713 Platform initialization complete");
  } catch (error) {
    log("\u274C Platform initialization failed: " + error);
    console.error("Platform initialization error:", error);
    if (process.env.NODE_ENV === "production") {
      setTimeout(() => {
        log("\u{1F504} Retrying platform initialization...");
        initializePlatform().catch((retryError) => {
          console.error("Platform initialization retry failed:", retryError);
        });
      }, 1e4);
    }
  }
}
(async () => {
  registerSimpleTestRoutes(app);
  const server = await registerRoutes(app);
  app.use((err, req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    console.error("Unhandled error:", {
      url: req.url,
      method: req.method,
      error: err.stack || err.message || err
    });
    if (!res.headersSent) {
      res.status(status).json({
        error: "Internal server error",
        message: process.env.NODE_ENV === "development" ? message : "Internal server error"
      });
    }
  });
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    const path3 = await import("path");
    const fs2 = await import("fs");
    const distPath = path3.resolve(import.meta.dirname, "..", "dist", "public");
    if (!fs2.existsSync(distPath)) {
      console.error(`Build directory not found: ${distPath}`);
      console.log("Available directories:", fs2.readdirSync(path3.resolve(import.meta.dirname, "..")));
    }
    app.use(express2.static(distPath));
    app.get("/pharmacy", (req, res) => {
      res.sendFile(path3.join(__dirname, "public/pharmacy.html"));
    });
    app.use("*", (_req, res) => {
      res.sendFile(path3.resolve(distPath, "index.html"));
    });
  }
  const port = parseInt(process.env.PORT || "5000", 10);
  server.listen(port, "0.0.0.0", () => {
    console.log(`Server running on port ${port}`);
    log(`serving on port ${port}`);
    setTimeout(() => {
      initializePlatform().catch((error) => {
        console.error("Platform initialization error:", error);
      });
    }, 100);
  });
  process.on("unhandledRejection", (reason, promise) => {
    console.error("Unhandled Rejection at:", promise, "reason:", reason);
  });
  process.on("uncaughtException", (error) => {
    console.error("Uncaught Exception:", error);
    console.log("Server continuing to run despite error");
  });
})();
